# 01 — Design System

These are the foundational tokens. Set these up in `tailwind.config.ts` BEFORE you start implementing screens.

---

## Colors

### Neutral palette (used by all templates)

| Token | Value | Usage |
|---|---|---|
| `--ink` | `#111111` | Primary text, dark surfaces |
| `--ink-soft` | `#1a1a1a` | Footer / dark sections |
| `--graphite` | `#2a2a2a` | Secondary dark surfaces |
| `--paper` | `#fafaf7` | Body background (warm off-white) |
| `--paper-soft` | `#f5f3ee` | Cards, alt sections |
| `--paper-warm` | `#efece4` | Tertiary surfaces |
| `--rule` | `#e6e3da` | Borders, dividers |
| `--rule-soft` | `#d8d4c8` | Subtle borders |
| `--muted` | `#7a766c` | Secondary text |
| `--muted-soft` | `#9c988e` | Tertiary text |

### Tailwind 4 setup

```css
/* app.css */
@theme {
  --color-ink: #111111;
  --color-ink-soft: #1a1a1a;
  --color-graphite: #2a2a2a;
  --color-paper: #fafaf7;
  --color-paper-soft: #f5f3ee;
  --color-paper-warm: #efece4;
  --color-rule: #e6e3da;
  --color-rule-soft: #d8d4c8;
  --color-muted: #7a766c;
  --color-muted-soft: #9c988e;
}
```

### Brand accent (per-webstore variable)

Each webstore has a **single accent color** set by the distributor. Apply via CSS variable so it cascades:

```tsx
// At the webstore root layout:
<div style={{ '--brand-accent': webstore.brand.accentColor }}>
  {children}
</div>
```

```css
@theme {
  --color-brand: var(--brand-accent, #c84e2a); /* fallback */
}
```

Use `bg-brand`, `text-brand`, `border-brand` sparingly — only for true accents (primary CTA, active link underline, key data points). The neutral palette does the heavy lifting.

### Sample brand accent colors (for reference)

- Yan & Co. → `#c84e2a` (terracotta)
- Northwind → `#1f4d3a` (forest)
- Acme → `#1a2747` (navy)

---

## Typography

### Font stacks

| Role | Stack | Use |
|---|---|---|
| **Display serif** | `'Cormorant Garamond', Georgia, serif` | Modern hero, editorial moments |
| **Sans body** | `Inter, system-ui, sans-serif` | All body, UI, labels |
| **Mono micro** | `'JetBrains Mono', ui-monospace, monospace` | Tags, codes, metadata |

> If your project already standardizes on a different sans (e.g., Geist), keep it for portal screens. The display serif is mainly for the **Modern** template's hero/editorial sections — substitute thoughtfully.

### Type scale

| Token | Size / Line | Weight | Usage |
|---|---|---|---|
| `display-xl` | 96 / 1.0 | 400 italic | Modern hero headline |
| `display-lg` | 72 / 1.05 | 400 italic | Section openers |
| `h1` | 48 / 1.1 | 500 | Page titles |
| `h2` | 32 / 1.2 | 500 | Section headers |
| `h3` | 22 / 1.3 | 500 | Card titles |
| `body` | 15 / 1.55 | 400 | Default body |
| `body-sm` | 13 / 1.5 | 400 | Secondary text |
| `micro` | 11 / 1.0 | 500 uppercase, tracked +0.12em | Labels, kickers, eyebrows |

### Italics & mixed type (Modern template signature)

The Modern template uses **mixed roman + italic** in the same headline as a brand signature:

```html
<h1>The shop, <em class="font-serif italic">considered</em>.</h1>
```

This pattern appears in: hero, section openers, story panels. Don't use it in Classic or Minimal.

---

## Spacing

Standard Tailwind 4 spacing scale (4px base). Most layouts use `gap-6` (24px) to `gap-16` (64px) for major spacing.

Section padding rules:
- **Modern** → generous: `py-20` to `py-32` between sections
- **Classic** → tight: `py-8` to `py-12`
- **Minimal** → very generous: `py-32` to `py-48`

---

## Borders & rules

- All borders are `1px solid var(--color-rule)` — never thicker
- Cards in Classic use `border` + subtle shadow; Modern and Minimal use no card chrome (just whitespace + rules)
- Rounded corners: `rounded-md` (6px) for inputs/buttons; `rounded-lg` (8px) for cards in Classic; **0 radius** in Modern and Minimal (sharp corners)

---

## Shadows

Avoid heavy shadows. Only Classic uses subtle shadows on hover:
```css
hover:shadow-sm  /* Classic only */
```
Modern and Minimal rely entirely on whitespace + rules — no shadows.

---

## Iconography

- Use **lucide-react** (single weight, 1.5px stroke)
- 16px in dense UI, 20px in nav, 24px in heroes
- No emoji unless explicitly part of the brand
- Don't draw illustrations — use placeholder image components for any imagery

---

## Brand chrome contract

The shared header + footer take a `brand` prop:

```ts
type Brand = {
  id: string;            // 'yan' | 'nrt' | 'acme'
  name: string;          // 'Yan & Co.'
  logoText: string;      // text-only logo (or omit if logoUrl set)
  logoUrl?: string;      // optional image logo
  accent: string;        // hex color
  tagline?: string;      // footer tagline
};
```

Each storefront screen wraps content in a `<BrandContext.Provider value={brand}>`.

---

## Density modes (per template)

| Template | Container max-width | Section padding-y | Grid gap |
|---|---|---|---|
| Modern | 1320px | 80–128px | 32px |
| Classic | 1280px | 32–48px | 16px |
| Minimal | 1100px | 128–192px | 48px |

Applied via the template root component, not per-screen.
