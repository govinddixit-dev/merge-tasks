# Storefront — Checkout

**Route:** `/checkout`
**Auth:** Public (collects email + ship-to during flow)
**Template-driven:** Yes

---

## Purpose

Collect shipping + payment info and place the order.

---

## Common steps (all templates, single page or step-wise)

1. **Contact** — email
2. **Shipping address** — name, company, address, city, state, zip, country, phone
3. **Shipping method** — radio list (Standard / Express / Overnight) with prices
4. **Payment** — card details OR "Bill to PO" (B2B option)
5. **Review** — line items + totals confirmation
6. **Place order** — primary CTA

---

## Modern variant

**Source:** `source/storefront-screens.jsx` → `StoreCheckout`

**Layout:**
- Two-column: form (left, 60%) + sticky order summary (right, 40%)
- Form sections separated by hairline rules, no card borders
- Section labels in italic serif ("Shipping. Payment. Review.")
- Inputs are flat with bottom-rule only (no full borders)
- Place order button is brand accent, full-width within form column

## Classic variant

**Source:** `source/classic-screens.jsx` → `ClassicCheckout`

**Layout:**
- Breadcrumb: Cart > Checkout
- Two-column with full card borders around each section
- Standard form inputs (full borders, labels above)
- Sticky summary card with subtle shadow
- Trust bar above footer (Secure checkout / Free returns / Support)
- Payment icons (Visa, MC, Amex) inline with payment section

## Minimal variant

**Source:** `source/minimal-screens.jsx` → `MinimalCheckout`

**Layout:**
- Single centered column (max 600px)
- Form sections stacked, separated by generous whitespace
- Light-weight inputs, hairline borders
- Summary at the bottom, also centered
- Single full-width light-weight CTA

---

## Data needed

```ts
{
  brand: Brand;
  cart: Cart;
  shippingMethods: ShippingMethod[];
  // Optional pre-fill if user is signed in
  user?: { email: string; defaultAddress?: Address; };
}
```

---

## Behaviors

- Email validation on blur
- Address autocomplete (use existing project integration if any; otherwise plain inputs)
- Shipping method radio updates summary total live
- "Bill to PO" toggle replaces card fields with PO number + billing contact fields
- Place order → tRPC mutation → on success, redirect to `/portal/orders/:orderId/confirmation`
- Errors render inline next to fields; non-field errors at top
- Cart-out-of-stock state blocks the page and links back to `/cart`
