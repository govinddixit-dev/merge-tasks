# Portal — Print Requests

**Routes:**
- `/portal/print` — list
- `/portal/print/:id` — detail (production tracking)

**Auth:** Required
**Template-driven:** No

---

## Purpose

Track custom print/production jobs the distributor is running for the client (e.g. branded apparel runs, signage production, packaging). Different from regular orders — these have approval steps for proofs.

---

## List view

**Source:** `source/portal-screens.jsx` → `PortalPrintRequests`

- Page heading: "Print requests" + count
- Filter row: status (All / Awaiting proof / Proof ready / In production / Shipped / Completed)
- Cards or table layout — designer's choice based on content density (cards probably better here because of thumbnails):
  - Job #, name, thumbnail
  - Status badge with current step
  - Quantity, deadline
  - Action button (varies by status — see below)

## Detail view

**Source:** `source/portal-screens.jsx` → `PortalPrintDetail` (or similar)

- Breadcrumb: Print > {job name}
- **Header:** job #, name, status, deadline, quantity
- **Production timeline (vertical):**
  1. Brief received — date
  2. Proof prepared — date + "View proof" link (when ready)
  3. Proof approved — date (action: Approve / Request changes when in this state)
  4. Production started — date
  5. Quality check — date
  6. Shipped — tracking link
  7. Delivered — date
- **Specs panel:** material, ink, dimensions, finishing
- **Files:** brief, proofs, mockups, final art
- **Messages:** thread between client and production team (textarea + send)

---

## Data needed

```ts
type PrintRequest = {
  id; number; name; thumbnail;
  status: 'brief' | 'proof-pending' | 'proof-ready' | 'in-production' | 'qc' | 'shipped' | 'delivered';
  deadlineIso; quantity;
  specs: Record<string, string>;
  steps: { id; label; completedAt?; data?; }[];
  files: { name; url; type; sizeBytes; }[];
  messages: Message[];
};
```

---

## Behaviors

- "View proof" → opens lightbox with multi-page navigation
- "Approve proof" → confirmation modal → mutation → status flips to "in production"
- "Request changes" → opens textarea drawer with file attach → posts message + flips status to "brief"
- Message thread auto-scrolls to bottom; new messages append in real-time (use existing realtime layer if present, else poll)
