# Storefront — Shop

**Route:** `/shop`
**Auth:** Public
**Template-driven:** Yes

---

## Purpose

Browse and filter the product catalog.

---

## Modern variant

**Source:** `source/shop-most.jsx` → `ShopMost` (this is the most detailed; also see `StoreShop` in `storefront-screens.jsx` for a simpler variant)

**Layout:**
- Header (centered logo, thin nav)
- **Page intro:** Mixed italic/roman headline ("Everything we make, in one place.") + collection count
- **Filter pills:** Horizontal row of inline pills — "All / Apparel / Drinkware / Bags / Stationery / New". Active pill has the brand accent underline.
- **Sort:** Right-aligned dropdown ("Recommended / Price ↑ / Price ↓ / Newest")
- **Product grid:** Asymmetric — alternating rows of [1 large + 2 small], [3 medium], [2 large] etc. Cards have NO border, just whitespace + product image + name + small price
- **Curtain reveal footer** — see template doc

**Filters expose:**
- Category (pill selector)
- Sort (dropdown)
- That's it — Modern is intentionally light on filters

## Classic variant

**Source:** `source/classic-screens.jsx` → `ClassicShop`

**Layout:**
- Utility bar + main nav + promo banner (shared with Home)
- **Breadcrumb:** Home > Shop
- **Page header:** "Shop all" + result count + sort dropdown right-aligned
- **2-column body:**
  - **Left sidebar (240px):** Filter accordion — Category, Price (range slider), Size, Color (swatches), Availability
  - **Right (flex):** Active filter chips at top, then 4-column product grid with full card chrome
- **Pagination** at bottom — page numbers + prev/next
- Full footer

**Filters expose:**
- Category (multi-select checkboxes)
- Price (slider)
- Size (chip multi-select)
- Color (swatch multi-select)
- Availability (in stock / on sale)

## Minimal variant

**Source:** `source/minimal-screens.jsx` → `MinimalShop`

**Layout:**
- Minimal header
- **Page title:** Single light-weight heading, centered ("Shop")
- **Filter chips:** Single horizontal row of category chips, centered
- **Product grid:** 3-column, equal sizing, no chrome — just image / name / price stacked
- **Load more** button (no pagination), centered, light weight
- Minimal footer

**Filters expose:**
- Category (chip selector only)

---

## Data needed

```ts
{
  brand: Brand;
  products: Product[];
  categories: Category[];
  filters: {
    category?: string[];
    priceMin?: number;
    priceMax?: number;
    size?: string[];
    color?: string[];
    sort: 'recommended' | 'price-asc' | 'price-desc' | 'newest';
  };
}
```

---

## Product card content

| Field | Modern | Classic | Minimal |
|---|---|---|---|
| Image | Yes (varies in size) | Yes (1:1) | Yes (4:5 portrait) |
| Name | Yes | Yes | Yes (light) |
| Price | Yes (small) | Yes (bold) | Yes (light) |
| "Add to cart" button | No (whole card → PDP) | Yes (visible) | No (whole card → PDP) |
| Color swatches | No | Yes | No |
| "New / Sale" badge | Subtle italic | Bright pill | None |

---

## Behaviors

- Click product → PDP (out of scope; link to `/shop/:productId`)
- Filter changes → debounced URL update + grid refetch
- Sort changes → URL update + grid refetch
- Pagination (Classic) → URL `?page=N`
- Load more (Minimal) → infinite scroll-style append
