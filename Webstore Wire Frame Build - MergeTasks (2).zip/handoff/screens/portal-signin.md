# Portal — Sign In

**Route:** `/portal/signin`
**Auth:** Public (entry point to portal)
**Template-driven:** No (portal is template-agnostic)

---

## Purpose

Authenticate the end-user into the client portal.

---

## Layout

**Source:** `source/portal-screens.jsx` → `PortalSignIn`

- Centered single-column card (max 420px) on a paper-soft background
- Brand mark at top
- Heading: "Sign in"
- Email field
- Password field
- "Remember me" checkbox + "Forgot password?" link
- Primary "Sign in" button (brand accent)
- Divider: "or"
- Secondary: "Sign in with magic link" button → emails a one-time link
- Below card: "Don't have an account? Contact your account manager." (no public signup)

---

## Data / Auth

Use the project's existing auth (the wireframe assumes email + password and an alternate magic-link flow). Specifics live in your auth setup.

---

## Behaviors

- Email validation on blur
- Submit → existing auth mutation → on success, redirect to `/portal`
- Magic link → request mutation → switch to "Check your email" confirmation state
- Errors render above the form (red banner)
- After 3 failed attempts, show "Forgot password?" prominently

---

## Notes

- This is the only auth screen in the handoff. Signup, password reset, etc. use whatever the existing app provides — link out to those.
- The portal sign-in is per-webstore (the URL is `acme.mergetasks.store/portal/signin`), so the brand chrome reflects the webstore's brand.
