# Portal — Team

**Route:** `/portal/team`
**Auth:** Required (admin-only for invite/remove)
**Template-driven:** No

---

## Purpose

Manage which people on the client side have access to this webstore's portal. Roles: Admin (full access), Member (view + order), Viewer (view only).

---

## Layout

**Source:** `source/portal-screens.jsx` → `PortalTeam`

- Page heading: "Team" + member count
- "Invite member" button (admin-only) → opens drawer with email + role
- **Members list (table):**
  - Avatar, name, email
  - Role badge
  - Last active
  - Actions menu: Change role / Remove (admin-only; can't remove self)
- **Pending invites** section (if any):
  - Email, role, sent date, "Resend" / "Revoke"
- Empty state for invites: hidden if none

---

## Data needed

```ts
type Member = {
  id; userId;
  name; email; avatarUrl?;
  role: 'admin' | 'member' | 'viewer';
  lastActiveAt?;
  joinedAt;
};

type Invite = {
  id; email; role; sentAt; sentBy;
};
```

---

## Behaviors

- Invite → mutation → adds to pending list + sends email
- Change role → confirmation if downgrading admin → mutation
- Remove → confirmation modal → mutation
- Resend invite → mutation → toast "Invite resent"
- Revoke invite → mutation → removes from list
- Non-admins see the table but the actions menu is hidden; "Invite member" is hidden

---

## Permissions matrix

| Action | Admin | Member | Viewer |
|---|---|---|---|
| View team | ✓ | ✓ | ✓ |
| Invite | ✓ | — | — |
| Change role | ✓ | — | — |
| Remove | ✓ | — | — |
| View proposals/orders | ✓ | ✓ | ✓ |
| Accept proposal | ✓ | ✓ | — |
| Place order | ✓ | ✓ | — |
| Approve proof | ✓ | ✓ | — |
