# Portal — Proposals

**Routes:**
- `/portal/proposals` — list
- `/portal/proposals/:id` — detail

**Auth:** Required
**Template-driven:** No

---

## List view

**Source:** `source/portal-screens.jsx` → `PortalProposals`

- Page heading: "Proposals" + count
- Filter row: status (All / Pending / Accepted / Declined / Expired) + search input
- Table:
  - Columns: Proposal #, Title, Date sent, Total, Status badge, Actions (View)
  - Sort by Date desc default
  - Status badge colors: Pending=ink, Accepted=green, Declined=muted, Expired=muted
- Pagination at bottom
- Empty state: "No proposals yet. Custom requests turn into proposals once your account manager builds them."

## Detail view

**Source:** `source/portal-screens.jsx` → `PortalProposalDetail`

- Breadcrumb: Proposals > {proposal title}
- Header card:
  - Proposal #, title, status badge
  - Sent date, expires date
  - From: account manager (name + email)
  - Total amount (large)
- **Line items table:**
  - Image, name, options, qty, unit price, line total
  - Image previews open a lightbox
- **Notes / brief** section (if AM included narrative)
- **Files attached** (PDFs, mockups) — download list
- **Actions footer (sticky):**
  - Primary: "Accept proposal" → confirmation modal → status changes
  - Secondary: "Request changes" → opens textarea drawer → sends message to AM
  - Tertiary: "Decline" → confirmation modal with reason field
- Once accepted: footer changes to "Proceed to checkout" → fills cart with line items and routes to `/checkout`

---

## Data needed

```ts
type Proposal = {
  id; number; title;
  status: 'pending' | 'accepted' | 'declined' | 'expired';
  sentAt; expiresAt; acceptedAt?;
  total: number; currency;
  fromAccountManager: { name; email; };
  items: ProposalItem[];
  notes?: string;
  files: { name; url; sizeBytes; }[];
};
```

---

## Behaviors

- Accept → tRPC mutation → optimistic status flip → success toast → footer swaps to checkout CTA
- Request changes → mutation that creates a message thread → success toast
- Decline → mutation with reason → status flips, page becomes read-only
- Expired proposals are read-only with a "Request a new proposal" CTA
