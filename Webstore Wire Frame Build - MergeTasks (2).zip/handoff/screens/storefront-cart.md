# Storefront — Cart

**Route:** `/cart`
**Auth:** Public (cart is session-bound)
**Template-driven:** Yes

---

## Purpose

Review items before checkout. Adjust quantities, remove items, see totals.

---

## Common content (all templates)

- **Line items:** image, name, options (color/size), unit price, qty stepper, line total, remove
- **Order summary:** Subtotal, shipping (calculated at checkout), tax (calculated at checkout), total
- **Promo code:** Input + apply button
- **Empty state:** "Your cart is empty" + "Browse the shop" CTA
- **Continue to checkout:** primary CTA (brand accent)
- **Continue shopping:** secondary link

---

## Modern variant

**Source:** `source/storefront-screens.jsx` → `StoreCart`

**Layout:**
- Two-column: line items (left, 60%) + summary card (right, 40%)
- Line items have hairline rule between them, no card chrome
- Summary is a paper-soft block with totals stacked
- Italic note above the CTA: "*Shipping calculated at checkout.*"

## Classic variant

**Source:** `source/classic-screens.jsx` → `ClassicCart`

**Layout:**
- Breadcrumb: Home > Cart
- Two-column same as Modern but with full card borders
- Line items in a bordered table-like block
- Summary card has a subtle shadow
- "Apply" button next to promo input
- Trust bar at bottom (Free shipping / Returns / Support)

## Minimal variant

**Source:** `source/minimal-screens.jsx` → `MinimalCart`

**Layout:**
- Centered single column (max 720px), generous padding
- Line items as plain rows separated by hairlines
- Summary stacked below items, right-aligned numbers
- Single light-weight CTA button, full width

---

## Data needed

```ts
{
  brand: Brand;
  cart: {
    items: CartItem[];
    subtotal: number;
    estimatedShipping?: number;
    estimatedTax?: number;
    total: number;
    promoCode?: { code: string; discount: number; };
  };
}

type CartItem = {
  id: string;
  productId: string;
  name: string;
  image: string;
  options: { size?: string; color?: string; };
  unitPrice: number;
  qty: number;
  lineTotal: number;
  inStock: boolean;
};
```

---

## Behaviors

- Qty stepper updates line total + cart total optimistically
- Remove fades the row out, then refetches cart
- Promo code → tRPC mutation → applies discount inline + shows confirmation/error
- "Continue to checkout" → `/checkout` (requires no auth — checkout itself collects email)
- Out-of-stock items show a warning + disable checkout CTA
