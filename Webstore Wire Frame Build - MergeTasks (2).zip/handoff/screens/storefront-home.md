# Storefront — Home

**Route:** `/`
**Auth:** Public
**Template-driven:** Yes (Modern / Classic / Minimal each have a different design)

---

## Purpose

Welcome the end-user to the webstore. Showcase the brand, surface featured products, drive to Shop or Custom Request.

---

## Sections (all templates have these, styled differently)

1. **Header** — brand chrome
2. **Hero** — primary brand statement + CTA to Shop
3. **Featured products** — 4–8 products, links to Shop and PDP
4. **Story / about panel** — short blurb about the brand
5. **Custom request CTA** — banner driving to `/custom-request`
6. **Footer** — brand chrome

---

## Modern variant

**Source:** `source/storefront-screens.jsx` → `StoreHome`

**Layout:**
- Centered logo header with thin nav (Shop / Custom / Story / Account)
- **Hero:** Full-bleed image with mixed serif italic + sans headline overlay ("The shop, *considered*.") + small CTA pair (Shop / Story)
- **Featured products:** Asymmetric 4-up — large card on left spanning 2 rows, three smaller cards stacked on the right
- **Story panel:** 2-column — large italic pull-quote on left, small portrait + paragraph on right
- **Custom request CTA:** Full-bleed dark band, centered text + outlined button
- **Footer:** Becomes the curtain reveal grey panel — see template doc

**Key components:** `BrandHeader`, `BrandFooter`, `Hero`, `ProductCardLarge`, `ProductCardSmall`, `StoryPanel`, `CTABand`

## Classic variant

**Source:** `source/classic-screens.jsx` → `ClassicHome`

**Layout:**
- Top utility bar (phone, hours, Sign in, Cart [3])
- Main nav with logo left, links center (Shop / Categories / Custom / Sale / Contact), search + cart right
- Promo banner strip ("Free shipping over $200")
- **Hero:** 2-up split — left half image, right half offer card with title, description, CTA
- **Category tiles:** 4-column row of category images with labels
- **Featured products:** 4-column dense grid, full card chrome (image / title / price / "Add to cart")
- **Trust bar:** Free shipping / Returns / Support icons
- **Footer:** Full 4-column with newsletter + payment icons

**Key components:** `UtilityBar`, `MainNav`, `PromoBanner`, `HeroSplit`, `CategoryTileRow`, `ProductGrid4`, `TrustBar`, `FooterFull`

## Minimal variant

**Source:** `source/minimal-screens.jsx` → `MinimalHome`

**Layout:**
- Tiny centered logo header with 5 nav links spaced out (light weight)
- **Hero:** Single centered image (60% width), no overlay, micro-text caption below
- **Featured products:** 3-up symmetric grid, no card chrome — just image / name / price
- **Story:** Short centered paragraph in a narrow column (max 480px)
- **Custom request CTA:** Single text link, centered, underlined on hover
- **Footer:** Single line — `© Brand · Custom requests · Account`

**Key components:** `MinimalHeader`, `MinimalHero`, `MinimalProductGrid3`, `MinimalStory`, `MinimalFooter`

---

## Data needed

```ts
{
  brand: Brand;
  hero: { headline: string; sub: string; image: string; ctaLabel: string; };
  featured: Product[];      // 4–8 items
  story: { quote: string; body: string; portrait?: string; };
  customCta: { headline: string; sub: string; };
}
```

---

## Behaviors

- Clicking any product → PDP (out of scope for this handoff — link to `/shop/:productId`)
- "Shop" CTA → `/shop`
- "Custom request" CTA → `/custom-request`
- Account icon (Classic, Modern) → `/portal/signin` if not authenticated, else `/portal`
- Cart icon → `/cart` (always shows count badge)

---

## Responsive

- Modern: hero stacks vertically on mobile; featured grid becomes single column
- Classic: utility bar collapses to hamburger; sidebar moves to drawer; grid → 2-col
- Minimal: same structure, just narrower; grid → 1-col
