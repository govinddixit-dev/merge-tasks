# Portal — Orders

**Routes:**
- `/portal/orders` — list
- `/portal/orders/:id` — detail

**Auth:** Required
**Template-driven:** No

---

## List view

**Source:** `source/portal-screens.jsx` → `PortalOrders`

- Page heading: "Orders" + count
- Filter row: status (All / Processing / Shipped / Delivered / Cancelled) + date range + search
- Table:
  - Columns: Order #, Date, Items (count), Total, Status, Actions (View / Reorder)
  - Sort by Date desc default
- Pagination
- Empty state: "No orders yet. Browse the shop to get started."

## Detail view

**Source:** `source/portal-screens.jsx` → `PortalOrderDetail` (if not present, follow Proposal Detail pattern)

- Breadcrumb: Orders > {order #}
- **Header card:** order #, placed date, status badge, total
- **Tracking timeline:** 4-step horizontal — Placed → Processing → Shipped → Delivered (active step in brand accent; tracking number link if shipped)
- **Line items table:** image, name, options, qty, unit price, line total
- **Shipping address** card
- **Billing** card (last 4 of card or PO number)
- **Totals breakdown:** subtotal, shipping, tax, discount, total
- **Actions:**
  - "Download invoice" (PDF)
  - "Reorder" → fills cart with same items
  - "Request return" (if delivered within 30 days) → opens form
  - "Contact account manager"

---

## Data needed

```ts
type Order = {
  id; number;
  placedAt;
  status: 'processing' | 'shipped' | 'delivered' | 'cancelled';
  items: OrderItem[];
  shippingAddress: Address;
  billing: { method: 'card' | 'po'; last4?; poNumber?; };
  shipping: { carrier?; trackingNumber?; estimatedDelivery?; };
  totals: { subtotal; shipping; tax; discount; total; };
  invoiceUrl: string;
};
```

---

## Behaviors

- Reorder → fills cart with all items at current prices, redirects to `/cart` with a banner "Items from order #1234 added"
- Return → opens a form (item selector + reason) → mutation
- Tracking number → opens carrier tracking page in new tab
