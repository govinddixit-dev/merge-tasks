# Storefront — Custom Request

**Route:** `/custom-request`
**Auth:** Public
**Template-driven:** Yes

---

## Purpose

Let the end-user request a custom product not in the catalog (e.g. "I need 500 branded notebooks for a conference"). Submits a request to the distributor, who follows up with a proposal.

---

## Common form fields (all templates)

- Contact: name, email, company, phone
- Project: project name, deadline, quantity (range or number)
- Product type: free text or select (apparel / drinkware / print / signage / other)
- Budget range: optional select ($500–$1k, $1k–$5k, $5k–$25k, $25k+)
- Brief: long textarea
- Reference files: upload (multi-file, optional)
- Submit

---

## Modern variant

**Source:** `source/storefront-screens.jsx` → `StoreCustomRequest`

**Layout:**
- Hero strip: italic serif headline ("Have something *specific* in mind?") + intro paragraph
- Two-column form: 60/40 — fields on left, "What happens next" sidebar on right (timeline of 3 steps: Submit → We respond in 24h → Proposal)
- Hairline-rule fields, italic section labels
- Full-width brand-accent submit button at bottom
- Curtain reveal footer

## Classic variant

**Source:** `source/classic-screens.jsx` → `ClassicCustomRequest`

**Layout:**
- Utility bar + main nav + promo banner
- Breadcrumb: Home > Custom Request
- Two-column form inside a bordered card with shadow
- Standard inputs, labels above
- Sidebar with FAQ accordion (5 common questions)
- Footer

## Minimal variant

**Source:** `source/minimal-screens.jsx` → `MinimalCustomRequest`

**Layout:**
- Single centered column (max 560px)
- Light-weight heading + 2-line intro
- Form fields stacked, hairline-rule inputs only
- Single small italic note below: "*We respond within one business day.*"
- Light full-width submit button
- Minimal footer

---

## Data needed

```ts
{
  brand: Brand;
  productTypes: string[];
  budgetRanges: string[];
}
```

Submit payload:
```ts
{
  contact: { name; email; company; phone; };
  project: { name; deadlineIso?; quantity; };
  productType: string;
  budgetRange?: string;
  brief: string;
  files: File[];
}
```

---

## Behaviors

- Required: name, email, brief
- File upload: drag-drop + click; max 10 files, 25MB each
- Submit → tRPC mutation → success state replaces form with "Thanks, we'll respond within one business day" + a Portal sign-in CTA
- Validation errors inline next to fields
