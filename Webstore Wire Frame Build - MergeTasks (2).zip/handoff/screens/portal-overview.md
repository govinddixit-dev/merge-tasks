# Portal — Overview

**Route:** `/portal`
**Auth:** Required
**Template-driven:** No

---

## Purpose

The end-user's home base after sign in. Shows recent activity, quick actions, and account snapshot.

---

## Layout

**Source:** `source/portal-screens.jsx` → `PortalOverview`

- Portal chrome: top bar with brand mark + nav (Overview / Proposals / Orders / Print / Team) + account menu
- **Greeting:** "Welcome back, {firstName}." + small last-sign-in timestamp
- **3 stat tiles** (3-column grid):
  - Active proposals (count + "View all" link)
  - Open orders (count + "View all")
  - Print requests in production (count + "View all")
- **Recent activity feed** (left, 60%): timeline of last 8 events
  - Proposal sent / accepted / declined
  - Order placed / shipped / delivered
  - Print request submitted / approved / completed
  - Each row: icon + title + 1-line description + timestamp
- **Quick actions card** (right, 40%):
  - "New custom request" → `/custom-request`
  - "Browse the shop" → `/shop`
  - "Contact account manager" → opens drawer with AM card (name, email, phone)

---

## Data needed

```ts
{
  user: { firstName; lastSignInAt; };
  stats: {
    activeProposals: number;
    openOrders: number;
    printsInProduction: number;
  };
  activity: ActivityEvent[];
  accountManager: { name; email; phone; avatar?; };
}
```

---

## Behaviors

- Stat tiles → respective list pages
- Activity event → respective detail page
- Quick action "Contact AM" → opens a side drawer (shadcn `Sheet`) with AM contact details + a "Send message" form
