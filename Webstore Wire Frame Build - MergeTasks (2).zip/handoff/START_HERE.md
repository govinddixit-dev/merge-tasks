# 🚀 START HERE — MergeTasks Webstore UI Handoff

**You are looking at design specs for the MergeTasks distributor webstore UI.**

This handoff package contains everything needed to implement the storefront and portal UI in your existing app (React 19 + TypeScript + Tailwind 4 + shadcn/ui + tRPC).

---

## 📖 Read these files in this order

1. **`CLAUDE.md`** ← if you are Claude Code, start here
2. **`00_PRODUCT_OVERVIEW.md`** — what this product is, who uses it
3. **`01_DESIGN_SYSTEM.md`** — colors, typography, spacing tokens
4. **`02_TEMPLATES.md`** — the 3 templates (Modern, Classic, Minimal)
5. **`screens/`** — one spec sheet per screen
6. **`IMPLEMENTATION_GUIDE.md`** — how to wire it into React 19 + Tailwind + shadcn
7. **`source/`** — the actual working JSX components from the wireframes

---

## 🎯 What you're building

A **customizable webstore** that distributors create for their end-user clients (e.g., "Northwind Apparel" creating a swag store for "Acme Corp"). The end-user picks one of **3 templates** during onboarding and the entire storefront re-styles to match.

**Three templates:**

| Template | Vibe | Best for |
|---|---|---|
| **Modern** | Editorial, asymmetric, curtain-reveal scroll, big italic typography | Lifestyle / agency / boutique brands |
| **Classic** | Traditional e-commerce, sidebar nav, dense grid, utility bar | Large catalogs (Shopify default vibe) |
| **Minimal** | Whitespace-heavy, thin type, no card chrome | Premium / curated / Aesop / Apple Store |

**Two surface areas:**

1. **Storefront** (changes per template) — Home, Shop, Cart, Checkout, Custom Request
2. **Client Portal** (template-agnostic, always the same) — Sign In, Overview, Proposals, Orders, Print Requests, Team

---

## 📂 What's in this folder

```
handoff/
├── START_HERE.md                  ← you are here
├── CLAUDE.md                      ← Claude Code instructions
├── 00_PRODUCT_OVERVIEW.md         ← what this is
├── 01_DESIGN_SYSTEM.md            ← tokens
├── 02_TEMPLATES.md                ← the 3 templates compared
├── IMPLEMENTATION_GUIDE.md        ← React 19 + Tailwind 4 + shadcn mapping
├── Webstore Wireframes.html       ← OPEN IN BROWSER to see all screens
├── screens/
│   ├── storefront-home.md         ← per-template spec
│   ├── storefront-shop.md
│   ├── storefront-cart.md
│   ├── storefront-checkout.md
│   ├── storefront-custom-request.md
│   ├── portal-signin.md
│   ├── portal-overview.md
│   ├── portal-proposals.md
│   ├── portal-orders.md
│   ├── portal-print.md
│   └── portal-team.md
└── source/                        ← working JSX components
    ├── brand-chrome.jsx           ← shared header/footer
    ├── primitives.jsx             ← icons, placeholders
    ├── storefront-screens.jsx     ← Modern template (storefront)
    ├── classic-screens.jsx        ← Classic template (storefront)
    ├── minimal-screens.jsx        ← Minimal template (storefront)
    ├── portal-screens.jsx         ← all portal screens
    ├── shop-most.jsx              ← detailed Modern Shop with curtain reveal
    ├── design-canvas.jsx          ← canvas layout (not for production)
    └── styles.css                 ← canvas styles (not for production)
```

---

## ⚡ Quick start for the developer

1. Open `Webstore Wireframes.html` in a browser to see all 24 screens visually
2. Read `00_PRODUCT_OVERVIEW.md` so you know what you're building
3. Read `01_DESIGN_SYSTEM.md` to set up your Tailwind theme tokens
4. Pick a screen from `screens/` to start with (recommend `storefront-home.md`)
5. Reference the corresponding `source/*.jsx` file for working code
6. Map JSX components to your shadcn primitives per `IMPLEMENTATION_GUIDE.md`

**Don't try to convert all 24 screens at once.** Start with one full template (e.g., Modern Home → Shop → Cart → Checkout) end-to-end, then duplicate the pattern for Classic and Minimal.

---

## ❓ Questions while implementing?

The spec sheets are intentionally short and focused. If something is ambiguous:
1. Open `Webstore Wireframes.html` and look at the actual rendered design
2. Open `source/<file>.jsx` and read the JSX — it's the source of truth
3. The README answers the most common questions; if it doesn't, ask the designer
