# Instructions for Claude Code

You are implementing UI designs for the **MergeTasks distributor webstore**. This folder contains the design specs and working JSX source from the wireframe phase.

## 🎯 Your job

Implement the screens described in `screens/*.md` into the existing React 19 + TypeScript + Tailwind 4 + shadcn/ui + tRPC codebase. The backend is already built.

## 📖 Read in this exact order

1. `START_HERE.md` — overview of the package
2. `00_PRODUCT_OVERVIEW.md` — product context (what is this, who uses it, what are templates)
3. `01_DESIGN_SYSTEM.md` — colors, type, spacing tokens — set these up in Tailwind first
4. `02_TEMPLATES.md` — understand the differences between the 3 templates
5. `IMPLEMENTATION_GUIDE.md` — concrete React/Tailwind/shadcn patterns
6. Then pick a screen and read its spec in `screens/<screen>.md`

## ⚠️ Critical rules

### 1. Templates are switchable per webstore

Each end-user webstore picks **one** template (Modern / Classic / Minimal) at creation time, and that template defines the visual language for ALL storefront screens (Home, Shop, Cart, Checkout, Custom Request). The portal is template-agnostic.

Implement template selection as a single value on the webstore record (e.g. `webstore.template: 'modern' | 'classic' | 'minimal'`) and switch component rendering off of it.

### 2. Brand theming is separate from templates

Each end-user has a brand (logo, name, primary accent color). Brand theming applies on top of the chosen template. See `01_DESIGN_SYSTEM.md` → "Brand Context."

So a screen has TWO axes of variation:
- **Template** (Modern / Classic / Minimal) — controls layout, typography, density
- **Brand** (per end-user) — controls logo, accent color, name strings

### 3. The source/ JSX files are reference, not production

The JSX in `source/` is the wireframe code. It uses inline styles, hard-coded values, and React 18 patterns. **Don't copy it directly.** Instead:
- Read it to understand layout, spacing, and component structure
- Convert inline styles to Tailwind classes
- Use shadcn primitives (Button, Input, Card, Sheet, etc.) where they fit
- Use the project's existing tRPC hooks for data

### 4. The portal is the same across templates

Don't build 3 versions of the portal screens. Just one set, using the project's neutral design system.

### 5. Storefront screens differ significantly by template

- **Modern** uses a "curtain reveal" scroll effect (white panel slides up over a fixed grey footer underneath). Implement with `position: sticky` or scroll-bound translate.
- **Classic** is a traditional fixed header + sidebar layout — no curtain.
- **Minimal** is generous whitespace and editorial centered layout — no curtain, no sidebar.

### 6. When in doubt, defer to the rendered HTML

`Webstore Wireframes.html` is the source of truth for visual decisions. Open it in a browser and look. The markdown specs are summaries — the JSX + rendered HTML is the actual design.

## 🛠️ Recommended implementation order

1. **Set up design tokens in Tailwind** (`tailwind.config.ts` — copy from `01_DESIGN_SYSTEM.md`)
2. **Build the shared header / footer / brand chrome** (`source/brand-chrome.jsx` is the reference)
3. **Pick one template to fully implement first** (recommend Modern — it's already most-developed)
4. **Build storefront screens for that template in order**: Home → Shop → Cart → Checkout → Custom Request
5. **Build the portal** (one set, template-agnostic): Sign In → Overview → Proposals → Orders → Print → Team
6. **Duplicate the pattern for Classic and Minimal** templates

## 🚫 What NOT to do

- Don't introduce new colors not in `01_DESIGN_SYSTEM.md` without asking
- Don't add screens that aren't in `screens/`
- Don't redesign — match the wireframes
- Don't implement all 3 templates in parallel — finish one fully first
- Don't use the canvas/design-canvas.jsx files in production — they're scaffolding for the wireframe view only
