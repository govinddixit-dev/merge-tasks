# Implementation Guide

How to translate the wireframe JSX into your production stack: **React 19 + TypeScript + Tailwind 4 + shadcn/ui + tRPC**.

---

## 1. Set up Tailwind tokens first

Before writing any screens, copy the design tokens from `01_DESIGN_SYSTEM.md` into your `app.css`:

```css
@import "tailwindcss";

@theme {
  --color-ink: #111111;
  --color-ink-soft: #1a1a1a;
  --color-graphite: #2a2a2a;
  --color-paper: #fafaf7;
  --color-paper-soft: #f5f3ee;
  --color-paper-warm: #efece4;
  --color-rule: #e6e3da;
  --color-rule-soft: #d8d4c8;
  --color-muted: #7a766c;
  --color-muted-soft: #9c988e;
  --color-brand: var(--brand-accent, #c84e2a);

  --font-sans: "Inter", system-ui, sans-serif;
  --font-serif: "Cormorant Garamond", Georgia, serif;
  --font-mono: "JetBrains Mono", ui-monospace, monospace;
}
```

Then verify a quick test page renders `bg-paper text-ink font-serif italic` correctly before continuing.

---

## 2. Brand context as React context

```tsx
// brand-context.tsx
type Brand = {
  id: string;
  name: string;
  logoText: string;
  logoUrl?: string;
  accent: string;
  tagline?: string;
};

const BrandContext = createContext<Brand | null>(null);
export const useBrand = () => {
  const b = useContext(BrandContext);
  if (!b) throw new Error("Wrap in <BrandProvider>");
  return b;
};

export function BrandProvider({ brand, children }: { brand: Brand; children: ReactNode }) {
  return (
    <div style={{ "--brand-accent": brand.accent } as CSSProperties}>
      <BrandContext.Provider value={brand}>{children}</BrandContext.Provider>
    </div>
  );
}
```

Wrap each storefront route at the top level — the webstore loader fetches the brand record and passes it.

---

## 3. Template switching

Each storefront page is a thin switcher:

```tsx
// app/(storefront)/page.tsx
export default async function HomePage() {
  const webstore = await getCurrentWebstore();        // tRPC server call
  const brand = webstore.brand;

  const Template = {
    modern: ModernHome,
    classic: ClassicHome,
    minimal: MinimalHome,
  }[webstore.template];

  return (
    <BrandProvider brand={brand}>
      <Template webstore={webstore} />
    </BrandProvider>
  );
}
```

Each `<XxxHome>` lives in its own file under `components/storefront/<template>/Home.tsx` and renders its own header/footer chrome.

---

## 4. Mapping wireframe components → shadcn

| Wireframe (in JSX source) | shadcn equivalent |
|---|---|
| Custom inputs (hairline-rule) | `<Input className="border-0 border-b border-rule rounded-none px-0">` |
| Plain buttons | `<Button>` with custom variants (see below) |
| Filter pills | shadcn `Toggle` or custom `<button>` with `data-active` |
| Sidebar filter accordion (Classic) | `<Accordion>` |
| Cart sheet, AM contact drawer | `<Sheet>` |
| Promo banner | Plain `<div>` — no shadcn primitive |
| Modal confirmations | `<AlertDialog>` |
| Status badges | `<Badge>` with custom variants |
| Stepper / qty | Build inline — two `<Button size="icon">` + display |
| Toast | Existing project toaster |

### Button variants to add

```ts
// In your Button component:
variants: {
  brand:    "bg-brand text-white hover:bg-brand/90",
  ghostInk: "bg-transparent text-ink hover:bg-paper-soft",
  outlineInk: "border border-ink text-ink hover:bg-ink hover:text-paper",
  link:     "underline underline-offset-4 hover:text-brand",
}
```

---

## 5. The "curtain reveal" effect (Modern only)

The Modern template's signature scroll effect: as you scroll, a white panel slides up over a fixed grey panel underneath, then reveals the grey as a permanent footer at the bottom.

**Simplest implementation** (CSS-only, no JS):

```tsx
function ModernLayout({ children }: { children: ReactNode }) {
  return (
    <>
      {/* Fixed grey footer panel that sits under everything */}
      <div className="fixed inset-x-0 bottom-0 h-[480px] bg-graphite text-paper z-0">
        <FooterContent />
      </div>

      {/* White content panel that slides over it */}
      <div className="relative z-10 bg-paper min-h-screen mb-[480px]">
        {children}
      </div>
    </>
  );
}
```

The `mb-[480px]` reserves the height of the fixed footer so when you scroll all the way down, the footer is fully visible. The `z-10` content panel covers the footer until then.

**Reference:** `source/storefront-screens.jsx` — search for `curtain` or look at `BrandLayout`.

---

## 6. tRPC wiring — recommended route shape

```ts
// server/routers/webstore.ts
export const webstoreRouter = router({
  getCurrent: publicProcedure.query(...),     // by subdomain
  listProducts: publicProcedure.input(...).query(...),
  getProduct: publicProcedure.input(...).query(...),

  cart: router({
    get: publicProcedure.query(...),          // session-bound
    addItem: publicProcedure.mutation(...),
    updateItem: publicProcedure.mutation(...),
    removeItem: publicProcedure.mutation(...),
    applyPromo: publicProcedure.mutation(...),
  }),

  checkout: router({
    placeOrder: publicProcedure.mutation(...),
  }),

  customRequest: router({
    submit: publicProcedure.mutation(...),
  }),
});

export const portalRouter = router({
  overview: protectedProcedure.query(...),
  proposals: router({
    list: protectedProcedure.query(...),
    get: protectedProcedure.query(...),
    accept: protectedProcedure.mutation(...),
    decline: protectedProcedure.mutation(...),
    requestChanges: protectedProcedure.mutation(...),
  }),
  orders: router({
    list: protectedProcedure.query(...),
    get: protectedProcedure.query(...),
    reorder: protectedProcedure.mutation(...),
  }),
  print: router({
    list: protectedProcedure.query(...),
    get: protectedProcedure.query(...),
    approveProof: protectedProcedure.mutation(...),
    requestChanges: protectedProcedure.mutation(...),
  }),
  team: router({
    list: protectedProcedure.query(...),
    invite: adminProcedure.mutation(...),
    changeRole: adminProcedure.mutation(...),
    remove: adminProcedure.mutation(...),
  }),
});
```

---

## 7. File structure recommendation

```
app/
├── (storefront)/
│   ├── layout.tsx                        ← BrandProvider + template switch wrapper
│   ├── page.tsx                          ← Home
│   ├── shop/page.tsx
│   ├── cart/page.tsx
│   ├── checkout/page.tsx
│   └── custom-request/page.tsx
├── portal/
│   ├── layout.tsx                        ← Portal chrome
│   ├── signin/page.tsx
│   ├── page.tsx                          ← Overview
│   ├── proposals/
│   ├── orders/
│   ├── print/
│   └── team/
components/
├── brand/
│   ├── BrandContext.tsx
│   └── BrandHeader.tsx                   ← variants: modern/classic/minimal
├── storefront/
│   ├── modern/  { Home, Shop, Cart, Checkout, CustomRequest, Header, Footer }
│   ├── classic/ { Home, Shop, Cart, Checkout, CustomRequest, Header, Footer, UtilityBar, PromoBanner, Sidebar }
│   └── minimal/ { Home, Shop, Cart, Checkout, CustomRequest, Header, Footer }
└── portal/      { Overview, Proposals, ProposalDetail, Orders, OrderDetail, Print, PrintDetail, Team, Nav }
```

---

## 8. Things to NOT do

- ❌ Don't try to extract a shared `<StorefrontLayout>` — the chrome differs too much per template
- ❌ Don't use `motion`/`framer-motion` — none of the wireframes need motion beyond CSS hover/transition
- ❌ Don't copy inline styles from `source/*.jsx` — convert to Tailwind classes
- ❌ Don't introduce new colors not in the design system
- ❌ Don't reuse `design-canvas.jsx` or `styles.css` from source — that's wireframe scaffolding only
- ❌ Don't build all 3 templates in parallel — finish Modern end-to-end first

---

## 9. Smoke test before declaring a screen done

For each screen:
1. Renders without console errors
2. Loads with all 3 brands (Yan / Northwind / Acme) — accent color updates correctly
3. Renders in the correct template variant
4. Empty states render (zero cart items, zero proposals, etc.)
5. Loading states render (use shadcn `Skeleton`)
6. Mobile width (375px) doesn't break — layout reflows reasonably
7. Keyboard nav works (Tab order is sensible, focus rings visible)
