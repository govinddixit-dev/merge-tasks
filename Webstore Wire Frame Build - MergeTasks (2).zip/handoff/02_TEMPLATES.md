# 02 — Templates

The webstore has three templates. Each end-user webstore picks **one** at creation, and that template controls the visual language for **all storefront screens** (Home, Shop, Cart, Checkout, Custom Request).

> The **portal is template-agnostic** — same design across all three.

---

## Modern

**Vibe:** Editorial, asymmetric, magazine-like. Generous whitespace + mixed serif italic + sans typography.

**Distinctive:**
- **Curtain reveal scroll** — a fixed grey panel sits underneath the page; as you scroll, the white content panel slides up over it, then a final reveal at the bottom shows the grey panel as a permanent footer. Implement with `position: sticky` or scroll-bound transforms.
- **Mixed type** — roman + italic serif in the same headline ("The shop, *considered*.")
- **Asymmetric grids** — product cards in 1+2+1 or 2+1+2 staggered layouts, not uniform
- **Centered logo** in the header, thin nav links left and right
- **No card chrome** — products float on the paper background with hairline rules

**Best for:** Lifestyle, agency, boutique brands, fashion-forward distributors.

**Files:**
- `source/storefront-screens.jsx` (StoreHome, StoreCart, StoreCheckout, StoreCustomRequest)
- `source/shop-most.jsx` (ShopMost — the detailed shop view with curtain reveal)

---

## Classic

**Vibe:** Traditional e-commerce, retail-familiar. Like Shopify default themes — utility bar, main nav, sidebar filters, dense product grid.

**Distinctive:**
- **Top utility bar** with phone, hours, account, cart count — the slim line above the main nav
- **Standard horizontal nav** with logo on the left, nav links center, search + cart right
- **Promo banner strip** ("Free shipping on orders over $200")
- **Sidebar filters** on Shop (categories, price, size, color)
- **Dense 4-column product grid** with full card chrome (border + image + title + price)
- **Standard breadcrumbs**
- **Full footer** with newsletter signup + 4 link columns + payment icons

**Best for:** Large catalogs, distributors selling to corporate procurement teams who expect Shopify-like UX, B2B utility-driven shoppers.

**Files:**
- `source/classic-screens.jsx` (ClassicHome, ClassicShop, ClassicCart, ClassicCheckout, ClassicCustomRequest)

---

## Minimal

**Vibe:** Premium, curated, gallery-like. Whitespace as the primary design tool. Aesop / Apple Store / MUJI aesthetic.

**Distinctive:**
- **Tiny centered logo** with massive whitespace around it
- **No utility bar, no promo banners, no sidebar filters**
- **Filter chips** as a single horizontal row above the grid
- **3-column grid** with no card chrome — just product image + name + price stacked
- **Light type weights** throughout
- **Massive section padding** (128–192px between sections)
- **Centered single hero image**, no overlay text
- **Minimal footer** — single line, centered

**Best for:** Premium / aesthetic / curated brands, distributors selling high-end gifts, executive swag, design-forward companies.

**Files:**
- `source/minimal-screens.jsx` (MinimalHome, MinimalShop, MinimalCart, MinimalCheckout, MinimalCustomRequest)

---

## Visual comparison cheatsheet

| Aspect | Modern | Classic | Minimal |
|---|---|---|---|
| Header height | 88px | 64px (nav) + 36px (utility) | 96px |
| Logo position | Centered | Left | Centered (small) |
| Hero | Curtain-reveal grey panel | Promo banner | Single centered image |
| Product grid | Asymmetric, no chrome | 4-col dense, full chrome | 3-col, no chrome |
| Card border | None | 1px rule + subtle shadow on hover | None |
| Card radius | 0 | 8px | 0 |
| Filters | Pills above grid | Sidebar (left) | Chip row above grid |
| Type | Sans + serif italic mix | Sans only | Sans, light weights |
| Section padding | 80–128px | 32–48px | 128–192px |
| Footer | Curtain-revealed grey panel | Full 4-column | Single line centered |
| Card hover | Subtle lift | Shadow + rule darken | Image dim only |

---

## Implementation pattern

```tsx
// Pseudo-code
function StorefrontHome({ webstore }: { webstore: Webstore }) {
  switch (webstore.template) {
    case 'modern':  return <ModernHome brand={webstore.brand} />;
    case 'classic': return <ClassicHome brand={webstore.brand} />;
    case 'minimal': return <MinimalHome brand={webstore.brand} />;
  }
}
```

Each `<XxxHome>` etc. renders its own header/footer chrome using the template's design language. Don't try to extract a shared `<Layout>` — the chrome differs too much.

---

## Recommended build order

1. **Modern first** — it's the most visually distinct and most-developed in the wireframes
2. **Classic second** — copy Modern's data structures, redo the layout
3. **Minimal last** — easiest visually but use Modern's data wiring as a starting point

Within each template: Home → Shop → Cart → Checkout → Custom Request.
