/* global React, Icon, Ph, BrandContext, RingLogo */
// MINIMAL template — premium / Aesop / Apple Store. Massive whitespace,
// thin typography, no card chrome, products float on white.

const MinimalShell = ({ children }) => {
  const b = React.useContext(BrandContext);
  return (
    <div style={{ width: '100%', height: '100%', background: '#fff', overflow: 'auto', fontFamily: '"Inter Tight", -apple-system, sans-serif', color: '#1b1b1b' }}>
      {/* Ultra-thin header */}
      <div style={{ padding: '32px 64px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #f0f0f0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <RingLogo size={20} color={b.logoColor} />
          <div style={{ fontSize: 13, fontWeight: 500, letterSpacing: '0.16em', textTransform: 'uppercase' }}>{b.name}</div>
        </div>
        <div style={{ display: 'flex', gap: 36, fontSize: 11, fontWeight: 400, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#1b1b1b' }}>
          <span>Shop</span><span>Collections</span><span>Custom</span><span>Portal</span>
        </div>
        <div style={{ display: 'flex', gap: 24, fontSize: 11, letterSpacing: '0.16em', textTransform: 'uppercase', color: '#1b1b1b' }}>
          <span>Search</span><span>Account</span><span>Bag (2)</span>
        </div>
      </div>
      {children}
    </div>
  );
};

const MinimalFooter = () => {
  const b = React.useContext(BrandContext);
  return (
    <div style={{ padding: '64px 64px 32px', borderTop: '1px solid #f0f0f0', fontFamily: '"Inter Tight", sans-serif' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr 1fr', gap: 48, marginBottom: 48 }}>
        <div>
          <div style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#1b1b1b', marginBottom: 16, fontWeight: 500 }}>{b.name}</div>
          <p style={{ margin: 0, color: '#666', fontSize: 13, lineHeight: 1.7, maxWidth: 320 }}>A curated selection of branded essentials, considered and made for your team.</p>
        </div>
        {[['Shop',['Apparel','Headwear','Drinkware','Bags']],['Service',['Contact','Returns','Sizing','FAQ']],['Studio',['About','Custom','Portal','Press']]].map(([h, links]) => (
          <div key={h}>
            <div style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#1b1b1b', marginBottom: 16 }}>{h}</div>
            {links.map(l => <div key={l} style={{ marginBottom: 10, color: '#666', fontSize: 13 }}>{l}</div>)}
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 24, borderTop: '1px solid #f0f0f0', fontSize: 11, color: '#999', letterSpacing: '0.06em' }}>
        <div>©2026 {b.name}</div>
        <div>Powered by MergeTasks Enterprise Platform</div>
      </div>
    </div>
  );
};

// Floating product (no card chrome)
const MinimalProduct = ({ ratio = '4/5', name = 'Heavyweight Crewneck', price = '$48' }) => (
  <div>
    <div style={{ aspectRatio: ratio, background: '#fafafa', position: 'relative', marginBottom: 16 }}>
      <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 0 }} />
    </div>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
      <div style={{ fontSize: 14, fontWeight: 400, color: '#1b1b1b' }}>{name}</div>
      <div style={{ fontSize: 13, color: '#666' }}>{price}</div>
    </div>
    <div style={{ fontSize: 11, color: '#999', marginTop: 4, letterSpacing: '0.04em' }}>4 colors</div>
  </div>
);

// ── HOME ─────────────────────────────────────────────────────────
function MinimalHome() {
  const b = React.useContext(BrandContext);
  return (
    <MinimalShell>
      {/* Editorial hero */}
      <div style={{ padding: '120px 64px 80px', textAlign: 'center' }}>
        <div style={{ fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', color: '#999', marginBottom: 32 }}>Spring · Summer 2026</div>
        <h1 style={{ fontSize: 80, fontWeight: 300, lineHeight: 1.05, margin: 0, letterSpacing: -0.02 }}>Considered<br />essentials.</h1>
        <p style={{ maxWidth: 480, margin: '32px auto 0', color: '#666', fontSize: 15, lineHeight: 1.7 }}>A small, curated collection of branded gear made for your team — considered materials, considered fit, considered finish.</p>
        <div style={{ marginTop: 40, fontSize: 12, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#1b1b1b', borderBottom: '1px solid #1b1b1b', paddingBottom: 4, display: 'inline-block' }}>Shop the collection</div>
      </div>

      {/* Single huge image */}
      <div style={{ aspectRatio: '21/9', background: '#fafafa', position: 'relative', margin: '0 64px' }}>
        <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 0 }} />
      </div>

      {/* 2-up showcase */}
      <div style={{ padding: '120px 64px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64 }}>
        <MinimalProduct ratio="3/4" name="Heavyweight Crewneck" price="$48" />
        <MinimalProduct ratio="3/4" name="Insulated Tumbler" price="$24" />
      </div>

      {/* Quote / brand line */}
      <div style={{ padding: '0 64px 120px', textAlign: 'center' }}>
        <div style={{ maxWidth: 640, margin: '0 auto', fontSize: 28, fontWeight: 300, lineHeight: 1.4, color: '#1b1b1b', letterSpacing: -0.01 }}>
          "Less, but better." Every piece earns its place — chosen for the people who wear it.
        </div>
      </div>

      <MinimalFooter />
    </MinimalShell>
  );
}

// ── SHOP ─────────────────────────────────────────────────────────
function MinimalShop() {
  return (
    <MinimalShell>
      <div style={{ padding: '64px 64px 48px', textAlign: 'center' }}>
        <div style={{ fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', color: '#999', marginBottom: 16 }}>Collection</div>
        <h1 style={{ fontSize: 48, fontWeight: 300, margin: 0, letterSpacing: -0.01 }}>All products</h1>
      </div>
      {/* Filter row */}
      <div style={{ padding: '0 64px 32px', display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid #f0f0f0', paddingBottom: 16, fontSize: 11, letterSpacing: '0.16em', textTransform: 'uppercase', color: '#666' }}>
        <div style={{ display: 'flex', gap: 32 }}>
          <span style={{ color: '#1b1b1b' }}>All</span>
          <span>Apparel</span>
          <span>Headwear</span>
          <span>Drinkware</span>
          <span>Bags</span>
        </div>
        <div>Sort · Featured</div>
      </div>
      {/* 2-column generous grid */}
      <div style={{ padding: '64px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64 }}>
        {Array.from({ length: 6 }).map((_, i) => (
          <MinimalProduct key={i} ratio="4/5" name={['Heavyweight Crewneck','Logo Cap','Insulated Tumbler','Canvas Tote','Wool Beanie','Field Notebook'][i]} price={['$48','$28','$24','$36','$32','$18'][i]} />
        ))}
      </div>
      {/* Load more */}
      <div style={{ textAlign: 'center', padding: '0 0 80px', fontSize: 12, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
        <span style={{ borderBottom: '1px solid #1b1b1b', paddingBottom: 4 }}>Load more</span>
      </div>
      <MinimalFooter />
    </MinimalShell>
  );
}

// ── CART ─────────────────────────────────────────────────────────
function MinimalCart() {
  const b = React.useContext(BrandContext);
  const items = [
    { name: 'Heavyweight Crewneck', meta: 'Black · Size L', q: 2, p: 48 },
    { name: 'Logo Cap', meta: 'Navy', q: 1, p: 28 },
    { name: 'Insulated Tumbler', meta: 'Steel · 20oz', q: 4, p: 24 },
  ];
  const subtotal = items.reduce((a, i) => a + i.p * i.q, 0);
  return (
    <MinimalShell>
      <div style={{ padding: '64px 64px 32px', textAlign: 'center' }}>
        <div style={{ fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', color: '#999', marginBottom: 12 }}>Your bag</div>
        <h1 style={{ fontSize: 36, fontWeight: 300, margin: 0 }}>3 items</h1>
      </div>
      <div style={{ padding: '0 64px 80px', display: 'grid', gridTemplateColumns: '1fr 380px', gap: 80 }}>
        <div>
          {items.map((it, i) => (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: '120px 1fr auto', gap: 24, padding: '32px 0', borderBottom: '1px solid #f0f0f0', alignItems: 'center' }}>
              <div style={{ aspectRatio: '1/1', background: '#fafafa', position: 'relative' }}>
                <Ph style={{ position: 'absolute', inset: 0, border: 'none' }} />
              </div>
              <div>
                <div style={{ fontSize: 16, marginBottom: 6 }}>{it.name}</div>
                <div style={{ fontSize: 12, color: '#999', marginBottom: 16, letterSpacing: '0.04em' }}>{it.meta}</div>
                <div style={{ display: 'flex', gap: 20, fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#666' }}>
                  <span>− {it.q} +</span>
                  <span style={{ borderBottom: '1px solid #999' }}>Remove</span>
                </div>
              </div>
              <div style={{ fontSize: 14, color: '#1b1b1b' }}>${(it.p * it.q).toFixed(2)}</div>
            </div>
          ))}
        </div>
        <div style={{ alignSelf: 'start', position: 'sticky', top: 32 }}>
          <div style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#1b1b1b', marginBottom: 24 }}>Summary</div>
          {[['Subtotal',`$${subtotal.toFixed(2)}`],['Shipping','$12.00'],['Tax','$13.92']].map(([l,v])=>(
            <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', fontSize: 13, color: '#666', borderBottom: '1px solid #f5f5f5' }}><span>{l}</span><span>{v}</span></div>
          ))}
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '20px 0', fontSize: 16, color: '#1b1b1b' }}><span>Total</span><span>${(subtotal+12+13.92).toFixed(2)}</span></div>
          <button style={{ width: '100%', padding: '18px 0', background: '#1b1b1b', color: '#fff', border: 'none', fontSize: 12, fontWeight: 400, letterSpacing: '0.18em', textTransform: 'uppercase', cursor: 'pointer', marginTop: 16 }}>Checkout</button>
          <div style={{ textAlign: 'center', marginTop: 20, fontSize: 11, letterSpacing: '0.16em', textTransform: 'uppercase', color: '#999' }}>Continue shopping</div>
        </div>
      </div>
      <MinimalFooter />
    </MinimalShell>
  );
}

// ── CHECKOUT ─────────────────────────────────────────────────────
function MinimalCheckout() {
  const Field = ({ label, ph, half = false }) => (
    <div style={{ flex: half ? 1 : '1 1 100%', minWidth: half ? 0 : '100%', marginBottom: 24 }}>
      <div style={{ fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#999', marginBottom: 8 }}>{label}</div>
      <input placeholder={ph} style={{ width: '100%', boxSizing: 'border-box', border: 'none', borderBottom: '1px solid #ddd', padding: '8px 0', fontSize: 14, fontFamily: 'inherit', background: 'transparent', outline: 'none' }} />
    </div>
  );
  return (
    <MinimalShell>
      <div style={{ padding: '64px 64px 32px', textAlign: 'center' }}>
        <div style={{ fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', color: '#999', marginBottom: 12 }}>Step 3 of 3</div>
        <h1 style={{ fontSize: 36, fontWeight: 300, margin: 0 }}>Checkout</h1>
      </div>
      <div style={{ padding: '0 64px 80px', display: 'grid', gridTemplateColumns: '1fr 380px', gap: 80 }}>
        <div>
          <div style={{ fontSize: 11, letterSpacing: '0.2em', textTransform: 'uppercase', color: '#1b1b1b', marginBottom: 28 }}>Contact</div>
          <Field label="Email" ph="you@company.com" />
          <Field label="Phone" ph="+1 ···" />

          <div style={{ fontSize: 11, letterSpacing: '0.2em', textTransform: 'uppercase', color: '#1b1b1b', margin: '40px 0 28px' }}>Shipping</div>
          <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap' }}>
            <Field label="First name" ph="" half />
            <Field label="Last name" ph="" half />
            <Field label="Address" ph="" />
            <Field label="City" ph="" half />
            <Field label="State" ph="" half />
            <Field label="ZIP" ph="" half />
            <Field label="Country" ph="" half />
          </div>

          <div style={{ fontSize: 11, letterSpacing: '0.2em', textTransform: 'uppercase', color: '#1b1b1b', margin: '40px 0 28px' }}>Payment</div>
          <Field label="Card number" ph="•••• •••• •••• ••••" />
          <div style={{ display: 'flex', gap: 24 }}>
            <Field label="Expiry" ph="MM / YY" half />
            <Field label="CVC" ph="123" half />
          </div>
        </div>
        <div style={{ alignSelf: 'start', position: 'sticky', top: 32 }}>
          <div style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#1b1b1b', marginBottom: 24 }}>Order</div>
          {[['Crewneck × 2','$96.00'],['Logo Cap','$28.00'],['Tumbler × 4','$96.00']].map(([l,v])=>(
            <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', fontSize: 13, color: '#666', borderBottom: '1px solid #f5f5f5' }}><span>{l}</span><span>{v}</span></div>
          ))}
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', fontSize: 13, color: '#666' }}><span>Shipping</span><span>$12.00</span></div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', fontSize: 13, color: '#666' }}><span>Tax</span><span>$18.56</span></div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '20px 0', fontSize: 16, color: '#1b1b1b', borderTop: '1px solid #1b1b1b', marginTop: 8 }}><span>Total</span><span>$250.56</span></div>
          <button style={{ width: '100%', padding: '18px 0', background: '#1b1b1b', color: '#fff', border: 'none', fontSize: 12, fontWeight: 400, letterSpacing: '0.18em', textTransform: 'uppercase', cursor: 'pointer', marginTop: 16 }}>Place order</button>
        </div>
      </div>
      <MinimalFooter />
    </MinimalShell>
  );
}

// ── CUSTOM REQUEST ──────────────────────────────────────────────
function MinimalCustomRequest() {
  const Field = ({ label, ph, full = false }) => (
    <div style={{ gridColumn: full ? '1 / -1' : 'auto', marginBottom: 32 }}>
      <div style={{ fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#999', marginBottom: 8 }}>{label}</div>
      <input placeholder={ph} style={{ width: '100%', boxSizing: 'border-box', border: 'none', borderBottom: '1px solid #ddd', padding: '8px 0', fontSize: 14, fontFamily: 'inherit', background: 'transparent', outline: 'none' }} />
    </div>
  );
  return (
    <MinimalShell>
      <div style={{ padding: '120px 64px 64px', textAlign: 'center' }}>
        <div style={{ fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', color: '#999', marginBottom: 16 }}>Bespoke</div>
        <h1 style={{ fontSize: 56, fontWeight: 300, margin: 0, letterSpacing: -0.01 }}>A custom<br />request.</h1>
        <p style={{ maxWidth: 460, margin: '24px auto 0', color: '#666', fontSize: 14, lineHeight: 1.7 }}>Tell us what you have in mind. We'll respond within two business days with options and a considered quote.</p>
      </div>
      <div style={{ padding: '0 64px 80px', maxWidth: 720, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 32px' }}>
          <Field label="Project name" ph="Summit Conference 2026" full />
          <Field label="Quantity" ph="500" />
          <Field label="Budget" ph="$15,000" />
          <Field label="Need by" ph="Mar 15, 2026" />
          <Field label="Reference link" ph="https://" />
          <div style={{ gridColumn: '1 / -1', marginBottom: 32 }}>
            <div style={{ fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#999', marginBottom: 8 }}>Tell us more</div>
            <textarea rows={5} placeholder="Materials, fit, decoration, finish…" style={{ width: '100%', boxSizing: 'border-box', border: 'none', borderBottom: '1px solid #ddd', padding: '8px 0', fontSize: 14, fontFamily: 'inherit', background: 'transparent', outline: 'none', resize: 'vertical' }} />
          </div>
          <div style={{ gridColumn: '1 / -1', marginBottom: 32 }}>
            <div style={{ fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#999', marginBottom: 12 }}>Reference materials</div>
            <div style={{ borderTop: '1px solid #ddd', borderBottom: '1px solid #ddd', padding: '32px 0', textAlign: 'center', fontSize: 12, color: '#999', letterSpacing: '0.06em' }}>Drop files or browse — PNG, JPG, AI, PDF</div>
          </div>
        </div>
        <div style={{ marginTop: 24, textAlign: 'center' }}>
          <button style={{ padding: '18px 56px', background: '#1b1b1b', color: '#fff', border: 'none', fontSize: 12, letterSpacing: '0.18em', textTransform: 'uppercase' }}>Submit request</button>
        </div>
      </div>
      <MinimalFooter />
    </MinimalShell>
  );
}

Object.assign(window, { MinimalHome, MinimalShop, MinimalCart, MinimalCheckout, MinimalCustomRequest });
