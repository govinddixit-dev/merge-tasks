/* global React, Icon, BrandContext, BrandedNav, BrandedFooterCompact, RingLogo */
// Portal screens — Sign In, Overview, Proposals, Orders, Print, Team
// Mid-fi, Most-aesthetic structure (rounded cards, large weight, subtle accent threads)

const TAB_DEFS = [
  { k: 'overview',  l: 'Overview',  i: 'grid' },
  { k: 'proposals', l: 'Proposals', i: 'list' },
  { k: 'orders',    l: 'Orders',    i: 'cart' },
  { k: 'print',     l: 'Print',     i: 'image' },
  { k: 'team',      l: 'Team',      i: 'user' },
];

function PortalShell({ active = 'overview', children, userName = 'Yan', subtitle = 'Administrator' }) {
  const b = React.useContext(BrandContext);
  return (
    <div style={{ background: '#fff', minHeight: '100%', fontFamily: '"Inter Tight", sans-serif', display: 'flex', flexDirection: 'column' }}>
      <BrandedNav active="PORTAL" signedIn userName={userName} cartCount={0} />
      <div style={{ flex: 1, padding: '32px 48px 48px' }}>
        {/* Welcome header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 24 }}>
          <div style={{
            width: 44, height: 44, borderRadius: 10, background: b.pill, color: '#fff',
            display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 18,
          }}>{userName[0]}</div>
          <div>
            <div style={{ fontSize: 22, fontWeight: 700, color: '#1b1b1b', letterSpacing: -0.01 }}>Welcome back, {userName}</div>
            <div style={{ fontSize: 13, color: b.logoColor, marginTop: 2 }}>{b.name} · {subtitle}</div>
          </div>
        </div>
        {/* Tabs */}
        <div style={{
          display: 'grid', gridTemplateColumns: `repeat(${TAB_DEFS.length}, 1fr)`,
          background: '#f4f4f5', borderRadius: 10, padding: 4, marginBottom: 28,
        }}>
          {TAB_DEFS.map(t => (
            <button key={t.k} style={{
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              padding: '10px 14px', borderRadius: 8,
              background: active === t.k ? '#fff' : 'transparent',
              border: 'none', cursor: 'pointer',
              fontSize: 13, fontWeight: 600,
              color: active === t.k ? '#1b1b1b' : '#666',
              boxShadow: active === t.k ? '0 1px 2px rgba(0,0,0,0.06)' : 'none',
            }}>
              <Icon name={t.i} size={14} stroke={1.8} />
              {t.l}
            </button>
          ))}
        </div>
        {children}
      </div>
      <BrandedFooterCompact />
    </div>
  );
}

// ── Sign In ────────────────────────────────────────────────
function PortalSignIn() {
  const b = React.useContext(BrandContext);
  const [tab, setTab] = React.useState('email');
  return (
    <div style={{ background: '#fff', minHeight: '100%', fontFamily: '"Inter Tight", sans-serif', display: 'flex', flexDirection: 'column' }}>
      <BrandedNav active="PORTAL" signedIn={false} cartCount={0} />
      <div style={{ flex: 1, display: 'grid', placeItems: 'center', padding: '60px 24px' }}>
        <div style={{ width: 460, maxWidth: '100%', textAlign: 'center' }}>
          <div style={{
            width: 48, height: 48, borderRadius: 10, background: b.pill, color: '#fff',
            display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 20,
            margin: '0 auto 18px',
          }}>{b.short}</div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: '#1b1b1b', margin: 0 }}>
            Sign in to <span style={{ color: b.logoColor }}>{b.name}</span>
          </h1>
          <div style={{ fontSize: 13, color: '#999', marginTop: 6 }}>Choose how you'd like to sign in</div>

          <div style={{
            marginTop: 22, padding: 22,
            border: '1px solid #ececec', borderRadius: 12, textAlign: 'left',
            background: '#fff',
          }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', background: '#f4f4f5', borderRadius: 8, padding: 4, marginBottom: 18 }}>
              {[['email','Email Code'],['pwd','Password']].map(([k,l]) => (
                <button key={k} onClick={()=>setTab(k)} style={{
                  padding: '8px 12px', borderRadius: 6, border: 'none',
                  background: tab===k ? b.pill : 'transparent',
                  color: tab===k ? '#fff' : '#666',
                  fontSize: 13, fontWeight: 600, cursor: 'pointer',
                }}>{l}</button>
              ))}
            </div>

            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#1b1b1b', marginBottom: 6 }}>Full Name</div>
              <input placeholder="John Doe" style={{
                width: '100%', boxSizing: 'border-box', padding: '10px 12px',
                border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 13, color: '#999', background: '#fff',
              }} />
            </div>
            <div style={{ marginBottom: 18 }}>
              <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6 }}>
                <span style={{ color: b.logoColor }}>Email</span> <span style={{ color: '#1b1b1b' }}>Address</span>
              </div>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#bbb' }}>
                  <Icon name="info" size={14} />
                </span>
                <input placeholder={tab==='email' ? 'you@company.com' : '••••••••'} type={tab==='email'?'text':'password'} style={{
                  width: '100%', boxSizing: 'border-box', padding: '10px 12px 10px 34px',
                  border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 13, color: '#999', background: '#fff',
                }} />
              </div>
            </div>
            <button style={{
              width: '100%', background: b.pill, color: '#fff', border: 'none',
              padding: '12px', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer',
            }}>Continue with {tab==='email'?'Email':'Password'}</button>
            <div style={{ fontSize: 11, color: '#bbb', textAlign: 'center', marginTop: 12 }}>
              ⓘ Enterprise SSO is automatically detected by your email domain.
            </div>
          </div>

          <div style={{ marginTop: 18, fontSize: 11, color: '#bbb' }}>
            Powered by <span style={{ color: b.logoColor }}>MergeTasks Enterprise Platform</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Overview ───────────────────────────────────────────────
const KPI = ({ icon, iconBg, iconColor, value, label }) => (
  <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: 18, background: '#fff' }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
      <div style={{ width: 32, height: 32, borderRadius: 8, background: iconBg, color: iconColor, display: 'grid', placeItems: 'center' }}>
        <Icon name={icon} size={16} stroke={1.8} />
      </div>
      <div style={{ color: '#22c55e' }}>↗</div>
    </div>
    <div style={{ fontSize: 28, fontWeight: 700, color: '#1b1b1b', letterSpacing: -0.02 }}>{value}</div>
    <div style={{ fontSize: 12, color: '#999', marginTop: 4 }}>{label}</div>
  </div>
);

function PortalOverview() {
  const b = React.useContext(BrandContext);
  return (
    <PortalShell active="overview">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        <KPI icon="list" iconBg="#dbeafe" iconColor="#2563eb" value="2"     label="Active Proposals" />
        <KPI icon="info" iconBg="#fed7aa" iconColor="#ea580c" value="0"     label="Pending Approvals" />
        <KPI icon="info" iconBg="#ede9fe" iconColor="#7c3aed" value="0"     label="Pending Orders" />
        <KPI icon="check" iconBg="#dcfce7" iconColor="#16a34a" value="$0.00" label="Total Spent" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
        {/* Recent Proposals */}
        <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#1b1b1b' }}>Recent Proposals</h3>
            <span style={{ fontSize: 12, color: '#999' }}>3 total</span>
          </div>
          {[
            { t: 'Test 3', d: 'Apr 14, 2026 · $0.00', s: 'ACCEPTED', c: '#16a34a', bg: '#dcfce7' },
            { t: 'Test 2', d: 'Apr 16, 2026 · $0.00', s: 'SENT',     c: '#2563eb', bg: '#dbeafe' },
            { t: 'Test 1', d: 'Apr 16, 2026 · $0.00', s: 'SENT',     c: '#2563eb', bg: '#dbeafe' },
          ].map((p,i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', padding: '10px 0', borderTop: i>0?'1px solid #f4f4f5':'none' }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#1b1b1b' }}>{p.t}</div>
                <div style={{ fontSize: 12, color: b.logoColor, marginTop: 2 }}>{p.d}</div>
              </div>
              <div style={{ flex: 1 }} />
              <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', padding: '4px 8px', borderRadius: 4, color: p.c, background: p.bg }}>{p.s}</span>
            </div>
          ))}
        </div>
        {/* Recent Orders */}
        <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#1b1b1b' }}>Recent Orders</h3>
            <span style={{ fontSize: 12, color: '#999' }}>0 total</span>
          </div>
          <div style={{ padding: '40px 0', textAlign: 'center', color: '#bbb' }}>
            <Icon name="cart" size={28} stroke={1.4} />
            <div style={{ marginTop: 10, fontSize: 13 }}>No orders yet</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: 20 }}>
        <h3 style={{ margin: '0 0 14px', fontSize: 15, fontWeight: 700, color: '#1b1b1b' }}>Quick Actions</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12 }}>
          {[
            { i: 'bag',   t: 'Browse Store',    s: 'Shop products' },
            { i: 'list',  t: 'View Proposals',  s: 'Review & approve', acc: true },
            { i: 'cart',  t: 'Order History',   s: 'Track orders' },
            { i: 'image', t: 'Print Request',   s: 'Submit request' },
          ].map((a,i) => (
            <div key={i} style={{
              border: '1px solid #ececec', borderRadius: 10, padding: 14,
              cursor: 'pointer',
            }}>
              <Icon name={a.i} size={18} stroke={1.6} />
              <div style={{ fontSize: 13, fontWeight: 600, marginTop: 8, color: '#1b1b1b' }}>{a.t}</div>
              <div style={{ fontSize: 11, color: a.acc ? b.logoColor : '#999', marginTop: 2 }}>{a.s}</div>
            </div>
          ))}
        </div>
      </div>
    </PortalShell>
  );
}

// ── Proposals (list) ───────────────────────────────────────
function PortalProposals() {
  const b = React.useContext(BrandContext);
  const rows = [
    { t: 'Test 3', d: '1 product · $0.00 · Apr 14, 2026', s: 'ACCEPTED', c: '#16a34a', bg: '#dcfce7', extra: 'FULFILLMENT SENT' },
    { t: 'Test 2', d: '1 product · $0.00 · Apr 16, 2026', s: 'SENT',     c: '#2563eb', bg: '#dbeafe', extra: 'FULFILLMENT SENT' },
    { t: 'Test 1', d: '1 product · $0.00 · Apr 16, 2026', s: 'SENT',     c: '#2563eb', bg: '#dbeafe' },
  ];
  return (
    <PortalShell active="proposals">
      <div style={{ display: 'flex', gap: 12, marginBottom: 18 }}>
        <div style={{ flex: 1, position: 'relative' }}>
          <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: '#999' }}>
            <Icon name="search" size={14} />
          </span>
          <input placeholder="Search proposals..." style={{
            width: '100%', boxSizing: 'border-box', padding: '10px 12px 10px 36px',
            border: '1px solid #ececec', borderRadius: 8, fontSize: 13, background: '#fff',
          }} />
        </div>
        <select style={{ border: '1px solid #ececec', borderRadius: 8, padding: '8px 28px 8px 12px', fontSize: 13, background: '#fff' }}>
          <option>All Statuses</option>
        </select>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {rows.map((p,i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 14,
            border: '1px solid #ececec', borderRadius: 10, padding: '14px 18px',
          }}>
            <div style={{ width: 36, height: 36, borderRadius: 8, background: '#f4f4f5', display: 'grid', placeItems: 'center', color: '#999' }}>
              <Icon name="list" size={16} />
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#1b1b1b' }}>{p.t}</div>
              <div style={{ fontSize: 12, color: '#999', marginTop: 2 }}>{p.d}</div>
            </div>
            <div style={{ flex: 1 }} />
            <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', padding: '4px 8px', borderRadius: 4, color: p.c, background: p.bg }}>{p.s}</span>
            {p.extra && <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', padding: '4px 8px', borderRadius: 4, color: '#ea580c', background: '#fed7aa' }}>{p.extra}</span>}
            <Icon name="chevDown" size={14} />
          </div>
        ))}
      </div>
    </PortalShell>
  );
}

// ── Proposal Detail ───────────────────────────────────────
function PortalProposalDetail() {
  const b = React.useContext(BrandContext);
  return (
    <PortalShell active="proposals">
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16, fontSize: 12, color: '#999' }}>
        <a style={{ cursor: 'pointer', color: b.logoColor }}>← Back to Proposals</a>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 24 }}>
        <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Test 3</h2>
            <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', padding: '4px 8px', borderRadius: 4, color: '#16a34a', background: '#dcfce7' }}>ACCEPTED</span>
          </div>
          <div style={{ fontSize: 12, color: '#999' }}>Apr 14, 2026 · From {b.name}</div>

          <div style={{ marginTop: 24 }}>
            <h3 style={{ fontSize: 13, fontWeight: 700, color: '#1b1b1b', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 12px' }}>Line items</h3>
            <div style={{ border: '1px solid #f1f1f1', borderRadius: 10, overflow: 'hidden' }}>
              {[
                { p: 'Polo Shirt — Navy, M', q: 24, u: '$18.00', t: '$432.00' },
                { p: 'Embroidery — Front',  q: 24, u: '$3.50',  t: '$84.00' },
              ].map((r,i) => (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 60px 80px 80px', padding: '12px 16px', borderTop: i>0?'1px solid #f1f1f1':'none', fontSize: 13, alignItems: 'center' }}>
                  <div style={{ fontWeight: 500 }}>{r.p}</div>
                  <div style={{ color: '#999' }}>×{r.q}</div>
                  <div style={{ color: '#999' }}>{r.u}</div>
                  <div style={{ fontWeight: 600, textAlign: 'right' }}>{r.t}</div>
                </div>
              ))}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 80px', padding: '14px 16px', background: '#fafafa', fontSize: 14, fontWeight: 700, alignItems: 'center' }}>
                <div>Total</div>
                <div style={{ textAlign: 'right' }}>$516.00</div>
              </div>
            </div>
          </div>
        </div>

        <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: 18, height: 'fit-content' }}>
          <h3 style={{ fontSize: 13, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 12px' }}>Actions</h3>
          <button style={{ width: '100%', background: b.pill, color: '#fff', border: 'none', padding: 12, borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer', marginBottom: 8 }}>Convert to order</button>
          <button style={{ width: '100%', background: '#fff', color: '#1b1b1b', border: '1px solid #ececec', padding: 12, borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer', marginBottom: 8 }}>Download PDF</button>
          <button style={{ width: '100%', background: '#fff', color: '#1b1b1b', border: '1px solid #ececec', padding: 12, borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Request changes</button>
        </div>
      </div>
    </PortalShell>
  );
}

// ── Orders (empty) ────────────────────────────────────────
function PortalOrders() {
  return (
    <PortalShell active="orders">
      <select style={{ border: '1px solid #ececec', borderRadius: 8, padding: '8px 28px 8px 12px', fontSize: 13, marginBottom: 18, background: '#fff' }}>
        <option>All Statuses</option>
      </select>
      <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: '60px 24px', textAlign: 'center', color: '#bbb' }}>
        <Icon name="cart" size={32} stroke={1.4} />
        <div style={{ marginTop: 12, fontSize: 14, fontWeight: 600, color: '#666' }}>No orders found</div>
        <div style={{ marginTop: 4, fontSize: 12 }}>Orders placed through the store will appear here</div>
      </div>
    </PortalShell>
  );
}

// ── Order Detail (filled) ─────────────────────────────────
function PortalOrderDetail() {
  const b = React.useContext(BrandContext);
  return (
    <PortalShell active="orders">
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16, fontSize: 12, color: '#999' }}>
        <a style={{ cursor: 'pointer', color: b.logoColor }}>← Back to Orders</a>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 24 }}>
        <div>
          <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: 24, marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Order #1024</h2>
              <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', padding: '4px 8px', borderRadius: 4, color: '#ea580c', background: '#fed7aa' }}>IN PRODUCTION</span>
            </div>
            <div style={{ fontSize: 12, color: '#999', marginTop: 4 }}>Placed Apr 12, 2026 · ETA Apr 24</div>

            <div style={{ marginTop: 20, display: 'flex', gap: 0, alignItems: 'center', position: 'relative' }}>
              {['Placed','Approved','In production','Shipped','Delivered'].map((s, i) => (
                <React.Fragment key={s}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1 }}>
                    <div style={{
                      width: 24, height: 24, borderRadius: 999,
                      background: i <= 2 ? b.logoColor : '#e5e7eb',
                      color: '#fff', display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 700,
                    }}>{i+1}</div>
                    <div style={{ fontSize: 10, fontWeight: 600, color: i <= 2 ? '#1b1b1b' : '#999', marginTop: 6 }}>{s}</div>
                  </div>
                  {i < 4 && <div style={{ height: 2, flex: 1, background: i < 2 ? b.logoColor : '#e5e7eb', alignSelf: 'flex-start', marginTop: 11 }} />}
                </React.Fragment>
              ))}
            </div>
          </div>

          <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: 24 }}>
            <h3 style={{ fontSize: 13, fontWeight: 700, color: '#1b1b1b', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 12px' }}>Items</h3>
            {[
              { p: 'Polo Shirt — Navy', sub: 'Sizes M(12) L(8) XL(4)', q: 24, t: '$432.00' },
              { p: 'Embroidery — Front', sub: 'Logo file uploaded', q: 24, t: '$84.00' },
            ].map((r,i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 0', borderTop: i>0?'1px solid #f4f4f5':'none' }}>
                <div style={{ width: 48, height: 48, borderRadius: 10, background: '#f4f4f5', display: 'grid', placeItems: 'center', color: '#999' }}>
                  <Icon name="image" size={18} />
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{r.p}</div>
                  <div style={{ fontSize: 12, color: '#999' }}>{r.sub}</div>
                </div>
                <div style={{ flex: 1 }} />
                <div style={{ fontSize: 13, color: '#999' }}>×{r.q}</div>
                <div style={{ fontSize: 14, fontWeight: 600, width: 80, textAlign: 'right' }}>{r.t}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: 18, height: 'fit-content' }}>
          <h3 style={{ fontSize: 13, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 12px' }}>Summary</h3>
          {[['Subtotal','$516.00'],['Shipping','$24.00'],['Tax','$0.00']].map(([k,v]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '6px 0', color: '#666' }}>
              <span>{k}</span><span>{v}</span>
            </div>
          ))}
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 15, fontWeight: 700, padding: '12px 0', borderTop: '1px solid #f1f1f1', marginTop: 6 }}>
            <span>Total</span><span>$540.00</span>
          </div>
          <button style={{ width: '100%', background: b.pill, color: '#fff', border: 'none', padding: 12, borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer', marginTop: 12 }}>Track shipment</button>
        </div>
      </div>
    </PortalShell>
  );
}

// ── Print Requests (empty + new modal hint) ───────────────
function PortalPrint() {
  const b = React.useContext(BrandContext);
  return (
    <PortalShell active="print">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
        <div>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#1b1b1b' }}>Print Requests</div>
          <div style={{ fontSize: 13, color: b.logoColor }}>Submit print and decoration requests to your distributor</div>
        </div>
        <button style={{ background: b.pill, color: '#fff', border: 'none', padding: '10px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          <Icon name="plus" size={14} stroke={2.2} /> New Request
        </button>
      </div>
      <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: '60px 24px', textAlign: 'center', color: '#bbb' }}>
        <Icon name="image" size={30} stroke={1.4} />
        <div style={{ marginTop: 12, fontSize: 14, fontWeight: 600, color: '#666' }}>No print requests</div>
        <div style={{ marginTop: 4, fontSize: 12, color: b.logoColor }}>Click "New Request" to submit your first print order</div>
      </div>
    </PortalShell>
  );
}

// ── Print New Request (form) ──────────────────────────────
function PortalPrintNew() {
  const b = React.useContext(BrandContext);
  return (
    <PortalShell active="print">
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16, fontSize: 12, color: b.logoColor }}>
        <a style={{ cursor: 'pointer' }}>← Back</a>
      </div>
      <div style={{ border: '1px solid #ececec', borderRadius: 14, padding: 24, maxWidth: 720 }}>
        <h2 style={{ margin: '0 0 6px', fontSize: 20, fontWeight: 700 }}>New Print Request</h2>
        <div style={{ fontSize: 13, color: '#999', marginBottom: 22 }}>Provide artwork and decoration details. Your distributor will quote within 24h.</div>

        {[
          { l: 'Project name', t: 'input', p: 'Spring 2026 Hoodies' },
          { l: 'Decoration type', t: 'select', o: ['Embroidery','Screen print','DTG','Heat transfer'] },
          { l: 'Garment(s)', t: 'select', o: ['From cart (3 items)','Pick from store','Customer-supplied'] },
          { l: 'Placement', t: 'select', o: ['Left chest','Full front','Back','Sleeve'] },
          { l: 'Quantity', t: 'input', p: '24' },
          { l: 'Notes', t: 'textarea', p: 'PMS colors, ink type, etc.' },
        ].map((f,i) => (
          <div key={i} style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: '#1b1b1b', marginBottom: 6 }}>{f.l}</div>
            {f.t === 'input' && <input placeholder={f.p} style={{ width: '100%', boxSizing: 'border-box', padding: '10px 12px', border: '1px solid #ececec', borderRadius: 8, fontSize: 13 }} />}
            {f.t === 'textarea' && <textarea placeholder={f.p} rows={3} style={{ width: '100%', boxSizing: 'border-box', padding: '10px 12px', border: '1px solid #ececec', borderRadius: 8, fontSize: 13, resize: 'vertical' }} />}
            {f.t === 'select' && <select style={{ width: '100%', padding: '10px 12px', border: '1px solid #ececec', borderRadius: 8, fontSize: 13, background: '#fff' }}>{f.o.map(o=><option key={o}>{o}</option>)}</select>}
          </div>
        ))}

        <div style={{ marginBottom: 22 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#1b1b1b', marginBottom: 6 }}>Artwork</div>
          <div style={{ border: '1.5px dashed #d4d4d4', borderRadius: 10, padding: 24, textAlign: 'center', color: '#999' }}>
            <Icon name="image" size={22} />
            <div style={{ fontSize: 13, marginTop: 6 }}>Drop AI / EPS / PDF here, or <a style={{ color: b.logoColor, cursor: 'pointer' }}>browse</a></div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <button style={{ background: '#fff', color: '#1b1b1b', border: '1px solid #ececec', padding: '10px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Cancel</button>
          <button style={{ background: b.pill, color: '#fff', border: 'none', padding: '10px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Submit Request</button>
        </div>
      </div>
    </PortalShell>
  );
}

// ── Team ──────────────────────────────────────────────────
function PortalTeam() {
  const b = React.useContext(BrandContext);
  return (
    <PortalShell active="team">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
        <div>
          <div style={{ fontSize: 16, fontWeight: 700 }}>Team Members</div>
          <div style={{ fontSize: 12, color: '#999' }}>2 members across 2 departments</div>
        </div>
        <button style={{ background: b.pill, color: '#fff', border: 'none', padding: '10px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          <Icon name="plus" size={14} stroke={2.2} /> Add Member
        </button>
      </div>

      {[
        { dept: 'No Department', members: [{ n: 'Yan Charitar', e: 'info@yan-financial.ca', tags: [['ADMIN','#666','#e5e7eb'],['ACTIVE','#0369a1','#e0f2fe']] }] },
        { dept: 'marketing',     members: [{ n: 'Yan Charitar', e: 'info@yanfinancial.ca',   tags: [['ADMIN','#666','#e5e7eb'],['SUSPENDED','#ea580c','#fed7aa']] }] },
      ].map((g,gi) => (
        <div key={gi} style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 16px', background: '#fafafa', borderRadius: 10, marginBottom: 8 }}>
            <Icon name="user" size={14} />
            <span style={{ fontSize: 13, fontWeight: 600 }}>{g.dept}</span>
            <span style={{ fontSize: 12, color: '#999' }}>({g.members.length})</span>
          </div>
          {g.members.map((m,mi) => (
            <div key={mi} style={{ display: 'flex', alignItems: 'center', gap: 12, border: '1px solid #ececec', borderRadius: 10, padding: '12px 16px' }}>
              <div style={{ width: 36, height: 36, borderRadius: 999, background: b.pill, color: '#fff', display: 'grid', placeItems: 'center', fontSize: 13, fontWeight: 700 }}>{m.n[0]}</div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{m.n}</div>
                <div style={{ fontSize: 12, color: '#999' }}>{m.e}</div>
              </div>
              <div style={{ flex: 1 }} />
              {m.tags.map(([t,c,bg]) => (
                <span key={t} style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', padding: '4px 8px', borderRadius: 4, color: c, background: bg }}>{t}</span>
              ))}
              <button style={{ background: 'transparent', border: 'none', color: '#999', cursor: 'pointer', padding: 4 }}>
                <Icon name="trash" size={14} />
              </button>
            </div>
          ))}
        </div>
      ))}
    </PortalShell>
  );
}

Object.assign(window, {
  PortalSignIn, PortalOverview, PortalProposals, PortalProposalDetail,
  PortalOrders, PortalOrderDetail, PortalPrint, PortalPrintNew, PortalTeam,
});
