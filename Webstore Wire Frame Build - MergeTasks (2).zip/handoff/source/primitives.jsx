/* global React */
// Shared primitives: icons, placeholders, header, footer

const Icon = ({ name, size = 18, stroke = 1.6 }) => {
  const paths = {
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></>,
    cart: <><path d="M3 3h2l2.5 12.5a2 2 0 0 0 2 1.5h8a2 2 0 0 0 2-1.5L22 7H6"/><circle cx="10" cy="20" r="1.2"/><circle cx="18" cy="20" r="1.2"/></>,
    sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></>,
    moon: <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    minus: <path d="M5 12h14"/>,
    filter: <path d="M3 5h18M6 12h12M10 19h4"/>,
    grid: <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></>,
    list: <><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/></>,
    chevDown: <path d="m6 9 6 6 6-6"/>,
    chevRight: <path d="m9 6 6 6-6 6"/>,
    x: <path d="M6 6l12 12M18 6 6 18"/>,
    heart: <path d="M12 21s-7-4.35-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.65-7 10-7 10z"/>,
    menu: <path d="M3 6h18M3 12h18M3 18h18"/>,
    check: <path d="M4 12l5 5L20 6"/>,
    bag: <><path d="M6 7h12l-1 13H7zM9 7a3 3 0 1 1 6 0"/></>,
    image: <><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></>,
    info: <><circle cx="12" cy="12" r="10"/><path d="M12 11v5M12 8h.01"/></>,
    trash: <><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M6 6l1 14h10l1-14"/></>,
    star: <path d="m12 2 3 7 7 .5-5.5 5 1.5 7-6-4-6 4 1.5-7L2 9.5 9 9z"/>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
         strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
      {paths[name]}
    </svg>
  );
};

// Placeholder image — square or arbitrary with a diagonal image glyph
const Ph = ({ label, style = {}, ratio }) => {
  const s = { aspectRatio: ratio, ...style };
  return (
    <div className="ph" style={s}>
      <Icon name="image" size={28} stroke={1.2} />
      {label && <div style={{ position: 'absolute', bottom: 8, left: 8, right: 8, textAlign: 'center', fontSize: 10, color: 'var(--ink-4)' }}>{label}</div>}
    </div>
  );
};

// Circular "logo" placeholder
const LogoMark = ({ size = 36 }) => (
  <div className="hdr-logo no-sketch" style={{ width: size, height: size }}>
    <svg width={size*0.55} height={size*0.55} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 7c4 0 4 10 8 10s4-10 8-10"/>
    </svg>
  </div>
);

// Header — shared across all screens
const Header = ({ active = 'shop', showCart = false, cartCount = 2, variant = 'classic', onDarkToggle, dark }) => {
  const nav = ['Shop', 'Collections', 'About', 'Contact'];
  return (
    <div className="hdr">
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <LogoMark />
        <div style={{ fontWeight: 600, letterSpacing: -0.02, fontSize: 15 }}>Storefront</div>
      </div>
      {variant === 'classic' && (
        <div className="hdr-nav">
          {nav.map((n,i) => <a key={n} className={i===0?'active':''}>{n}</a>)}
        </div>
      )}
      {variant === 'mega' && (
        <div className="hdr-nav" style={{ position: 'relative' }}>
          {nav.map((n,i) => (
            <a key={n} className={i===0?'active':''} style={{ display:'flex', alignItems:'center', gap:4 }}>
              {n} <Icon name="chevDown" size={12} stroke={2} />
            </a>
          ))}
        </div>
      )}
      {variant === 'sticky' && (
        <>
          <div className="hdr-nav" style={{ fontSize: 13 }}>
            {nav.map((n,i) => <a key={n} className={i===0?'active':''}>{n}</a>)}
          </div>
          <div style={{ fontSize: 11, color: 'var(--ink-3)', padding: '3px 8px', border: '1px solid var(--border)', borderRadius: 4 }}>Free ship over $50</div>
        </>
      )}
      <div className="hdr-spacer" />
      <div className="hdr-icons">
        {showCart && (
          <button className="icon-btn" title="Cart">
            <Icon name="bag" size={16} />
            <span className="badge">{cartCount}</span>
          </button>
        )}
        <button className="icon-btn" title="Theme" onClick={onDarkToggle}>
          <Icon name={dark ? 'sun' : 'moon'} size={16} />
        </button>
        <button className="icon-btn" title="Search">
          <Icon name="search" size={16} />
        </button>
      </div>
    </div>
  );
};

// Sketchy filter (applied via CSS) — renders once
const RoughFilter = () => (
  <svg width="0" height="0" style={{ position: 'absolute' }} aria-hidden>
    <defs>
      <filter id="roughen">
        <feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves="2" seed="7"/>
        <feDisplacementMap in="SourceGraphic" scale="1.2"/>
      </filter>
    </defs>
  </svg>
);

Object.assign(window, { Icon, Ph, LogoMark, Header, RoughFilter });
