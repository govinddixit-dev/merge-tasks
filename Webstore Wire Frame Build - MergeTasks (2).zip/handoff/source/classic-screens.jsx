/* global React, Icon, Ph, BrandContext, RingLogo */
// CLASSIC template — traditional e-commerce: sidebar category nav,
// dense product grid, utilitarian chrome, no curtain reveal.
// Vibe: Shopify default / mid-2010s catalog. Lives or dies on density + clarity.

const ClassicShell = ({ children }) => {
  const b = React.useContext(BrandContext);
  return (
    <div style={{ width: '100%', height: '100%', background: '#fff', overflow: 'auto', fontFamily: '"Inter Tight", -apple-system, sans-serif' }}>
      {/* Top utility bar */}
      <div style={{ background: '#1b1b1b', color: '#bbb', fontSize: 11, padding: '6px 24px', display: 'flex', justifyContent: 'space-between' }}>
        <span>Free shipping on orders over $150</span>
        <span style={{ display: 'flex', gap: 18 }}>
          <span>Help</span><span>Track Order</span><span>USD ▾</span>
        </span>
      </div>
      {/* Main header */}
      <div style={{ background: '#fff', borderBottom: '1px solid #e5e5e5', padding: '14px 24px', display: 'flex', alignItems: 'center', gap: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <RingLogo size={26} color={b.logoColor} />
          <div style={{ fontSize: 18, fontWeight: 700, color: '#1b1b1b' }}>{b.name}</div>
        </div>
        <div style={{ flex: 1, maxWidth: 520, display: 'flex', alignItems: 'center', gap: 0, border: '1px solid #d4d4d4', borderRadius: 4, padding: '6px 12px', background: '#fff' }}>
          <Icon name="search" size={16} stroke={1.6} />
          <input placeholder="Search products, categories, SKUs…" style={{ border: 'none', outline: 'none', flex: 1, marginLeft: 8, fontSize: 13, fontFamily: 'inherit' }} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18, color: '#444', fontSize: 12 }}>
          <span style={{ display:'flex', alignItems:'center', gap: 6 }}><Icon name="user" size={16} stroke={1.6} /> My Account</span>
          <span style={{ display:'flex', alignItems:'center', gap: 6 }}><Icon name="heart" size={16} stroke={1.6} /> Wishlist</span>
          <span style={{ display:'flex', alignItems:'center', gap: 6, padding: '6px 10px', background: b.accent, color: b.accentInk, borderRadius: 4, fontWeight: 600 }}>
            <Icon name="cart" size={14} stroke={2} /> Cart (2) — $148.00
          </span>
        </div>
      </div>
      {/* Category strip */}
      <div style={{ background: '#fafafa', borderBottom: '1px solid #e5e5e5', padding: '10px 24px', display: 'flex', gap: 24, fontSize: 12, fontWeight: 600, color: '#444', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
        <span style={{ color: b.accent }}>All Products</span>
        <span>Apparel</span>
        <span>Headwear</span>
        <span>Drinkware</span>
        <span>Bags</span>
        <span>Office</span>
        <span>Tech</span>
        <span>New Arrivals</span>
        <span style={{ color: '#c4392b' }}>Sale</span>
      </div>
      {children}
    </div>
  );
};

const ClassicFooter = () => {
  const b = React.useContext(BrandContext);
  const cols = [
    ['Shop', ['All Products','New Arrivals','Best Sellers','Sale','Gift Cards']],
    ['Account', ['Sign In','My Orders','Track Order','Wishlist','Returns']],
    ['Support', ['FAQ','Shipping','Sizing Guide','Contact Us','Help Center']],
    ['About', ['Our Company','Sustainability','Careers','Press','Blog']],
  ];
  return (
    <div style={{ background: '#1b1b1b', color: '#bbb', padding: '40px 24px 20px', fontSize: 12, fontFamily: '"Inter Tight", sans-serif' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr repeat(4, 1fr)', gap: 32, paddingBottom: 32, borderBottom: '1px solid #2a2a2a' }}>
        <div>
          <div style={{ display:'flex', alignItems:'center', gap: 8, marginBottom: 12 }}>
            <RingLogo size={22} color={b.logoColor} />
            <span style={{ color: '#fff', fontWeight: 700, fontSize: 14 }}>{b.name}</span>
          </div>
          <p style={{ margin: 0, lineHeight: 1.55, color: '#999' }}>Your team store, powered by branded gear and merchandise selected for {b.name}.</p>
          <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
            {['IG','FB','TW','YT'].map(s => <div key={s} style={{ width: 28, height: 28, borderRadius: 4, background: '#2a2a2a', display:'grid', placeItems:'center', fontSize:10, color:'#fff', fontWeight:600 }}>{s}</div>)}
          </div>
        </div>
        {cols.map(([h, links]) => (
          <div key={h}>
            <div style={{ color: '#fff', fontWeight: 700, fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 12 }}>{h}</div>
            {links.map(l => <div key={l} style={{ marginBottom: 6, color: '#999' }}>{l}</div>)}
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 16, color: '#666', fontSize: 11 }}>
        <div>©2026 {b.name} · All rights reserved</div>
        <div>Powered by <span style={{ color: '#fff' }}>MergeTasks Enterprise Platform</span></div>
      </div>
    </div>
  );
};

// Sidebar used on Shop page
const ClassicSidebar = () => (
  <aside style={{ width: 220, flexShrink: 0, fontSize: 12, color: '#444' }}>
    {[
      ['Categories', ['Apparel','Headwear','Drinkware','Bags','Office','Tech']],
      ['Filter by price', null],
      ['Brand', ['Champion','Carhartt','Yeti','Patagonia','Nike']],
      ['Color', null],
      ['Size', ['XS','S','M','L','XL','XXL']],
    ].map(([title, items], i) => (
      <div key={i} style={{ marginBottom: 18, paddingBottom: 18, borderBottom: '1px solid #ececec' }}>
        <div style={{ fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.08em', color: '#1b1b1b', marginBottom: 10 }}>{title}</div>
        {title === 'Filter by price' && (
          <>
            <div style={{ height: 4, background: '#e5e5e5', borderRadius: 999, position: 'relative' }}>
              <div style={{ position: 'absolute', left: '15%', right: '40%', top: 0, height: 4, background: '#1b1b1b', borderRadius: 999 }} />
              <div style={{ position: 'absolute', left: '15%', top: -3, width: 10, height: 10, borderRadius: 999, background: '#1b1b1b' }} />
              <div style={{ position: 'absolute', right: '40%', top: -3, width: 10, height: 10, borderRadius: 999, background: '#1b1b1b' }} />
            </div>
            <div style={{ marginTop: 8, fontSize: 11, color: '#666' }}>$15 — $90</div>
          </>
        )}
        {title === 'Color' && (
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {['#1b1b1b','#ffffff','#c4392b','#3a7bd5','#cbb88d','#256d4a','#777'].map(c => (
              <div key={c} style={{ width: 18, height: 18, borderRadius: 999, background: c, border: '1px solid #ddd' }} />
            ))}
          </div>
        )}
        {Array.isArray(items) && items.map(it => (
          <div key={it} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6, fontSize: 12 }}>
            <input type="checkbox" style={{ accentColor: '#1b1b1b' }} /> {it}
          </div>
        ))}
      </div>
    ))}
  </aside>
);

// Tight product card
const ClassicCard = () => {
  const b = React.useContext(BrandContext);
  return (
    <div style={{ border: '1px solid #ececec', borderRadius: 4, overflow: 'hidden', background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <div style={{ aspectRatio: '1/1', background: '#f4f4f5', position: 'relative' }}>
        <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 0 }} />
        <span style={{ position: 'absolute', top: 8, left: 8, background: '#c4392b', color: '#fff', fontSize: 9, fontWeight: 700, letterSpacing: '0.06em', padding: '2px 6px', borderRadius: 2 }}>SALE</span>
      </div>
      <div style={{ padding: 10, fontSize: 12 }}>
        <div style={{ color: '#999', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Apparel</div>
        <div style={{ fontWeight: 600, color: '#1b1b1b', marginBottom: 4, lineHeight: 1.25 }}>Heavyweight Crewneck</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ color: '#1b1b1b', fontWeight: 700 }}>$48.00</span>
          <span style={{ color: '#999', textDecoration: 'line-through', fontSize: 11 }}>$64</span>
        </div>
        <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
          {['#1b1b1b','#777','#c4392b','#256d4a'].map(c => <div key={c} style={{ width: 12, height: 12, borderRadius: 999, background: c, border: '1px solid #ddd' }} />)}
        </div>
        <button style={{ marginTop: 8, width: '100%', padding: '7px 0', background: b.accent, color: b.accentInk, border: 'none', borderRadius: 3, fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', cursor: 'pointer' }}>Add to cart</button>
      </div>
    </div>
  );
};

// ── HOME ─────────────────────────────────────────────────────────
function ClassicHome() {
  const b = React.useContext(BrandContext);
  return (
    <ClassicShell>
      {/* Promo strip hero */}
      <div style={{ background: '#fafafa', padding: '18px 24px', borderBottom: '1px solid #e5e5e5', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: b.accent, letterSpacing: '0.1em', textTransform: 'uppercase' }}>SS26 Collection</div>
          <div style={{ fontSize: 26, fontWeight: 700, color: '#1b1b1b', marginTop: 4 }}>Outfit your team for the season ahead</div>
          <div style={{ fontSize: 12, color: '#666', marginTop: 4 }}>Free shipping on orders $150+ · 50+ new arrivals this month</div>
        </div>
        <button style={{ padding: '10px 20px', background: b.accent, color: b.accentInk, border: 'none', borderRadius: 3, fontWeight: 600, fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Shop SS26</button>
      </div>

      {/* Hero banner row */}
      <div style={{ padding: '20px 24px', display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 12 }}>
        <div style={{ aspectRatio: '16/7', background: '#e5e9f5', borderRadius: 4, position: 'relative', display: 'flex', alignItems: 'center', padding: 24 }}>
          <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 4 }} />
          <div style={{ position: 'relative', zIndex: 2, color: '#1b1b1b', maxWidth: '50%' }}>
            <div style={{ fontSize: 28, fontWeight: 800, lineHeight: 1.1 }}>Apparel up to 30% off</div>
            <div style={{ fontSize: 12, marginTop: 6, color: '#444' }}>This week only — bulk order discounts apply.</div>
            <button style={{ marginTop: 12, padding: '8px 16px', background: '#1b1b1b', color: '#fff', border: 'none', borderRadius: 3, fontWeight: 600, fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Shop now</button>
          </div>
        </div>
        <div style={{ aspectRatio: '8/7', background: '#fff1d4', borderRadius: 4, position: 'relative', padding: 14, display: 'flex', alignItems: 'flex-end' }}>
          <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 4 }} />
          <div style={{ position: 'relative', zIndex: 2, color: '#1b1b1b' }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 4 }}>New arrivals</div>
            <div style={{ fontSize: 16, fontWeight: 700 }}>Headwear collection →</div>
          </div>
        </div>
        <div style={{ aspectRatio: '8/7', background: '#e8f0e0', borderRadius: 4, position: 'relative', padding: 14, display: 'flex', alignItems: 'flex-end' }}>
          <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 4 }} />
          <div style={{ position: 'relative', zIndex: 2, color: '#1b1b1b' }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 4 }}>Best sellers</div>
            <div style={{ fontSize: 16, fontWeight: 700 }}>Top-rated drinkware →</div>
          </div>
        </div>
      </div>

      {/* Featured products — dense 6-up grid */}
      <div style={{ padding: '0 24px 24px' }}>
        <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom: 14 }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, color: '#1b1b1b', margin: 0, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Featured Products</h2>
          <span style={{ fontSize: 11, color: b.accent, fontWeight: 600 }}>View all →</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12 }}>
          {Array.from({ length: 6 }).map((_, i) => <ClassicCard key={i} />)}
        </div>
      </div>

      {/* Trust bar */}
      <div style={{ padding: '20px 24px', borderTop: '1px solid #ececec', borderBottom: '1px solid #ececec', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, fontSize: 12, color: '#444', background: '#fafafa' }}>
        {[
          ['🚚','Free shipping','On orders over $150'],
          ['↩','30-day returns','No questions asked'],
          ['🔒','Secure checkout','PCI-compliant payments'],
          ['💬','Live support','Mon-Fri 9-5 ET'],
        ].map(([emoji, t, s]) => (
          <div key={t} style={{ display:'flex', alignItems:'center', gap: 12 }}>
            <div style={{ width: 32, height: 32, borderRadius: 4, background: '#fff', border: '1px solid #ececec', display:'grid', placeItems:'center', fontSize: 14 }}>{emoji}</div>
            <div>
              <div style={{ fontWeight: 600, color: '#1b1b1b' }}>{t}</div>
              <div style={{ color: '#999', fontSize: 11 }}>{s}</div>
            </div>
          </div>
        ))}
      </div>

      <ClassicFooter />
    </ClassicShell>
  );
}

// ── SHOP ─────────────────────────────────────────────────────────
function ClassicShop() {
  return (
    <ClassicShell>
      {/* Breadcrumb */}
      <div style={{ padding: '10px 24px', fontSize: 11, color: '#666', borderBottom: '1px solid #ececec' }}>
        Home · <span style={{ color: '#1b1b1b' }}>All Products</span>
      </div>
      {/* Header row */}
      <div style={{ padding: '16px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #ececec' }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: '#1b1b1b', margin: 0 }}>All Products</h1>
          <div style={{ fontSize: 11, color: '#999', marginTop: 2 }}>Showing 1–24 of 142 results</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, fontSize: 12 }}>
          <span style={{ color: '#666' }}>Sort by:</span>
          <select style={{ border: '1px solid #d4d4d4', padding: '6px 10px', borderRadius: 3, fontSize: 12, fontFamily: 'inherit' }}>
            <option>Featured</option><option>Price: Low to High</option><option>Price: High to Low</option><option>Newest</option>
          </select>
          <div style={{ display: 'flex', border: '1px solid #d4d4d4', borderRadius: 3 }}>
            <span style={{ padding: '6px 10px', background: '#1b1b1b', color: '#fff' }}><Icon name="grid" size={12} stroke={2} /></span>
            <span style={{ padding: '6px 10px', color: '#999' }}><Icon name="list" size={12} stroke={2} /></span>
          </div>
        </div>
      </div>
      {/* Sidebar + grid */}
      <div style={{ display: 'flex', padding: '20px 24px', gap: 24 }}>
        <ClassicSidebar />
        <div style={{ flex: 1 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
            {Array.from({ length: 12 }).map((_, i) => <ClassicCard key={i} />)}
          </div>
          {/* Pagination */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginTop: 24 }}>
            {['‹','1','2','3','4','5','›'].map((p, i) => (
              <span key={i} style={{ width: 30, height: 30, display: 'grid', placeItems: 'center', border: '1px solid #d4d4d4', borderRadius: 3, fontSize: 12, color: p === '1' ? '#fff' : '#444', background: p === '1' ? '#1b1b1b' : '#fff' }}>{p}</span>
            ))}
          </div>
        </div>
      </div>
      <ClassicFooter />
    </ClassicShell>
  );
}

// ── CART ─────────────────────────────────────────────────────────
function ClassicCart() {
  const b = React.useContext(BrandContext);
  const items = [
    { name: 'Heavyweight Crewneck', sku: 'APR-CRW-001', size: 'L', color: 'Black', q: 2, p: 48.00 },
    { name: 'Logo Embroidered Cap', sku: 'HEA-CAP-014', size: 'OS', color: 'Navy', q: 1, p: 28.00 },
    { name: 'Insulated Tumbler 20oz', sku: 'DRK-TBL-007', size: '20oz', color: 'Steel', q: 4, p: 24.00 },
  ];
  const subtotal = items.reduce((a, i) => a + i.p * i.q, 0);
  return (
    <ClassicShell>
      <div style={{ padding: '10px 24px', fontSize: 11, color: '#666', borderBottom: '1px solid #ececec' }}>Home · <span style={{ color: '#1b1b1b' }}>Shopping Cart</span></div>
      <div style={{ padding: '20px 24px' }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: '#1b1b1b', margin: '0 0 16px' }}>Shopping Cart ({items.length} items)</h1>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 24 }}>
          {/* Cart table */}
          <div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr style={{ borderBottom: '2px solid #1b1b1b', textAlign: 'left', textTransform: 'uppercase', fontSize: 10, letterSpacing: '0.06em', color: '#666' }}>
                  <th style={{ padding: '8px 0', fontWeight: 700 }}>Product</th>
                  <th style={{ padding: '8px 0', fontWeight: 700 }}>Price</th>
                  <th style={{ padding: '8px 0', fontWeight: 700 }}>Qty</th>
                  <th style={{ padding: '8px 0', fontWeight: 700, textAlign: 'right' }}>Subtotal</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {items.map((it, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid #ececec' }}>
                    <td style={{ padding: '12px 0', display: 'flex', gap: 12, alignItems: 'center' }}>
                      <div style={{ width: 64, height: 64, background: '#f4f4f5', borderRadius: 3, position: 'relative', flexShrink: 0 }}>
                        <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 3 }} />
                      </div>
                      <div>
                        <div style={{ fontWeight: 600, color: '#1b1b1b' }}>{it.name}</div>
                        <div style={{ color: '#999', fontSize: 11, marginTop: 2 }}>SKU: {it.sku}</div>
                        <div style={{ color: '#666', fontSize: 11, marginTop: 2 }}>Size: {it.size} · Color: {it.color}</div>
                      </div>
                    </td>
                    <td style={{ color: '#1b1b1b' }}>${it.p.toFixed(2)}</td>
                    <td>
                      <div style={{ display: 'inline-flex', border: '1px solid #d4d4d4', borderRadius: 3 }}>
                        <span style={{ width: 24, height: 28, display: 'grid', placeItems: 'center', cursor: 'pointer' }}>−</span>
                        <span style={{ width: 32, display: 'grid', placeItems: 'center', borderLeft: '1px solid #d4d4d4', borderRight: '1px solid #d4d4d4' }}>{it.q}</span>
                        <span style={{ width: 24, height: 28, display: 'grid', placeItems: 'center', cursor: 'pointer' }}>+</span>
                      </div>
                    </td>
                    <td style={{ textAlign: 'right', fontWeight: 700, color: '#1b1b1b' }}>${(it.p * it.q).toFixed(2)}</td>
                    <td style={{ textAlign: 'right', color: '#999' }}><Icon name="trash" size={14} stroke={1.6} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 16, fontSize: 12 }}>
              <div style={{ display: 'flex', gap: 8 }}>
                <input placeholder="Promo code" style={{ border: '1px solid #d4d4d4', padding: '7px 10px', borderRadius: 3, fontSize: 12, fontFamily: 'inherit' }} />
                <button style={{ padding: '7px 14px', background: '#fff', border: '1px solid #1b1b1b', borderRadius: 3, fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Apply</button>
              </div>
              <button style={{ padding: '7px 14px', background: '#fff', border: '1px solid #d4d4d4', borderRadius: 3, fontSize: 11, color: '#666' }}>← Continue Shopping</button>
            </div>
          </div>
          {/* Summary */}
          <div style={{ background: '#fafafa', border: '1px solid #ececec', borderRadius: 4, padding: 18, alignSelf: 'start', fontSize: 12 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: '#1b1b1b', textTransform: 'uppercase', letterSpacing: '0.06em', borderBottom: '1px solid #ececec', paddingBottom: 10, marginBottom: 12 }}>Order Summary</div>
            {[['Subtotal', `$${subtotal.toFixed(2)}`],['Shipping','$12.00'],['Tax','$13.92']].map(([l,v]) => (
              <div key={l} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, color: '#444' }}><span>{l}</span><span>{v}</span></div>
            ))}
            <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 10, borderTop: '1px solid #ececec', fontWeight: 700, fontSize: 14, color: '#1b1b1b' }}><span>Total</span><span>${(subtotal + 12 + 13.92).toFixed(2)}</span></div>
            <button style={{ width: '100%', marginTop: 14, padding: '11px 0', background: b.accent, color: b.accentInk, border: 'none', borderRadius: 3, fontWeight: 700, fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.06em', cursor: 'pointer' }}>Proceed to Checkout</button>
            <button style={{ width: '100%', marginTop: 6, padding: '9px 0', background: '#fff', color: '#444', border: '1px solid #d4d4d4', borderRadius: 3, fontWeight: 500, fontSize: 11, cursor: 'pointer' }}>Save as Proposal</button>
            <div style={{ marginTop: 10, padding: 8, background: '#fff', border: '1px solid #ececec', borderRadius: 3, color: '#666', fontSize: 11 }}>🔒 Secure checkout · 256-bit SSL</div>
          </div>
        </div>
      </div>
      <ClassicFooter />
    </ClassicShell>
  );
}

// ── CHECKOUT ─────────────────────────────────────────────────────
function ClassicCheckout() {
  const b = React.useContext(BrandContext);
  const Section = ({ num, title, children }) => (
    <div style={{ border: '1px solid #ececec', borderRadius: 4, marginBottom: 12, overflow: 'hidden' }}>
      <div style={{ padding: '10px 14px', borderBottom: '1px solid #ececec', background: '#fafafa', fontSize: 12, fontWeight: 700, color: '#1b1b1b', textTransform: 'uppercase', letterSpacing: '0.06em', display:'flex', alignItems:'center', gap: 8 }}>
        <span style={{ width: 18, height: 18, borderRadius: 999, background: b.accent, color: b.accentInk, fontSize: 10, display:'grid', placeItems:'center' }}>{num}</span>
        {title}
      </div>
      <div style={{ padding: 14 }}>{children}</div>
    </div>
  );
  const Field = ({ label, ph, half = false }) => (
    <div style={{ flex: half ? 1 : '1 1 100%', minWidth: half ? 0 : '100%' }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>{label}</div>
      <input placeholder={ph} style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #d4d4d4', borderRadius: 3, padding: '8px 10px', fontSize: 12, fontFamily: 'inherit' }} />
    </div>
  );
  return (
    <ClassicShell>
      <div style={{ padding: '10px 24px', fontSize: 11, color: '#666', borderBottom: '1px solid #ececec' }}>Home · Cart · <span style={{ color: '#1b1b1b' }}>Checkout</span></div>
      <div style={{ padding: '20px 24px' }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: '#1b1b1b', margin: '0 0 16px' }}>Checkout</h1>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 24 }}>
          <div>
            <Section num="1" title="Customer Information">
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                <Field label="Email" ph="you@company.com" />
                <Field label="First Name" ph="" half />
                <Field label="Last Name" ph="" half />
                <Field label="Company" ph="" />
                <Field label="Phone" ph="" />
              </div>
            </Section>
            <Section num="2" title="Shipping Address">
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                <Field label="Address" ph="" />
                <Field label="City" ph="" half />
                <Field label="State" ph="" half />
                <Field label="ZIP" ph="" half />
                <Field label="Country" ph="" half />
              </div>
            </Section>
            <Section num="3" title="Shipping Method">
              {[
                ['Standard (5-7 days)','$12.00', true],
                ['Expedited (2-3 days)','$28.00', false],
                ['Overnight','$45.00', false],
              ].map(([l, p, on], i) => (
                <label key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 0', borderBottom: i < 2 ? '1px solid #ececec' : 'none', cursor: 'pointer' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 12 }}>
                    <input type="radio" defaultChecked={on} style={{ accentColor: '#1b1b1b' }} />
                    {l}
                  </span>
                  <span style={{ fontWeight: 700, color: '#1b1b1b' }}>{p}</span>
                </label>
              ))}
            </Section>
            <Section num="4" title="Payment Method">
              {['Credit / Debit Card','Invoice (NET 30)','Purchase Order'].map((l, i) => (
                <label key={i} style={{ display: 'flex', alignItems: 'center', padding: '10px 0', borderBottom: i < 2 ? '1px solid #ececec' : 'none', gap: 10, fontSize: 12, cursor: 'pointer' }}>
                  <input type="radio" defaultChecked={i === 0} style={{ accentColor: '#1b1b1b' }} />
                  {l}
                </label>
              ))}
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 10 }}>
                <Field label="Card number" ph="•••• •••• •••• ••••" />
                <Field label="Expiry" ph="MM / YY" half />
                <Field label="CVC" ph="123" half />
              </div>
            </Section>
          </div>
          <div style={{ background: '#fafafa', border: '1px solid #ececec', borderRadius: 4, padding: 18, alignSelf: 'start', fontSize: 12, position: 'sticky', top: 20 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: '#1b1b1b', textTransform: 'uppercase', letterSpacing: '0.06em', borderBottom: '1px solid #ececec', paddingBottom: 10, marginBottom: 12 }}>Your Order (3 items)</div>
            {[['Heavyweight Crewneck × 2','$96.00'],['Logo Cap','$28.00'],['Tumbler × 4','$96.00']].map(([l, p]) => (
              <div key={l} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}><span style={{ color: '#444' }}>{l}</span><span style={{ color: '#1b1b1b', fontWeight: 600 }}>{p}</span></div>
            ))}
            <div style={{ borderTop: '1px solid #ececec', paddingTop: 10, marginTop: 10 }}>
              {[['Subtotal','$220.00'],['Shipping','$12.00'],['Tax','$18.56']].map(([l, v]) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, color: '#444' }}><span>{l}</span><span>{v}</span></div>
              ))}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 10, borderTop: '1px solid #ececec', fontWeight: 700, fontSize: 14, color: '#1b1b1b' }}><span>Total</span><span>$250.56</span></div>
            <button style={{ width: '100%', marginTop: 14, padding: '11px 0', background: b.accent, color: b.accentInk, border: 'none', borderRadius: 3, fontWeight: 700, fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.06em', cursor: 'pointer' }}>Place Order</button>
            <button style={{ width: '100%', marginTop: 6, padding: '9px 0', background: '#fff', color: '#444', border: '1px solid #d4d4d4', borderRadius: 3, fontWeight: 500, fontSize: 11 }}>Save as Proposal</button>
          </div>
        </div>
      </div>
      <ClassicFooter />
    </ClassicShell>
  );
}

// ── CUSTOM REQUEST ──────────────────────────────────────────────
function ClassicCustomRequest() {
  const b = React.useContext(BrandContext);
  return (
    <ClassicShell>
      <div style={{ padding: '10px 24px', fontSize: 11, color: '#666', borderBottom: '1px solid #ececec' }}>Home · <span style={{ color: '#1b1b1b' }}>Custom Request</span></div>
      <div style={{ padding: '24px', maxWidth: 880, margin: '0 auto' }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: '#1b1b1b', margin: '0 0 6px' }}>Submit a Custom Request</h1>
        <div style={{ fontSize: 13, color: '#666', marginBottom: 18 }}>Need something not in our catalog? Tell us what you're looking for and we'll get back with options + pricing.</div>
        <div style={{ border: '1px solid #ececec', borderRadius: 4, padding: 20 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            {[
              ['Project name','e.g. Summit Conference 2026 Swag'],
              ['Target budget','$'],
              ['Quantity needed',''],
              ['Need by date',''],
            ].map(([l, ph]) => (
              <div key={l}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>{l}</div>
                <input placeholder={ph} style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #d4d4d4', borderRadius: 3, padding: '8px 10px', fontSize: 12, fontFamily: 'inherit' }} />
              </div>
            ))}
            <div style={{ gridColumn: '1 / -1' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Describe what you're looking for</div>
              <textarea rows={5} placeholder="Items, materials, decoration, color preferences…" style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #d4d4d4', borderRadius: 3, padding: 10, fontSize: 12, fontFamily: 'inherit', resize: 'vertical' }} />
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Reference images / artwork</div>
              <div style={{ border: '1px dashed #d4d4d4', borderRadius: 3, padding: '20px', textAlign: 'center', fontSize: 12, color: '#666' }}>
                <div style={{ marginBottom: 4 }}>Drop files here or <span style={{ color: b.accent, fontWeight: 600 }}>browse</span></div>
                <div style={{ fontSize: 11, color: '#999' }}>PNG, JPG, AI, EPS, PDF · max 25 MB</div>
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 16, justifyContent: 'flex-end' }}>
            <button style={{ padding: '9px 18px', background: '#fff', border: '1px solid #d4d4d4', borderRadius: 3, fontSize: 12, color: '#444' }}>Cancel</button>
            <button style={{ padding: '9px 18px', background: b.accent, color: b.accentInk, border: 'none', borderRadius: 3, fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Submit Request</button>
          </div>
        </div>
      </div>
      <ClassicFooter />
    </ClassicShell>
  );
}

Object.assign(window, { ClassicHome, ClassicShop, ClassicCart, ClassicCheckout, ClassicCustomRequest });
