/* global React, Header, Ph, Icon, LogoMark */
// Category (landing) page variations

const CATS = [
  { name: 'Apparel & Uniforms', tag: 'Bestseller' },
  { name: 'Promotional Items', tag: 'New' },
  { name: 'Corporate Gifts', tag: '' },
  { name: 'Events & Signage', tag: '' },
  { name: 'Print & Stationery', tag: 'New' },
  { name: 'Tech & Drinkware', tag: '' },
];

// ──────────────── V1: 4-up row (matches PDF) ────────────────
function CategoryV1() {
  return (
    <div className="art-inner">
      <Header active="shop" />
      <div style={{ padding: '48px 56px' }}>
        <div style={{ marginBottom: 32 }}>
          <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--ink-3)', marginBottom: 8 }}>Shop by category</div>
          <h1>Welcome back, Acme Team</h1>
          <div className="muted" style={{ marginTop: 6, maxWidth: 520 }}>Curated catalog for your organization — approved brand items, bulk pricing, and one-click reorders.</div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr) 80px', gap: 20, alignItems: 'stretch' }}>
          {CATS.slice(0,4).map((c,i) => (
            <div key={i} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: 20, display: 'flex', flexDirection: 'column', gap: 14, cursor: 'pointer' }}>
              <Ph ratio="1" label={`Promotional icon ${i+1}`} />
              <div>
                <div style={{ fontWeight: 600, fontSize: 15 }}>{c.name}</div>
                <div className="muted tiny" style={{ marginTop: 4 }}>Headline text for {c.name.toLowerCase()}.</div>
              </div>
              <div className="tiny muted" style={{ marginTop: 'auto', paddingTop: 8, borderTop: '1px dashed var(--border)' }}>Browse category →</div>
            </div>
          ))}
          <button className="btn-ghost" style={{ border: '2px dashed var(--border-strong)', borderRadius: 'var(--radius-lg)', background: 'transparent', display: 'grid', placeItems: 'center', color: 'var(--ink-3)', gap: 6, flexDirection: 'column', cursor: 'pointer' }}>
            <Icon name="plus" size={28} stroke={1.5} />
            <div className="tiny">Add category</div>
          </button>
        </div>

        <div style={{ marginTop: 28, padding: 24, border: '1px dashed var(--border-strong)', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-3)', marginBottom: 8 }}>About this store</div>
          <div style={{ maxWidth: 720, color: 'var(--ink-2)', lineHeight: 1.6 }}>
            Text area with regular formatting capabilities. Distributor-managed rich copy — a welcome note, program rules, or ordering deadlines.
          </div>
        </div>
      </div>
    </div>
  );
}

// ──────────────── V2: Hero + smaller tiles ────────────────
function CategoryV2() {
  return (
    <div className="art-inner">
      <Header active="shop" />
      <div style={{ padding: '40px 56px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 20, height: 340 }}>
          <div style={{ position: 'relative', borderRadius: 'var(--radius-lg)', overflow: 'hidden', background: 'linear-gradient(135deg, var(--accent-soft), var(--surface-2))', padding: 36, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div>
              <div className="tiny" style={{ textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--ink-2)', marginBottom: 10 }}>Featured category</div>
              <h1 style={{ fontSize: 36 }}>Apparel & Uniforms</h1>
              <div className="muted" style={{ marginTop: 8, maxWidth: 360 }}>Branded wear for teams, events, and recognition programs.</div>
            </div>
            <button className="btn btn-primary" style={{ alignSelf: 'flex-start' }}>Shop the category <Icon name="chevRight" size={14} /></button>
            <Ph style={{ position: 'absolute', right: -40, bottom: -40, width: 280, height: 280, borderRadius: 999, border: 'none', opacity: 0.9 }} />
          </div>
          <div style={{ display: 'grid', gridTemplateRows: '1fr 1fr', gap: 20 }}>
            {[CATS[1], CATS[2]].map((c,i) => (
              <div key={i} style={{ position: 'relative', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)', overflow: 'hidden', padding: 20, display: 'flex', gap: 16, alignItems: 'center', cursor: 'pointer', background: 'var(--surface)' }}>
                <Ph style={{ width: 96, height: 96, flexShrink: 0 }} />
                <div>
                  {c.tag && <span className="tag sale">{c.tag}</span>}
                  <div style={{ fontWeight: 600, fontSize: 16, marginTop: c.tag ? 6: 0 }}>{c.name}</div>
                  <div className="muted tiny" style={{ marginTop: 4 }}>24 items · starts at $8.50</div>
                </div>
                <Icon name="chevRight" size={18} stroke={1.4} />
              </div>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 32, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
          {CATS.slice(2,6).map((c,i) => (
            <div key={i} style={{ padding: 16, border: '1px solid var(--border)', borderRadius: 'var(--radius)', cursor: 'pointer', background: 'var(--bg)' }}>
              <Ph ratio="16/10" />
              <div style={{ marginTop: 10, fontWeight: 500, fontSize: 13 }}>{c.name}</div>
              <div className="muted tiny">12 items</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ──────────────── V3: Icon-forward flexible grid ────────────────
function CategoryV3() {
  return (
    <div className="art-inner">
      <Header active="shop" />
      <div style={{ padding: '56px 56px 40px', textAlign: 'center' }}>
        <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.14em', color: 'var(--ink-3)' }}>Merchandise portal</div>
        <h1 style={{ fontSize: 40, marginTop: 8, letterSpacing: -0.03 }}>What are you shopping for?</h1>
        <div className="muted" style={{ marginTop: 10, maxWidth: 540, margin: '10px auto 0' }}>Choose a category to see the items approved for your program.</div>
      </div>
      <div style={{ padding: '0 56px 48px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 14 }}>
          {CATS.map((c,i) => (
            <div key={i} style={{ aspectRatio: '1', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: 18, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', background: i===0 ? 'var(--accent-soft)' : 'var(--bg)', cursor: 'pointer', position: 'relative' }}>
              {c.tag && <span className="tag sale" style={{ position: 'absolute', top: 12, right: 12 }}>{c.tag}</span>}
              <div style={{ width: 44, height: 44, borderRadius: 10, background: 'var(--surface-2)', display: 'grid', placeItems: 'center', color: 'var(--ink-2)' }}>
                <Icon name={['bag','star','heart','grid','list','image'][i]} size={22} stroke={1.4} />
              </div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14, letterSpacing: -0.01 }}>{c.name}</div>
                <div className="muted tiny" style={{ marginTop: 3 }}>{12+i*4} items</div>
              </div>
            </div>
          ))}
          <button className="btn-ghost" style={{ aspectRatio:'1', border:'2px dashed var(--border-strong)', borderRadius:'var(--radius-lg)', display:'grid', placeItems:'center', color:'var(--ink-3)', cursor:'pointer', background:'transparent', flexDirection:'column', gap:6 }}>
            <Icon name="plus" size={24} />
            <div className="tiny">Add category</div>
          </button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { CategoryV1, CategoryV2, CategoryV3 });
