/* global React, Header, Ph, Icon */
// Shop page — Most template style with Curtain Reveal footer
//
// Curtain mechanic: a scrollable artboard containing
//   - .shop-curtain-content   solid bg, z-10, rounded bottom corners
//   - .shop-curtain-footer    fixed-to-artboard-bottom, z-0
// Content has bottom margin == footer height; as user scrolls into that
// margin "hole" the fixed footer is revealed beneath.

const SHOP_CATS = [
  { n: 'For Running', tone: '#fbe5e2' },
  { n: 'Training',    tone: '#fff1d4' },
  { n: 'Walking',     tone: '#e8f0e0' },
  { n: 'Workout',     tone: '#e6e9f5' },
];

const SHOP_PRODUCTS = [
  { t: 'Run Max 88',         p: 180, cat: 'For Running', sale: false, oldP: null, tone: '#f4f4f5' },
  { t: 'Workout Revolution', p: 120, cat: 'Workout',     sale: false, oldP: null, tone: '#f4f4f5' },
  { t: 'KL 17 BS',           p: 80,  cat: 'Training',    sale: false, oldP: null, tone: '#f4f4f5' },
  { t: 'Flex Armour',        p: 139.99, cat: 'Walking',  sale: false, oldP: null, tone: '#f4f4f5' },
  { t: 'Men Vision Trainers',p: 56.99,  cat: 'Training', sale: false, oldP: null, tone: '#e0f2ec' },
  { t: 'React Falcon 3.0',   p: 99,   cat: 'For Running',sale: 'Sale', oldP: 130,  tone: '#e8eaf3' },
];

const SIDE_PRODUCTS = [
  { t: 'Run Max 88',         p: 180 },
  { t: 'Workout Revolution', p: 120 },
  { t: 'KL 17 BS',           p: 80 },
  { t: 'Flex Armour',        p: 139.99 },
  { t: 'Men Vision Trainers',p: 56.99 },
];

const SIDE_CATS = ['For Running','Training','Uncategorized','Walking','Workout'];
const SIDE_TAGS = ['Life','Move','Sport','Trainers'];

function MostShopCard({ p, accent }) {
  return (
    <article style={{
      borderRadius: 20, overflow: 'hidden',
      display: 'flex', flexDirection: 'column',
      cursor: 'pointer',
    }}>
      <div style={{
        position: 'relative', borderRadius: 20, overflow: 'hidden',
        marginBottom: -20, aspectRatio: '4/3',
        background: p.tone || '#f4f4f5',
      }}>
        <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 0, background: 'transparent' }} />
        {p.sale && (
          <span style={{
            position: 'absolute', top: 12, right: 12,
            width: 55, height: 55, borderRadius: 999,
            background: '#ffd233', color: '#1b1b1b',
            display: 'grid', placeItems: 'center',
            fontWeight: 700, fontSize: 13, zIndex: 1,
          }}>{p.sale}!</span>
        )}
      </div>
      <div style={{
        paddingLeft: 24, paddingRight: 20, paddingTop: 14, paddingBottom: 14,
        borderRadius: 20, background: '#fff',
        position: 'relative', zIndex: 1,
      }}>
        <div style={{ fontSize: 12, color: accent, marginBottom: 4, fontWeight: 500 }}>{p.cat}</div>
        <h5 style={{ fontSize: 18, fontWeight: 600, margin: 0, width: 'calc(100% - 50px)', lineHeight: 1.25, letterSpacing: -0.01, color: '#1b1b1b' }}>{p.t}</h5>
        <div style={{ display: 'flex', alignItems: 'center', marginTop: 8 }}>
          <div style={{ fontWeight: 500, fontSize: 14, color: '#666' }}>
            {p.oldP && <span style={{ textDecoration: 'line-through', opacity: 0.5, marginRight: 6 }}>${p.oldP.toFixed(2)}</span>}
            <span>${typeof p.p === 'number' && !Number.isInteger(p.p) ? p.p.toFixed(2) : p.p + '.00'}</span>
          </div>
          <div style={{ flex: 1 }} />
          <button title="Add to cart" style={{
            position: 'absolute', right: 0, bottom: 0,
            background: '#777', width: 45, height: 45,
            borderTopLeftRadius: 16, borderBottomRightRadius: 20,
            border: 'none', display: 'grid', placeItems: 'center',
            color: '#fff', cursor: 'pointer',
          }}>
            <Icon name="plus" size={22} stroke={2.2} />
          </button>
        </div>
      </div>
    </article>
  );
}

function ShopMost() {
  const PRIMARY = 'hsl(12, 85%, 58%)';
  const FOOTER_H = 360;
  const [priceLow, setPriceLow] = React.useState(50);
  const [priceHigh, setPriceHigh] = React.useState(180);
  const scrollRef = React.useRef(null);
  const [scrolled, setScrolled] = React.useState(0);

  React.useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const max = el.scrollHeight - el.clientHeight;
      setScrolled(max > 0 ? el.scrollTop / max : 0);
    };
    el.addEventListener('scroll', onScroll);
    return () => el.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div style={{
      position: 'relative', width: '100%', height: '100%',
      background: '#f0eef0',
      fontFamily: '"Inter Tight", -apple-system, sans-serif',
      overflow: 'hidden',
    }}>
      {/* FIXED FOOTER (curtain behind) */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        height: FOOTER_H, zIndex: 0,
        background: '#ececec',
        padding: '60px 64px 24px',
        display: 'flex', flexDirection: 'column',
        boxSizing: 'border-box',
      }}>
        {/* Hero band */}
        <div style={{ textAlign: 'center', marginBottom: 50 }}>
          <h2 style={{
            fontSize: 64, fontWeight: 400, letterSpacing: -0.02,
            margin: 0, lineHeight: 1.05, color: '#1b1b1b',
          }}>
            Welcome to your <strong style={{ fontWeight: 800 }}>TEAM</strong>
            <br />
            <strong style={{ fontWeight: 800 }}>STORE</strong>
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 8,
              marginLeft: 18, padding: '12px 24px',
              border: '1.5px solid #1b1b1b',
              borderRadius: 999,
              fontSize: 16, fontWeight: 500,
              verticalAlign: 'middle',
              cursor: 'pointer',
            }}>
              Start shopping
              <span style={{
                width: 28, height: 28, borderRadius: 999,
                background: '#1b1b1b', color: '#fff',
                display: 'grid', placeItems: 'center',
              }}>→</span>
            </span>
          </h2>
        </div>

        <div style={{ flex: 1 }} />

        {/* Socials row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 32, paddingBottom: 18, borderBottom: 'none' }}>
          {[
            { t: 'Dribble',   h: '@madsparrow_dev', i: 'D' },
            { t: 'Twitter',   h: '@madsparrow_dev', i: 'T' },
            { t: 'Instagram', h: '@madsparrow_dev', i: 'I' },
            { t: 'Behance',   h: '@madsparrow_dev', i: 'B' },
          ].map(s => (
            <div key={s.t} style={{ borderTop: '1px solid #c6c6c6', paddingTop: 16, display: 'flex', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#1b1b1b' }}>{s.t}</div>
                <div style={{ fontSize: 12, color: '#999' }}>{s.h}</div>
              </div>
              <div style={{ flex: 1 }} />
              <div style={{
                width: 32, height: 32, borderRadius: 999,
                background: '#d4d4d4', color: '#1b1b1b',
                display: 'grid', placeItems: 'center',
                fontSize: 12, fontWeight: 700,
              }}>{s.i}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 16, fontSize: 11, color: '#999' }}>
          <div>©2026 <strong style={{ color: '#1b1b1b' }}>MergeTasks</strong>. All Rights Reserved.</div>
          <div>End-user branded webstore</div>
        </div>
      </div>

      {/* SCROLLABLE CONTENT (the curtain itself) */}
      <div ref={scrollRef} style={{
        position: 'absolute', inset: 0,
        zIndex: 10,
        overflowY: 'auto',
        background: 'transparent',
      }}>
        <div style={{
          background: '#fff',
          borderBottomLeftRadius: 32,
          borderBottomRightRadius: 32,
          marginBottom: FOOTER_H,
          minHeight: '100%',
          paddingBottom: 80,
          boxShadow: '0 8px 24px rgba(0,0,0,0.04)',
          position: 'relative',
        }}>
          {/* Top nav */}
          <div style={{
            display: 'flex', alignItems: 'center',
            padding: '24px 48px',
            position: 'sticky', top: 0,
            background: '#fff', zIndex: 5,
          }}>
            <div style={{
              width: 40, height: 40, borderRadius: 999,
              background: '#1b1b1b', color: '#fff',
              display: 'grid', placeItems: 'center',
              fontStyle: 'italic', fontWeight: 600, fontSize: 18,
              fontFamily: 'Georgia, serif',
            }}>m</div>
            <div style={{ flex: 1, display: 'flex', justifyContent: 'center', gap: 28, fontSize: 14, color: '#1b1b1b' }}>
              {['Home','Stories','Works','Page','Contact','Shop'].map((n,i) => (
                <a key={n} style={{ textDecoration: 'none', color: '#1b1b1b', fontWeight: i===5?600:400, cursor: 'pointer' }}>{n}</a>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 16, color: '#1b1b1b' }}>
              <Icon name="sun" size={18} stroke={1.5} />
              <Icon name="search" size={18} stroke={1.5} />
            </div>
          </div>

          {/* Header */}
          <div style={{ padding: '40px 48px 0' }}>
            <h1 style={{ fontSize: 72, fontWeight: 800, letterSpacing: -0.03, margin: 0, color: '#1b1b1b', lineHeight: 1 }}>Shop</h1>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 40, marginTop: 56 }}>
              {/* LEFT col header */}
              <div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 }}>
                  <p style={{ margin: 0, color: '#999', fontSize: 13 }}>Showing 1–6 of 7 results</p>
                  <div style={{
                    display: 'inline-flex', alignItems: 'center', gap: 8,
                    border: '1px solid #e5e5e5', borderRadius: 4,
                    padding: '8px 14px', fontSize: 13, color: '#666',
                    cursor: 'pointer',
                  }}>
                    Default sorting
                    <Icon name="chevDown" size={12} stroke={2} />
                  </div>
                </div>

                {/* Category chips */}
                <div style={{ display: 'flex', gap: 14, marginBottom: 36, flexWrap: 'wrap' }}>
                  {SHOP_CATS.map((c, i) => (
                    <div key={c.n} style={{
                      display: 'inline-flex', alignItems: 'center', gap: 8,
                      padding: '4px 16px 4px 4px',
                      background: c.tone, borderRadius: 999,
                      cursor: 'pointer',
                    }}>
                      <div style={{
                        width: 32, height: 32, borderRadius: 999,
                        background: '#fff', display: 'grid', placeItems: 'center',
                      }}>
                        <Icon name="image" size={14} stroke={1.4} />
                      </div>
                      <span style={{ fontSize: 13, fontWeight: 500, color: PRIMARY }}>{c.n}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* RIGHT col header — Price filter */}
              <div>
                <h3 style={{ fontSize: 18, fontWeight: 700, margin: '0 0 18px', color: '#1b1b1b', position: 'relative', paddingBottom: 14 }}>
                  Filter by price
                  <span style={{ position: 'absolute', left: 0, bottom: 0, width: 30, height: 2, background: '#1b1b1b' }} />
                </h3>
                <div style={{ position: 'relative', height: 24, marginBottom: 18 }}>
                  <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, height: 3, background: '#e5e5e5', borderRadius: 999, transform: 'translateY(-50%)' }} />
                  <div style={{
                    position: 'absolute', top: '50%', height: 3,
                    left: `${((priceLow-50)/130)*100}%`,
                    right: `${100-((priceHigh-50)/130)*100}%`,
                    background: '#777', borderRadius: 999, transform: 'translateY(-50%)',
                  }} />
                  <div style={{
                    position: 'absolute', top: '50%', left: `${((priceLow-50)/130)*100}%`,
                    transform: 'translate(-50%, -50%)',
                    width: 14, height: 14, borderRadius: 999, background: '#777',
                  }} />
                  <div style={{
                    position: 'absolute', top: '50%', left: `${((priceHigh-50)/130)*100}%`,
                    transform: 'translate(-50%, -50%)',
                    width: 14, height: 14, borderRadius: 999, background: '#777',
                  }} />
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                  <span style={{ color: '#999', textTransform: 'uppercase', letterSpacing: '0.08em', fontSize: 11, fontWeight: 600 }}>Price:</span>
                  <span style={{ fontWeight: 600 }}>{priceLow}$</span>
                  <span style={{ color: '#999' }}>–</span>
                  <span style={{ fontWeight: 600 }}>{priceHigh}$</span>
                  <div style={{ flex: 1 }} />
                  <button style={{
                    background: 'transparent', border: 'none', color: PRIMARY,
                    fontWeight: 700, fontSize: 12, letterSpacing: '0.1em',
                    cursor: 'pointer', textTransform: 'uppercase',
                  }}>FILTER</button>
                </div>
              </div>
            </div>
          </div>

          {/* Main grid */}
          <div style={{ padding: '0 48px', display: 'grid', gridTemplateColumns: '1fr 320px', gap: 40 }}>
            {/* LEFT — products */}
            <div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 24 }}>
                {SHOP_PRODUCTS.map((p, i) => <MostShopCard key={i} p={p} accent={PRIMARY} />)}
              </div>

              {/* Pagination */}
              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 8, marginTop: 56 }}>
                <span style={{
                  width: 36, height: 36, borderRadius: 999,
                  background: '#1b1b1b', color: '#fff',
                  display: 'grid', placeItems: 'center', fontSize: 13, fontWeight: 600,
                }}>1</span>
                <a style={{ padding: '0 12px', color: '#1b1b1b', cursor: 'pointer', fontSize: 13 }}>2</a>
                <a style={{ padding: '0 12px', color: PRIMARY, cursor: 'pointer', fontSize: 13, fontWeight: 500 }}>Next</a>
              </div>
            </div>

            {/* RIGHT — sidebar */}
            <aside style={{ display: 'flex', flexDirection: 'column', gap: 36 }}>
              {/* Products */}
              <div>
                <h3 style={{ fontSize: 18, fontWeight: 700, margin: '0 0 18px', color: '#1b1b1b', position: 'relative', paddingBottom: 14 }}>
                  Products
                  <span style={{ position: 'absolute', left: 0, bottom: 0, width: 30, height: 2, background: '#1b1b1b' }} />
                </h3>
                <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 16 }}>
                  {SIDE_PRODUCTS.map((p, i) => (
                    <li key={i} style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                      <div style={{ width: 70, height: 70, borderRadius: 12, background: '#f4f4f5', overflow: 'hidden', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                        <Icon name="image" size={20} stroke={1.4} />
                      </div>
                      <div>
                        <div style={{ fontSize: 15, fontWeight: 600, color: '#1b1b1b', lineHeight: 1.3 }}>{p.t}</div>
                        <div style={{ fontSize: 13, color: '#777', marginTop: 4 }}>${typeof p.p === 'number' && !Number.isInteger(p.p) ? p.p.toFixed(2) : p.p + '.00'}</div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Categories */}
              <div>
                <h3 style={{ fontSize: 18, fontWeight: 700, margin: '0 0 18px', color: '#1b1b1b', position: 'relative', paddingBottom: 14 }}>
                  Product categories
                  <span style={{ position: 'absolute', left: 0, bottom: 0, width: 30, height: 2, background: '#1b1b1b' }} />
                </h3>
                <ul style={{ listStyle: 'disc', paddingLeft: 18, margin: 0, color: '#1b1b1b', display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {SIDE_CATS.map(c => <li key={c} style={{ fontSize: 14, cursor: 'pointer' }}>{c}</li>)}
                </ul>
              </div>

              {/* Tags */}
              <div>
                <h3 style={{ fontSize: 18, fontWeight: 700, margin: '0 0 18px', color: '#1b1b1b', position: 'relative', paddingBottom: 14 }}>
                  Product tags
                  <span style={{ position: 'absolute', left: 0, bottom: 0, width: 30, height: 2, background: '#1b1b1b' }} />
                </h3>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {SIDE_TAGS.map(t => (
                    <span key={t} style={{
                      padding: '6px 14px', borderRadius: 999,
                      background: '#eaf3fc', color: '#1b1b1b',
                      fontSize: 13, fontWeight: 500, cursor: 'pointer',
                    }}>#{t}</span>
                  ))}
                </div>
              </div>
            </aside>
          </div>

          {/* End of curtain — back-to-top */}
          <div style={{ position: 'absolute', right: 24, bottom: 24 }}>
            <button style={{
              width: 36, height: 36, borderRadius: 999,
              border: '1px solid #e5e5e5', background: '#fff',
              display: 'grid', placeItems: 'center', cursor: 'pointer',
              color: '#1b1b1b',
            }}>↑</button>
          </div>
        </div>
      </div>

      {/* Scroll indicator (showing the curtain progress) */}
      <div style={{
        position: 'absolute', top: 12, right: 12, zIndex: 20,
        background: 'rgba(28,27,26,0.88)', color: '#fff',
        padding: '5px 10px', borderRadius: 999,
        fontSize: 10, fontWeight: 600, letterSpacing: '0.05em',
        textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 8,
        pointerEvents: 'none',
      }}>
        <span>Scroll inside ↓</span>
        <span style={{ width: 40, height: 3, background: 'rgba(255,255,255,0.25)', borderRadius: 999, overflow: 'hidden' }}>
          <span style={{ display: 'block', height: '100%', width: `${Math.round(scrolled*100)}%`, background: '#fff' }} />
        </span>
      </div>
    </div>
  );
}

Object.assign(window, { ShopMost });
