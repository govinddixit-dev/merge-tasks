/* global React, Icon */
// MergeTasks shared brand chrome — distributor-skinnable
// Provides BrandContext (logo + colors + name) and BrandedHeader / BrandedFooter
// used by all storefront and portal screens for visual consistency.

const BRANDS = {
  sample: {
    name: 'Sample Co.',
    short: 'S',
    logoColor: '#777',
    accent: '#1b1b1b',
    accentInk: '#fff',
    pill: '#1b1b1b',
    nav: ['HOME', 'PRODUCTS', 'CART', 'CUSTOM REQUEST', 'PORTAL'],
  },
  yan: {
    name: 'Yan Financial',
    short: 'Y',
    logoColor: '#3a7bd5',
    accent: '#0f1c3f',
    accentInk: '#fff',
    pill: '#0f1c3f',
    nav: ['HOME', 'PRODUCTS', 'CART', 'CUSTOM REQUEST', 'PORTAL'],
  },
  northwind: {
    name: 'Northwind Apparel',
    short: 'N',
    logoColor: '#c4392b',
    accent: '#c4392b',
    accentInk: '#fff',
    pill: '#1b1b1b',
    nav: ['HOME', 'PRODUCTS', 'CART', 'CUSTOM REQUEST', 'PORTAL'],
  },
};

const BrandContext = React.createContext(BRANDS.sample);

// A small ring-style logo mark used by all brands
const RingLogo = ({ size = 28, color = '#3a7bd5' }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
    <defs>
      <linearGradient id={`grad-${color.replace('#','')}`} x1="0" y1="0" x2="32" y2="32">
        <stop offset="0%" stopColor={color} stopOpacity="0.95" />
        <stop offset="100%" stopColor={color} stopOpacity="0.55" />
      </linearGradient>
    </defs>
    <circle cx="16" cy="16" r="11" stroke={`url(#grad-${color.replace('#','')})`} strokeWidth="3.5" fill="none" />
    <circle cx="22.5" cy="9.5" r="2.6" fill={color} />
  </svg>
);

const BrandedNav = ({ active = 'HOME', signedIn = false, userName = 'Yan', cartCount = 0 }) => {
  const b = React.useContext(BrandContext);
  return (
    <div style={{
      display: 'flex', alignItems: 'center',
      padding: '20px 48px',
      background: '#fff', borderBottom: '1px solid #f0f0f0',
      fontFamily: '"Inter Tight", -apple-system, sans-serif',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <RingLogo size={28} color={b.logoColor} />
        <div style={{ fontSize: 17, fontWeight: 700, color: '#1b1b1b', letterSpacing: -0.01 }}>{b.name}</div>
      </div>
      <div style={{ flex: 1, display: 'flex', justifyContent: 'center', gap: 32, fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', color: '#666' }}>
        {b.nav.map(n => (
          <a key={n} style={{
            cursor: 'pointer',
            color: n === active ? '#1b1b1b' : '#666',
            position: 'relative', padding: '4px 0',
          }}>{n}</a>
        ))}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, color: '#666' }}>
        <Icon name="moon" size={16} stroke={1.6} />
        {signedIn ? (
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            padding: '4px 10px 4px 4px', borderRadius: 999, background: '#f4f4f5',
          }}>
            <div style={{
              width: 26, height: 26, borderRadius: 999,
              background: b.pill, color: '#fff',
              display: 'grid', placeItems: 'center', fontSize: 12, fontWeight: 700,
            }}>{userName[0]}</div>
            <span style={{ fontSize: 12, color: '#1b1b1b', fontWeight: 500 }}>{userName}</span>
            <span style={{
              fontSize: 9, fontWeight: 700, letterSpacing: '0.08em',
              background: '#e5e7eb', color: '#666', padding: '2px 6px', borderRadius: 3,
            }}>ADMIN</span>
          </div>
        ) : (
          <button style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            background: b.pill, color: '#fff',
            border: 'none', padding: '7px 14px', borderRadius: 999,
            fontSize: 12, fontWeight: 600, cursor: 'pointer',
          }}>
            <Icon name="user" size={12} stroke={2} /> Sign In
          </button>
        )}
        <div style={{ position: 'relative' }}>
          <Icon name="cart" size={18} stroke={1.6} />
          {cartCount > 0 && (
            <span style={{
              position: 'absolute', top: -6, right: -8,
              background: '#1b1b1b', color: '#fff',
              minWidth: 16, height: 16, borderRadius: 999,
              fontSize: 9, fontWeight: 700, padding: '0 4px',
              display: 'grid', placeItems: 'center',
            }}>{cartCount}</span>
          )}
        </div>
      </div>
    </div>
  );
};

const BrandedFooterCompact = () => {
  const b = React.useContext(BrandContext);
  return (
    <div style={{
      background: '#f1f1f2', padding: '32px 48px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontFamily: '"Inter Tight", sans-serif', fontSize: 12, color: '#999',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <RingLogo size={20} color={b.logoColor} />
        <span style={{ color: '#1b1b1b', fontWeight: 600, fontSize: 13 }}>{b.name}</span>
      </div>
      <div style={{ textAlign: 'right' }}>
        <div>Powered by <span style={{ color: '#1b1b1b', fontWeight: 600 }}>MergeTasks Enterprise Platform</span></div>
        <div style={{ marginTop: 4 }}>support@mergetasks.com</div>
        <div style={{ marginTop: 2 }}>Terms · Privacy</div>
      </div>
    </div>
  );
};

Object.assign(window, { BRANDS, BrandContext, RingLogo, BrandedNav, BrandedFooterCompact });
