/* global React, Icon, Ph, BrandContext, BrandedNav */
// Storefront screens — Home, Cart, Checkout, Custom Request
// Most-template aesthetic; curtain reveal applied to scrollable surfaces.

const PRIMARY = 'hsl(12, 85%, 58%)';

function CurtainShell({ children, footer, footerHeight = 280 }) {
  const scrollRef = React.useRef(null);
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: '#f0eef0', overflow: 'hidden', fontFamily: '"Inter Tight", sans-serif' }}>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: footerHeight, zIndex: 0 }}>{footer}</div>
      <div ref={scrollRef} style={{ position: 'absolute', inset: 0, zIndex: 10, overflowY: 'auto' }}>
        <div style={{ background: '#fff', borderBottomLeftRadius: 32, borderBottomRightRadius: 32, marginBottom: footerHeight, minHeight: '100%', boxShadow: '0 8px 24px rgba(0,0,0,0.04)' }}>
          {children}
        </div>
      </div>
      <div style={{ position: 'absolute', top: 12, right: 12, zIndex: 20, background: 'rgba(28,27,26,0.88)', color: '#fff', padding: '5px 10px', borderRadius: 999, fontSize: 10, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', pointerEvents: 'none' }}>Scroll inside ↓</div>
    </div>
  );
}

const SimpleFooter = ({ showHero = false }) => {
  const b = React.useContext(BrandContext);
  return (
    <div style={{ background: '#ececec', height: '100%', padding: showHero ? '50px 48px 24px' : '24px 48px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', fontFamily: '"Inter Tight", sans-serif' }}>
      {showHero && (
        <div style={{ textAlign: 'center', marginBottom: 30 }}>
          <h2 style={{ fontSize: 48, fontWeight: 400, margin: 0, color: '#1b1b1b', lineHeight: 1.1 }}>
            Welcome to your <strong style={{ fontWeight: 800 }}>TEAM STORE</strong>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, marginLeft: 14, padding: '10px 20px', border: '1.5px solid #1b1b1b', borderRadius: 999, fontSize: 14, fontWeight: 500, verticalAlign: 'middle', cursor: 'pointer' }}>
              Start shopping <span style={{ width: 24, height: 24, borderRadius: 999, background: '#1b1b1b', color: '#fff', display: 'grid', placeItems: 'center' }}>→</span>
            </span>
          </h2>
        </div>
      )}
      <div style={{ flex: 1 }} />
      <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 14, borderTop: '1px solid #c6c6c6', fontSize: 11, color: '#999' }}>
        <div>©2026 <strong style={{ color: '#1b1b1b' }}>{b.name}</strong></div>
        <div>Powered by MergeTasks Enterprise Platform</div>
      </div>
    </div>
  );
};

// ── HOME ────────────────────────────────────────────────────
function StoreHome() {
  const b = React.useContext(BrandContext);
  return (
    <CurtainShell footer={<SimpleFooter showHero />} footerHeight={260}>
      <BrandedNav active="HOME" signedIn cartCount={2} userName="Yan" />
      <div style={{ padding: '60px 48px 0' }}>
        {/* Hero */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'center', marginBottom: 80 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.12em', color: PRIMARY, textTransform: 'uppercase', marginBottom: 14 }}>SS26 Collection</div>
            <h1 style={{ fontSize: 72, fontWeight: 800, lineHeight: 1, letterSpacing: -0.03, margin: 0 }}>Branded gear<br/>for your <em style={{ fontWeight: 400, fontStyle: 'italic' }}>team.</em></h1>
            <p style={{ fontSize: 16, color: '#666', maxWidth: 460, marginTop: 18, lineHeight: 1.55 }}>Browse, customize and order apparel and promo with on-demand decoration. Quotes within 24h.</p>
            <div style={{ marginTop: 28, display: 'flex', gap: 12 }}>
              <button style={{ padding: '14px 22px', borderRadius: 999, background: '#1b1b1b', color: '#fff', border: 'none', fontWeight: 600, fontSize: 13, letterSpacing: '0.06em', cursor: 'pointer', textTransform: 'uppercase' }}>Shop now →</button>
            </div>
          </div>
          <div style={{ aspectRatio: '4/5', borderRadius: 28, background: '#f4f4f5', overflow: 'hidden', position: 'relative' }}>
            <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 0 }} />
          </div>
        </div>

        {/* Categories strip */}
        <div style={{ marginBottom: 80 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 24 }}>
            <h2 style={{ fontSize: 32, fontWeight: 700, margin: 0 }}>Shop by category</h2>
            <a style={{ fontSize: 13, fontWeight: 600, color: PRIMARY, cursor: 'pointer' }}>View all →</a>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
            {[['Apparel','#fbe5e2'],['Headwear','#fff1d4'],['Drinkware','#e8f0e0'],['Bags','#e6e9f5']].map(([n,t]) => (
              <div key={n} style={{ borderRadius: 20, overflow: 'hidden', cursor: 'pointer' }}>
                <div style={{ aspectRatio: '1/1', background: t, position: 'relative' }}>
                  <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 0, background: 'transparent' }} />
                </div>
                <div style={{ padding: '14px 4px', fontSize: 16, fontWeight: 600 }}>{n}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Featured products — Most cards */}
        <div style={{ marginBottom: 100 }}>
          <h2 style={{ fontSize: 32, fontWeight: 700, marginBottom: 24 }}>Featured</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
            {[['Run Max 88','For Running',180],['Workout Revolution','Workout',120],['KL 17 BS','Training',80],['Flex Armour','Walking',140]].map(([t,c,p]) => (
              <article key={t} style={{ borderRadius: 20, overflow: 'hidden', cursor: 'pointer' }}>
                <div style={{ position: 'relative', borderRadius: 20, overflow: 'hidden', marginBottom: -20, aspectRatio: '4/3', background: '#f4f4f5' }}>
                  <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 0, background: 'transparent' }} />
                </div>
                <div style={{ padding: '14px 20px 14px 24px', borderRadius: 20, background: '#fff', position: 'relative', zIndex: 1 }}>
                  <div style={{ fontSize: 12, color: PRIMARY, marginBottom: 4 }}>{c}</div>
                  <div style={{ fontSize: 18, fontWeight: 600, width: 'calc(100% - 50px)' }}>{t}</div>
                  <div style={{ display: 'flex', alignItems: 'center', marginTop: 8 }}>
                    <div style={{ fontSize: 14, color: '#666', fontWeight: 500 }}>${p}.00</div>
                    <button style={{ position: 'absolute', right: 0, bottom: 0, background: '#777', width: 45, height: 45, borderTopLeftRadius: 16, borderBottomRightRadius: 20, border: 'none', color: '#fff', display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
                      <Icon name="plus" size={22} stroke={2.2} />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>

        {/* How it works */}
        <div style={{ background: '#1b1b1b', color: '#fff', borderRadius: 32, padding: '56px 48px', marginBottom: 100 }}>
          <h2 style={{ fontSize: 36, fontWeight: 700, marginTop: 0, marginBottom: 36, color: '#fff' }}>How it works</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
            {[['01','Browse the store','Pick from your distributor\'s curated catalog.'],['02','Customize','Pick sizes, colors and decoration. Upload artwork.'],['03','Approve & order','Review your proposal, approve, and we produce.']].map(([n,t,d]) => (
              <div key={n}>
                <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.12em', color: PRIMARY, marginBottom: 8 }}>STEP {n}</div>
                <div style={{ fontSize: 22, fontWeight: 700, marginBottom: 6 }}>{t}</div>
                <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)' }}>{d}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </CurtainShell>
  );
}

// ── CART ────────────────────────────────────────────────────
function StoreCart() {
  const b = React.useContext(BrandContext);
  const items = [
    { t: 'Run Max 88', sub: 'For Running · Size 42 · Black', q: 2, p: 180 },
    { t: 'KL 17 BS',    sub: 'Training · Size 41 · Yellow', q: 1, p: 80 },
    { t: 'Workout Revolution', sub: 'Workout · Size 43 · Red', q: 1, p: 120 },
  ];
  const subtotal = items.reduce((a, i) => a + i.p * i.q, 0);
  return (
    <CurtainShell footer={<SimpleFooter />} footerHeight={80}>
      <BrandedNav active="CART" signedIn cartCount={4} userName="Yan" />
      <div style={{ padding: '40px 48px 0' }}>
        <h1 style={{ fontSize: 56, fontWeight: 800, letterSpacing: -0.03, margin: 0 }}>Cart</h1>
        <div style={{ fontSize: 13, color: '#999', marginTop: 6 }}>{items.length} items · subject to distributor approval</div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 32, marginTop: 40 }}>
          <div>
            {items.map((it, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '20px 0', borderTop: i>0?'1px solid #f1f1f1':'none' }}>
                <div style={{ width: 80, height: 80, borderRadius: 16, background: '#f4f4f5', position: 'relative', overflow: 'hidden' }}>
                  <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 0, background: 'transparent' }} />
                </div>
                <div>
                  <div style={{ fontSize: 16, fontWeight: 600 }}>{it.t}</div>
                  <div style={{ fontSize: 12, color: '#999', marginTop: 2 }}>{it.sub}</div>
                  <a style={{ fontSize: 12, color: PRIMARY, marginTop: 6, display: 'inline-block', cursor: 'pointer' }}>Add decoration →</a>
                </div>
                <div style={{ flex: 1 }} />
                <div style={{ display: 'flex', alignItems: 'center', border: '1.5px solid #e5e7eb', borderRadius: 999, height: 36 }}>
                  <button style={{ width: 32, border: 'none', background: 'transparent', cursor: 'pointer', display: 'grid', placeItems: 'center' }}><Icon name="minus" size={12} stroke={2} /></button>
                  <div style={{ width: 28, textAlign: 'center', fontSize: 13, fontWeight: 600 }}>{it.q}</div>
                  <button style={{ width: 32, border: 'none', background: 'transparent', cursor: 'pointer', display: 'grid', placeItems: 'center' }}><Icon name="plus" size={12} stroke={2} /></button>
                </div>
                <div style={{ width: 80, textAlign: 'right', fontSize: 16, fontWeight: 700 }}>${it.p * it.q}.00</div>
                <button style={{ background: 'transparent', border: 'none', color: '#999', cursor: 'pointer', padding: 4 }}><Icon name="trash" size={16} /></button>
              </div>
            ))}
            <div style={{ marginTop: 32 }}>
              <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', color: '#999', textTransform: 'uppercase', marginBottom: 8 }}>Promo code</div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input placeholder="Enter code" style={{ flex: 1, padding: '12px 14px', border: '1.5px solid #e5e7eb', borderRadius: 999, fontSize: 13 }} />
                <button style={{ padding: '12px 20px', borderRadius: 999, border: '1.5px solid #1b1b1b', background: 'transparent', fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Apply</button>
              </div>
            </div>
          </div>

          {/* Order summary */}
          <aside style={{ background: '#fafafa', borderRadius: 24, padding: 28, height: 'fit-content', position: 'sticky', top: 16 }}>
            <h3 style={{ margin: 0, fontSize: 20, fontWeight: 700 }}>Order summary</h3>
            <div style={{ marginTop: 18 }}>
              {[['Subtotal',`$${subtotal}.00`],['Shipping','Calculated next'],['Estimated tax','—']].map(([k,v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', fontSize: 13, color: '#666' }}>
                  <span>{k}</span><span>{v}</span>
                </div>
              ))}
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '14px 0 6px', borderTop: '1px solid #ececec', marginTop: 10, fontSize: 18, fontWeight: 700 }}>
                <span>Total</span><span>${subtotal}.00</span>
              </div>
            </div>
            <button style={{ width: '100%', marginTop: 16, padding: '14px', borderRadius: 999, background: PRIMARY, color: '#fff', border: 'none', fontWeight: 700, fontSize: 13, letterSpacing: '0.08em', textTransform: 'uppercase', cursor: 'pointer' }}>Continue to checkout</button>
            <div style={{ fontSize: 11, color: '#999', marginTop: 12, textAlign: 'center' }}>Or save as proposal for approval</div>
          </aside>
        </div>
      </div>
    </CurtainShell>
  );
}

// ── CHECKOUT ────────────────────────────────────────────────
function StoreCheckout() {
  const b = React.useContext(BrandContext);
  const [step] = React.useState(1);
  const steps = ['Address','Shipping','Payment'];
  return (
    <CurtainShell footer={<SimpleFooter />} footerHeight={80}>
      <BrandedNav active="CART" signedIn cartCount={4} userName="Yan" />
      <div style={{ padding: '40px 48px 0' }}>
        <h1 style={{ fontSize: 56, fontWeight: 800, letterSpacing: -0.03, margin: 0 }}>Checkout</h1>

        <div style={{ display: 'flex', gap: 16, marginTop: 28, marginBottom: 32 }}>
          {steps.map((s, i) => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 10, opacity: i <= step ? 1 : 0.4 }}>
              <span style={{ width: 28, height: 28, borderRadius: 999, background: i <= step ? '#1b1b1b' : '#e5e7eb', color: i <= step ? '#fff' : '#999', display: 'grid', placeItems: 'center', fontSize: 12, fontWeight: 700 }}>{i+1}</span>
              <span style={{ fontSize: 13, fontWeight: 600, color: i <= step ? '#1b1b1b' : '#999' }}>{s}</span>
              {i < 2 && <span style={{ width: 36, height: 1, background: '#e5e7eb', marginLeft: 4 }} />}
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 32 }}>
          <div>
            <div style={{ border: '1px solid #ececec', borderRadius: 20, padding: 24, marginBottom: 16 }}>
              <h3 style={{ margin: '0 0 16px', fontSize: 16, fontWeight: 700 }}>Shipping address</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                {[['First name','Yan'],['Last name','Charitar'],['Company','Yan Financial'],['Email','info@yan-financial.ca']].map(([l,v]) => (
                  <div key={l}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: '#999', marginBottom: 4 }}>{l}</div>
                    <input defaultValue={v} style={{ width: '100%', padding: '10px 12px', border: '1.5px solid #ececec', borderRadius: 8, fontSize: 13, boxSizing: 'border-box' }} />
                  </div>
                ))}
                <div style={{ gridColumn: 'span 2' }}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: '#999', marginBottom: 4 }}>Address</div>
                  <input defaultValue="123 Bloor St W" style={{ width: '100%', padding: '10px 12px', border: '1.5px solid #ececec', borderRadius: 8, fontSize: 13, boxSizing: 'border-box' }} />
                </div>
                {[['City','Toronto'],['Province','Ontario'],['Postal code','M5S 1M2']].map(([l,v]) => (
                  <div key={l}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: '#999', marginBottom: 4 }}>{l}</div>
                    <input defaultValue={v} style={{ width: '100%', padding: '10px 12px', border: '1.5px solid #ececec', borderRadius: 8, fontSize: 13, boxSizing: 'border-box' }} />
                  </div>
                ))}
              </div>
            </div>

            <div style={{ border: '1px solid #ececec', borderRadius: 20, padding: 24, marginBottom: 16 }}>
              <h3 style={{ margin: '0 0 16px', fontSize: 16, fontWeight: 700 }}>Shipping method</h3>
              {[['Standard','5–7 business days','Free'],['Express','2–3 business days','$24.00'],['Pickup','Pick up at distributor','Free']].map(([n,d,p],i) => (
                <label key={n} style={{ display: 'flex', alignItems: 'center', padding: '14px 16px', border: `1.5px solid ${i===1?'#1b1b1b':'#ececec'}`, borderRadius: 12, marginBottom: 8, cursor: 'pointer', background: i===1?'#fafafa':'transparent' }}>
                  <input type="radio" name="ship" defaultChecked={i===1} />
                  <div style={{ marginLeft: 12 }}>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{n}</div>
                    <div style={{ fontSize: 12, color: '#999' }}>{d}</div>
                  </div>
                  <div style={{ flex: 1 }} />
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{p}</div>
                </label>
              ))}
            </div>

            <div style={{ border: '1px solid #ececec', borderRadius: 20, padding: 24 }}>
              <h3 style={{ margin: '0 0 16px', fontSize: 16, fontWeight: 700 }}>Payment</h3>
              {[['card','Credit / debit card'],['inv','Invoice / NET-30 (account)'],['po','Purchase order']].map(([k,n],i) => (
                <label key={k} style={{ display: 'flex', alignItems: 'center', padding: '14px 16px', border: `1.5px solid ${i===1?'#1b1b1b':'#ececec'}`, borderRadius: 12, marginBottom: 8, cursor: 'pointer' }}>
                  <input type="radio" name="pay" defaultChecked={i===1} />
                  <span style={{ marginLeft: 12, fontSize: 14, fontWeight: 600 }}>{n}</span>
                </label>
              ))}
            </div>
          </div>

          <aside style={{ background: '#fafafa', borderRadius: 24, padding: 28, height: 'fit-content' }}>
            <h3 style={{ margin: 0, fontSize: 20, fontWeight: 700 }}>Summary</h3>
            <div style={{ marginTop: 14 }}>
              {[['Items (4)','$560.00'],['Shipping','$24.00'],['Tax','$76.00']].map(([k,v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', fontSize: 13, color: '#666' }}>
                  <span>{k}</span><span>{v}</span>
                </div>
              ))}
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '14px 0 6px', borderTop: '1px solid #ececec', marginTop: 10, fontSize: 18, fontWeight: 700 }}>
                <span>Total</span><span>$660.00</span>
              </div>
            </div>
            <button style={{ width: '100%', marginTop: 16, padding: '14px', borderRadius: 999, background: '#1b1b1b', color: '#fff', border: 'none', fontWeight: 700, fontSize: 13, letterSpacing: '0.08em', textTransform: 'uppercase', cursor: 'pointer' }}>Place order</button>
            <button style={{ width: '100%', marginTop: 8, padding: '14px', borderRadius: 999, background: 'transparent', color: '#1b1b1b', border: '1.5px solid #ececec', fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Save as proposal</button>
          </aside>
        </div>
      </div>
    </CurtainShell>
  );
}

// ── CUSTOM REQUEST ──────────────────────────────────────────
function StoreCustomRequest() {
  const b = React.useContext(BrandContext);
  return (
    <CurtainShell footer={<SimpleFooter />} footerHeight={80}>
      <BrandedNav active="CUSTOM REQUEST" signedIn cartCount={2} userName="Yan" />
      <div style={{ padding: '40px 48px 80px', maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.12em', color: PRIMARY, textTransform: 'uppercase' }}>Don't see what you need?</div>
        <h1 style={{ fontSize: 56, fontWeight: 800, letterSpacing: -0.03, margin: '8px 0 0' }}>Custom request</h1>
        <p style={{ fontSize: 15, color: '#666', maxWidth: 580, marginTop: 12 }}>Tell us what you're looking for. Your distributor will reach out within 1 business day with options and pricing.</p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 32 }}>
          {[
            { l: 'Project name', p: 'Annual sales kickoff merch' },
            { l: 'Target budget',   p: '$2,000 – $5,000' },
            { l: 'Quantity',        p: '50' },
            { l: 'Need by',         p: 'May 15, 2026' },
          ].map(f => (
            <div key={f.l}>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#1b1b1b', marginBottom: 6 }}>{f.l}</div>
              <input placeholder={f.p} style={{ width: '100%', boxSizing: 'border-box', padding: '12px 14px', border: '1.5px solid #ececec', borderRadius: 10, fontSize: 13 }} />
            </div>
          ))}
          <div style={{ gridColumn: 'span 2' }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#1b1b1b', marginBottom: 6 }}>Describe what you're looking for</div>
            <textarea rows={5} placeholder="Product type, materials, decoration, color preferences..." style={{ width: '100%', boxSizing: 'border-box', padding: '12px 14px', border: '1.5px solid #ececec', borderRadius: 10, fontSize: 13, resize: 'vertical' }} />
          </div>
          <div style={{ gridColumn: 'span 2' }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#1b1b1b', marginBottom: 6 }}>Reference images / artwork (optional)</div>
            <div style={{ border: '1.5px dashed #d4d4d4', borderRadius: 14, padding: 28, textAlign: 'center', color: '#999' }}>
              <Icon name="image" size={26} />
              <div style={{ fontSize: 13, marginTop: 6 }}>Drop files here, or <a style={{ color: PRIMARY, cursor: 'pointer' }}>browse</a></div>
            </div>
          </div>
        </div>

        <div style={{ marginTop: 28, display: 'flex', alignItems: 'center', gap: 12 }}>
          <button style={{ background: '#1b1b1b', color: '#fff', border: 'none', padding: '14px 28px', borderRadius: 999, fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', cursor: 'pointer' }}>Send Request →</button>
          <span style={{ fontSize: 12, color: '#999' }}>Replies within 1 business day</span>
        </div>
      </div>
    </CurtainShell>
  );
}

Object.assign(window, { StoreHome, StoreCart, StoreCheckout, StoreCustomRequest });
