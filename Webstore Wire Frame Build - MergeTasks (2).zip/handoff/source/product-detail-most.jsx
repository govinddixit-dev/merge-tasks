/* global React, Header, Ph, Icon */
// Single Product — Most template style
// Aesthetic: 20pt rounded cards, primary hsl(12,85%,58%) orange-red,
// uppercase breadcrumbs, big 40-56px titles, distinctive "+" button with
// asymmetric rounded corners, tucked content panel under hero image.

const MOST_COLORS = [
  { n: 'Black',  c: '#1b1b1b' },
  { n: 'Navy',   c: '#1f3a5f' },
  { n: 'Stone',  c: '#c9bd9e' },
  { n: 'Red',    c: '#c4392b' },
  { n: 'White',  c: '#f1ece0' },
];
const MOST_SIZES = ['39','40','41','42','43','44'];

const RELATED = [
  { t: 'Run Max 88', p: 160, cat: 'For Running', sale: false, oldP: null },
  { t: 'Sport Vibe', p: 130, cat: 'Training', sale: 'Sale', oldP: 170 },
  { t: 'Street Pro', p: 145, cat: 'Walking', sale: false, oldP: null },
  { t: 'Air Glide', p: 180, cat: 'For Running', sale: 'New', oldP: null },
];

function MostProductCard({ p }) {
  return (
    <article style={{
      borderRadius: 20,
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      background: 'transparent',
      cursor: 'pointer',
    }}>
      <div style={{ position: 'relative', borderRadius: 20, overflow: 'hidden', marginBottom: -20, aspectRatio: '4/3', background: 'var(--surface-2)' }}>
        <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 0 }} />
        {p.sale && (
          <span style={{
            position: 'absolute', top: 12, right: 12,
            width: 55, height: 55, borderRadius: 999,
            background: '#ffd233', color: '#1b1b1b',
            display: 'grid', placeItems: 'center',
            fontWeight: 700, fontSize: 13,
            zIndex: 1,
          }}>{p.sale}!</span>
        )}
      </div>
      <div style={{
        paddingLeft: 24, paddingRight: 20, paddingTop: 14, paddingBottom: 14,
        borderRadius: 20,
        background: 'var(--surface)',
        position: 'relative', zIndex: 1,
      }}>
        <div style={{ fontSize: 12, color: 'hsl(12, 85%, 58%)', marginBottom: 4, fontWeight: 500 }}>{p.cat}</div>
        <h5 style={{ fontSize: 20, fontWeight: 600, margin: 0, width: 'calc(100% - 50px)', lineHeight: 1.25, letterSpacing: -0.01 }}>{p.t}</h5>
        <div style={{ display: 'flex', alignItems: 'center', marginTop: 10 }}>
          <div style={{ fontWeight: 600, fontSize: 16, color: 'var(--ink-2)' }}>
            {p.oldP && <span style={{ textDecoration: 'line-through', opacity: 0.5, marginRight: 6 }}>${p.oldP}</span>}
            <span>${p.p}</span>
          </div>
          <div style={{ flex: 1 }} />
          <button title="Add to cart" style={{
            position: 'absolute',
            right: 0, bottom: 0,
            background: 'var(--ink-2)',
            width: 45, height: 45,
            borderTopLeftRadius: 16,
            borderBottomRightRadius: 20,
            border: 'none',
            display: 'grid', placeItems: 'center',
            color: '#fff', cursor: 'pointer',
          }}>
            <Icon name="plus" size={22} stroke={2.2} />
          </button>
        </div>
      </div>
    </article>
  );
}

function ProductDetailMost() {
  const [qty, setQty] = React.useState(1);
  const [tab, setTab] = React.useState(0);
  const [imgIdx, setImgIdx] = React.useState(0);

  const PRIMARY = 'hsl(12, 85%, 58%)';
  const tabs = ['Description', 'Additional Information', 'Review (1)'];

  return (
    <div className="art-inner" style={{ '--accent': PRIMARY, background: 'var(--bg)' }}>
      <Header active="shop" showCart cartCount={2} />
      <div style={{ padding: '40px 64px 56px', maxWidth: 1400, margin: '0 auto' }}>
        {/* Breadcrumb */}
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--ink-3)', marginBottom: 32, fontWeight: 500 }}>
          <span>Shop</span>
          <span style={{ opacity: 0.4 }}>/</span>
          <span>For Running</span>
          <span style={{ opacity: 0.4 }}>/</span>
          <span style={{ color: 'var(--ink)' }}>Run Max 88</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'start' }}>
          {/* LEFT — gallery w/ swiper-style pagination */}
          <div>
            <div style={{ position: 'relative', aspectRatio: '1/1', borderRadius: 28, overflow: 'hidden', background: 'var(--surface-2)' }}>
              <Ph style={{ position: 'absolute', inset: 0, border: 'none', borderRadius: 0 }} />
              {/* Nav arrows */}
              <button style={{
                position: 'absolute', left: 16, top: '50%', transform: 'translateY(-50%)',
                width: 48, height: 48, borderRadius: 999,
                background: 'rgba(255,255,255,0.9)', border: 'none',
                display: 'grid', placeItems: 'center', cursor: 'pointer',
                boxShadow: '0 2px 10px rgba(0,0,0,0.08)',
              }}>
                <Icon name="chevRight" size={18} stroke={2} style={{ transform: 'rotate(180deg)' }} />
              </button>
              <button style={{
                position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%)',
                width: 48, height: 48, borderRadius: 999,
                background: 'rgba(255,255,255,0.9)', border: 'none',
                display: 'grid', placeItems: 'center', cursor: 'pointer',
                boxShadow: '0 2px 10px rgba(0,0,0,0.08)',
              }}>
                <Icon name="chevRight" size={18} stroke={2} />
              </button>
              {/* Pagination dots */}
              <div style={{ position: 'absolute', bottom: 16, left: 0, right: 0, display: 'flex', gap: 6, justifyContent: 'center' }}>
                {[0,1,2].map(i => (
                  <span key={i} onClick={()=>setImgIdx(i)} style={{
                    width: i===imgIdx?24:8, height: 8, borderRadius: 999,
                    background: i===imgIdx?PRIMARY:'rgba(0,0,0,0.2)',
                    cursor: 'pointer', transition: 'all 0.2s',
                  }} />
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT — product info */}
          <div style={{ paddingTop: 8 }}>
            <h1 style={{ fontSize: 52, fontWeight: 600, margin: 0, letterSpacing: -0.03, lineHeight: 1.05 }}>Run Max 88</h1>
            <p style={{ marginTop: 20, marginBottom: 0, fontSize: 32, fontWeight: 600, color: 'var(--ink-2)' }}>
              <span style={{ color: 'var(--ink-3)', fontWeight: 500 }}>$</span>160
            </p>

            {/* Rating */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 14, marginBottom: 24 }}>
              <div style={{ display: 'flex', gap: 2, color: '#ffb800' }}>
                {[0,1,2,3,4].map(i => <Icon key={i} name="star" size={14} stroke={1.5} />)}
              </div>
              <span style={{ fontSize: 14, fontWeight: 600 }}>5.00</span>
              <a style={{ fontSize: 13, color: 'var(--ink-3)', textDecoration: 'underline', cursor: 'pointer' }}>(1 customer review)</a>
            </div>

            <p style={{ fontSize: 15, lineHeight: 1.6, color: 'var(--ink-2)', marginTop: 0, marginBottom: 20 }}>
              Phosfluorescently benchmark unique e-services whereas transparent collaboration and idea-sharing. Enthusiastically communicate maintainable networks via global metrics.
            </p>

            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px', background: 'rgba(46, 204, 113, 0.12)', color: 'rgb(30, 150, 80)', borderRadius: 999, fontSize: 12, fontWeight: 600, marginBottom: 28 }}>
              <span style={{ width: 8, height: 8, borderRadius: 999, background: 'rgb(30, 150, 80)' }} />
              7 in stock
            </div>

            {/* Color + Size */}
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--ink-3)', marginBottom: 10, fontWeight: 600 }}>Color</div>
              <div style={{ display: 'flex', gap: 10 }}>
                {MOST_COLORS.map((c, i) => (
                  <div key={c.n} title={c.n} style={{
                    width: 32, height: 32, borderRadius: 999,
                    background: c.c, cursor: 'pointer',
                    boxShadow: i===1 ? `0 0 0 2px var(--bg), 0 0 0 4px ${PRIMARY}` : '0 0 0 1px var(--border-strong)',
                  }} />
                ))}
              </div>
            </div>

            <div style={{ marginBottom: 28 }}>
              <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--ink-3)', marginBottom: 10, fontWeight: 600 }}>Size</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {MOST_SIZES.map((s, i) => (
                  <button key={s} style={{
                    width: 48, height: 48, borderRadius: 12,
                    background: i===3 ? PRIMARY : 'transparent',
                    color: i===3 ? '#fff' : 'var(--ink)',
                    border: `1.5px solid ${i===3 ? PRIMARY : 'var(--border-strong)'}`,
                    fontSize: 14, fontWeight: 600,
                    cursor: 'pointer',
                  }}>{s}</button>
                ))}
              </div>
            </div>

            {/* Qty + Add to cart row */}
            <div style={{ display: 'flex', gap: 12, alignItems: 'stretch', marginBottom: 32 }}>
              <div style={{
                display: 'flex', alignItems: 'center',
                border: '1.5px solid var(--border-strong)',
                borderRadius: 999, overflow: 'hidden',
                height: 56,
              }}>
                <button onClick={() => qty > 1 && setQty(qty-1)} style={{
                  width: 48, height: '100%', border: 'none', background: 'transparent',
                  cursor: 'pointer', display: 'grid', placeItems: 'center', color: 'var(--ink)',
                }}>
                  <Icon name="minus" size={16} stroke={2} />
                </button>
                <input
                  value={qty}
                  onChange={e => setQty(Math.max(1, Math.min(7, +e.target.value || 1)))}
                  style={{ width: 44, height: '100%', border: 'none', background: 'transparent', textAlign: 'center', fontSize: 16, fontWeight: 600, color: 'var(--ink)', outline: 'none' }}
                />
                <button onClick={() => qty < 7 && setQty(qty+1)} style={{
                  width: 48, height: '100%', border: 'none', background: 'transparent',
                  cursor: 'pointer', display: 'grid', placeItems: 'center', color: 'var(--ink)',
                }}>
                  <Icon name="plus" size={16} stroke={2} />
                </button>
              </div>
              <button style={{
                flex: 1,
                background: PRIMARY, color: '#fff',
                border: 'none', borderRadius: 999,
                fontSize: 14, fontWeight: 700, letterSpacing: '0.08em',
                textTransform: 'uppercase',
                cursor: 'pointer',
                height: 56,
                transition: 'filter 0.15s',
              }}>Add to cart</button>
              <button style={{
                width: 56, height: 56, borderRadius: 999,
                border: '1.5px solid var(--border-strong)',
                background: 'transparent',
                display: 'grid', placeItems: 'center',
                cursor: 'pointer', color: 'var(--ink-2)',
              }}>
                <Icon name="heart" size={18} />
              </button>
            </div>

            {/* Meta */}
            <div style={{ paddingTop: 20, borderTop: '1px solid var(--border)', display: 'flex', flexDirection: 'column', gap: 10, fontSize: 13, color: 'var(--ink-2)' }}>
              <div><strong style={{ color: 'var(--ink)', marginRight: 8 }}>SKU:</strong> 161056</div>
              <div><strong style={{ color: 'var(--ink)', marginRight: 8 }}>Category:</strong> <a style={{ color: PRIMARY, textDecoration: 'none', cursor: 'pointer' }}>For Running</a></div>
              <div>
                <strong style={{ color: 'var(--ink)', marginRight: 8 }}>Tags:</strong>
                {['Life','Move','Sport','Trainers'].map((t,i) => (
                  <React.Fragment key={t}>
                    <a style={{ color: PRIMARY, textDecoration: 'none', cursor: 'pointer' }}>{t}</a>
                    {i < 3 && <span style={{ color: 'var(--ink-3)' }}>, </span>}
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ marginTop: 80 }}>
          <div style={{ display: 'flex', gap: 0, borderBottom: '1px solid var(--border)', marginBottom: 32 }}>
            {tabs.map((t, i) => (
              <button key={t} onClick={()=>setTab(i)} style={{
                background: 'transparent', border: 'none',
                padding: '14px 24px',
                fontSize: 14, fontWeight: 600,
                letterSpacing: '0.02em',
                color: tab===i ? 'var(--ink)' : 'var(--ink-3)',
                borderBottom: tab===i ? `2px solid ${PRIMARY}` : '2px solid transparent',
                marginBottom: -1,
                cursor: 'pointer',
              }}>{t}</button>
            ))}
          </div>

          <div style={{ fontSize: 15, lineHeight: 1.75, color: 'var(--ink-2)', maxWidth: 900 }}>
            {tab === 0 && (
              <p style={{ margin: 0 }}>
                Credibly e-enable e-business materials with competitive products. Enthusiastically extend unique leadership before timely users. Synergistically scale B2C e-business rather than quality products. Synergistically incubate extensible outsourcing via magnetic sources.
              </p>
            )}
            {tab === 1 && (
              <div style={{ maxWidth: 640 }}>
                <h3 style={{ fontSize: 22, fontWeight: 600, marginBottom: 16 }}>Additional information</h3>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <tbody>
                    {[['Size','39, 40, 41, 42, 43, 44'],['Collection','Most Sport Pro'],['Upper Material','Leather']].map(([k,v]) => (
                      <tr key={k} style={{ borderTop: '1px solid var(--border)' }}>
                        <th style={{ textAlign: 'left', padding: '14px 20px 14px 0', fontWeight: 600, color: 'var(--ink)', width: 200 }}>{k}</th>
                        <td style={{ padding: '14px 0', color: 'var(--ink-2)' }}>{v}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {tab === 2 && (
              <div>
                <h3 style={{ fontSize: 22, fontWeight: 600, marginBottom: 16 }}>Be the first to review</h3>
                <div className="tiny" style={{ color: 'var(--ink-3)' }}>Review form with name, email, rating, and message.</div>
              </div>
            )}
          </div>
        </div>

        {/* Related products */}
        <div style={{ marginTop: 100 }}>
          <h2 style={{ fontSize: 36, fontWeight: 600, letterSpacing: -0.02, marginBottom: 32 }}>Related products</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24 }}>
            {RELATED.map((p,i) => <MostProductCard key={i} p={p} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ProductDetailMost });
