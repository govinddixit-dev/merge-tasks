/* global React, Header, Ph, Icon */
// Product listing / filter page variations

const PRODUCTS = [
  { name: 'Classic Logo Tee', price: 18, tags: ['S','M','L','XL'], color: '#2d2b28' },
  { name: 'Structured Cap', price: 22, tags: ['OS'], color: '#b8a27a' },
  { name: 'Insulated Bottle', price: 28, tags: ['17oz'], color: '#556b7a' },
  { name: 'Canvas Tote', price: 14, tags: ['Standard'], color: '#d4c8ab' },
  { name: 'Softshell Jacket', price: 74, tags: ['S','M','L','XL','2XL'], color: '#1f2a33' },
  { name: 'Ceramic Mug', price: 12, tags: ['11oz','15oz'], color: '#efeae2' },
  { name: 'Notebook Set', price: 9, tags: ['A5'], color: '#c43d2a' },
  { name: 'Wireless Charger', price: 32, tags: ['Std'], color: '#2a2a2a' },
];

const SortControl = () => (
  <select className="select" style={{ width: 160 }}>
    <option>Default sorting</option>
    <option>Price: low → high</option>
    <option>Price: high → low</option>
    <option>Newest</option>
    <option>Best-selling</option>
  </select>
);

const ProductCard = ({ p, compact }) => (
  <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius)', overflow: 'hidden', background: 'var(--bg)', position: 'relative', cursor: 'pointer' }}>
    <div style={{ aspectRatio: '1', background: 'var(--surface)', position: 'relative' }}>
      <Ph style={{ position: 'absolute', inset: 12, border: 'none' }} />
      <button style={{ position: 'absolute', bottom: 10, right: 10, width: 32, height: 32, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--bg)', display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
        <Icon name="plus" size={14} stroke={2} />
      </button>
    </div>
    <div style={{ padding: compact ? '10px 12px' : '14px 14px' }}>
      <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
        {p.tags.slice(0,3).map(t => <span key={t} className="tag">{t}</span>)}
      </div>
      <div style={{ fontWeight: 500, fontSize: 13 }}>{p.name}</div>
      <div style={{ fontSize: 13, marginTop: 2 }}>${p.price.toFixed(2)}</div>
    </div>
  </div>
);

const PriceRange = () => (
  <div>
    <div style={{ position: 'relative', height: 30, marginTop: 4 }}>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 14, height: 3, background: 'var(--surface-2)', borderRadius: 2 }} />
      <div style={{ position: 'absolute', left: '20%', right: '25%', top: 14, height: 3, background: 'var(--accent)', borderRadius: 2 }} />
      <div style={{ position: 'absolute', left: '20%', top: 9, width: 13, height: 13, borderRadius: 999, background: 'var(--bg)', border: '2px solid var(--accent)', transform: 'translateX(-50%)' }} />
      <div style={{ position: 'absolute', left: '75%', top: 9, width: 13, height: 13, borderRadius: 999, background: 'var(--bg)', border: '2px solid var(--accent)', transform: 'translateX(-50%)' }} />
    </div>
    <div className="row" style={{ justifyContent: 'space-between' }}>
      <span className="tiny muted">Price: $50 – $180</span>
      <a className="tiny" style={{ color: 'var(--accent)', cursor: 'pointer', fontWeight: 500 }}>Filter</a>
    </div>
  </div>
);

const FilterGroups = () => (
  <>
    <div className="tk-row" style={{ marginBottom: 20 }}>
      <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-3)', marginBottom: 10 }}>Filter by Price</div>
      <PriceRange />
    </div>

    <div style={{ marginBottom: 20 }}>
      <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-3)', marginBottom: 10 }}>Products</div>
      <div className="col gap-8">
        {PRODUCTS.slice(0,4).map((p,i) => (
          <div key={i} className="row gap-8" style={{ alignItems: 'center' }}>
            <Ph style={{ width: 36, height: 36, flexShrink: 0 }} />
            <div className="grow">
              <div style={{ fontSize: 12 }}>{p.name}</div>
              <div className="tiny muted">${p.price.toFixed(2)}</div>
            </div>
          </div>
        ))}
      </div>
    </div>

    <div style={{ marginBottom: 20 }}>
      <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-3)', marginBottom: 10 }}>Product Categories</div>
      <div className="col gap-4 tiny">
        {['Apparel','Drinkware','Bags','Print'].map(c => (
          <label key={c} className="row gap-8" style={{ alignItems: 'center', cursor: 'pointer' }}>
            <input type="checkbox" defaultChecked={c==='Apparel'} /> {c}
          </label>
        ))}
      </div>
    </div>

    <div>
      <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-3)', marginBottom: 10 }}>Product Tags</div>
      <div className="row gap-4" style={{ flexWrap: 'wrap' }}>
        {['New','Sale','Bulk','Eco','Limited'].map(t => <span key={t} className="chip">{t}</span>)}
      </div>
    </div>
  </>
);

// ──────────────── V1: Right sidebar (PDF) ────────────────
function ProductListV1() {
  return (
    <div className="art-inner">
      <Header active="shop" showCart />
      <div style={{ padding: '32px 48px' }}>
        <div style={{ fontSize: 12, color: 'var(--ink-3)', marginBottom: 6 }}>Shop / Apparel</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 40 }}>
          <div>
            <div className="row" style={{ alignItems: 'center', marginBottom: 16 }}>
              <h1 style={{ fontSize: 24 }}>Apparel</h1>
              <div className="space" />
              <SortControl />
            </div>
            <div className="tiny muted" style={{ marginBottom: 14 }}>Showing 1–8 of 24 results</div>
            <div className="row gap-8" style={{ marginBottom: 20, flexWrap:'wrap' }}>
              {['All','Tees','Hats','Polos','Hoodies','Outerwear'].map((t,i)=>(
                <span key={t} className={`chip ${i===0?'active':''}`}>{t}</span>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
              {PRODUCTS.map((p,i) => <ProductCard key={i} p={p} compact />)}
            </div>
            <div className="row" style={{ marginTop: 28, justifyContent: 'center', alignItems: 'center', gap: 12 }}>
              <span style={{ width: 28, height: 28, borderRadius: 999, background: 'var(--accent)', color: 'var(--accent-ink)', display: 'grid', placeItems: 'center', fontSize: 12, fontWeight: 600 }}>1</span>
              <span className="tiny" style={{ cursor: 'pointer' }}>2</span>
              <span className="tiny" style={{ cursor: 'pointer', color: 'var(--ink-2)' }}>Next →</span>
            </div>
          </div>
          <aside>
            <FilterGroups />
          </aside>
        </div>
      </div>
    </div>
  );
}

// ──────────────── V2: Left sidebar w/ collapsible ────────────────
function ProductListV2() {
  return (
    <div className="art-inner">
      <Header active="shop" variant="mega" showCart />
      <div style={{ padding: '28px 48px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr', gap: 36 }}>
          <aside>
            <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Filters</div>
            {[
              { label:'Category', items:['All','Apparel','Drinkware','Bags','Print'] },
              { label:'Size', items:['XS','S','M','L','XL','2XL'], chip: true },
              { label:'Color', items:['Black','Navy','Stone','Red','White'], swatch:true },
            ].map((grp,gi) => (
              <div key={gi} style={{ paddingBottom: 16, marginBottom: 16, borderBottom: '1px solid var(--border)' }}>
                <div className="row" style={{ alignItems:'center', marginBottom: 10, cursor: 'pointer' }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{grp.label}</div>
                  <div className="space" />
                  <Icon name="chevDown" size={14} />
                </div>
                {grp.chip ? (
                  <div className="row gap-4" style={{ flexWrap: 'wrap' }}>
                    {grp.items.map((it,i)=> <span key={i} className={`chip ${i===1?'active':''}`}>{it}</span>)}
                  </div>
                ) : grp.swatch ? (
                  <div className="row gap-8">
                    {['#1b1b1b','#1f3a5f','#c9bd9e','#c4392b','#f1ece0'].map((c,i)=>(
                      <div key={i} style={{ width: 22, height: 22, borderRadius: 999, background: c, border: '2px solid var(--bg)', boxShadow: i===0?'0 0 0 2px var(--accent)':'0 0 0 1px var(--border-strong)', cursor:'pointer' }} />
                    ))}
                  </div>
                ) : (
                  <div className="col gap-4 tiny">
                    {grp.items.map((c,i) => (
                      <label key={c} className="row gap-8" style={{ alignItems:'center', cursor:'pointer' }}>
                        <input type="checkbox" defaultChecked={i===1} /> {c}
                      </label>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div style={{ paddingBottom: 16, marginBottom: 16, borderBottom: '1px solid var(--border)' }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10 }}>Price</div>
              <PriceRange />
            </div>
          </aside>
          <div>
            <div className="row" style={{ alignItems:'center', marginBottom: 8 }}>
              <div>
                <h1 style={{ fontSize: 24 }}>Apparel</h1>
                <div className="tiny muted" style={{ marginTop: 4 }}>Showing 1–8 of 24 results</div>
              </div>
              <div className="space" />
              <div className="row gap-8">
                <button className="btn btn-sm" style={{ padding: 8 }}><Icon name="grid" size={14} /></button>
                <button className="btn btn-sm" style={{ padding: 8, opacity: 0.5 }}><Icon name="list" size={14} /></button>
                <SortControl />
              </div>
            </div>
            <div className="hr" />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
              {PRODUCTS.slice(0,6).map((p,i)=><ProductCard key={i} p={p} />)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ──────────────── V3: Top collapsible filter bar ────────────────
function ProductListV3() {
  return (
    <div className="art-inner">
      <Header active="shop" variant="sticky" showCart />
      <div style={{ padding: '28px 48px' }}>
        <div className="row" style={{ alignItems: 'baseline', marginBottom: 14 }}>
          <div>
            <div className="tiny muted">Shop / Apparel</div>
            <h1 style={{ fontSize: 28, marginTop: 4 }}>Apparel</h1>
          </div>
          <div className="space" />
          <div className="tiny muted">24 results</div>
        </div>

        <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '10px 14px', display: 'flex', gap: 10, alignItems: 'center', background: 'var(--surface)', marginBottom: 20 }}>
          <Icon name="filter" size={15} stroke={1.5} />
          <span style={{ fontSize: 13, fontWeight: 500 }}>Filters</span>
          {[
            { l:'Category', v:'Apparel' },
            { l:'Size', v:'M, L' },
            { l:'Color', v:'Any' },
            { l:'Price', v:'$50 – $180' },
          ].map((f,i)=> (
            <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 10px', border: '1px solid var(--border-strong)', background: 'var(--bg)', borderRadius: 999, fontSize: 12 }}>
              <span className="muted">{f.l}:</span> {f.v}
              <Icon name="chevDown" size={11} />
            </span>
          ))}
          <div className="space" />
          <SortControl />
        </div>

        <div className="row gap-8" style={{ marginBottom: 20, flexWrap:'wrap' }}>
          <span style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'4px 10px', borderRadius: 999, background:'var(--accent-soft)', fontSize: 12, color:'var(--ink)' }}>
            Size: M <Icon name="x" size={11} />
          </span>
          <span style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'4px 10px', borderRadius: 999, background:'var(--accent-soft)', fontSize: 12, color:'var(--ink)' }}>
            Size: L <Icon name="x" size={11} />
          </span>
          <span className="tiny" style={{ color:'var(--ink-3)', padding: '4px 0', cursor:'pointer' }}>Clear all</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
          {PRODUCTS.map((p,i)=><ProductCard key={i} p={p} compact />)}
        </div>

        <div className="row" style={{ marginTop: 28, justifyContent:'center', gap: 6 }}>
          {[1,2,3,'…',6].map((n,i)=>(
            <span key={i} style={{ width: 32, height: 32, borderRadius: 6, display:'grid', placeItems:'center', fontSize: 12, border: n===1?'1px solid var(--accent)':'1px solid var(--border)', background: n===1?'var(--accent-soft)':'var(--bg)', cursor:'pointer' }}>{n}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ProductListV1, ProductListV2, ProductListV3 });
