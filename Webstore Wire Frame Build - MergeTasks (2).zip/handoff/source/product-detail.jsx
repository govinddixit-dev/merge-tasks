/* global React, Header, Ph, Icon */
// Single product page variations — the add-to-list / add-list-to-cart flow

const COLORS = [
  { n: 'Black',  c: '#1b1b1b' },
  { n: 'Navy',   c: '#1f3a5f' },
  { n: 'Stone',  c: '#c9bd9e' },
  { n: 'Red',    c: '#c4392b' },
  { n: 'White',  c: '#f1ece0' },
];
const SIZES = ['XS','S','M','L','XL','2XL'];

const Breadcrumb = () => (
  <div className="tiny muted" style={{ marginBottom: 20 }}>
    Shop / Apparel / <span style={{ color: 'var(--ink)' }}>Classic Logo Tee</span>
  </div>
);

const Gallery = () => (
  <div>
    <div style={{ aspectRatio: '1', background: 'var(--surface)', borderRadius: 'var(--radius)', position: 'relative', marginBottom: 12 }}>
      <Ph style={{ position: 'absolute', inset: 20, border: 'none' }} />
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
      {[0,1,2,3].map(i => (
        <div key={i} style={{ aspectRatio: '1', background: 'var(--surface)', border: i===0?'2px solid var(--accent)':'1px solid var(--border)', borderRadius: 'var(--radius-sm)' }} />
      ))}
    </div>
  </div>
);

const TabBar = ({ tabs = ['Products','Reviews'] }) => (
  <div className="row" style={{ borderBottom: '1px solid var(--border)', marginBottom: 14 }}>
    {tabs.map((t,i)=>(
      <button key={t} style={{ background:'transparent', border:'none', padding: '8px 14px', cursor:'pointer', fontSize: 13, fontWeight: 500, color: i===0?'var(--ink)':'var(--ink-3)', borderBottom: i===0?'2px solid var(--accent)':'2px solid transparent', marginBottom: -1 }}>{t}</button>
    ))}
  </div>
);

const MetaRows = () => (
  <div className="col gap-8 tiny" style={{ color: 'var(--ink-2)' }}>
    {[['SKU', 'TEE-CLS-001'],['Category','Apparel · Tees'],['Tags','cotton · unisex · bestseller']].map(([k,v])=>(
      <div key={k} className="row" style={{ paddingBottom: 6, borderBottom: '1px dashed var(--border)' }}>
        <span style={{ width: 90, color: 'var(--ink-3)' }}>{k}</span>
        <span>{v}</span>
      </div>
    ))}
  </div>
);

// ──────────────── V1: Inline growing list (PDF intent) ────────────────
function ProductDetailV1() {
  const [items, setItems] = React.useState([
    { color: 'Navy', size: 'M', qty: 12 },
    { color: 'Navy', size: 'L', qty: 8 },
  ]);
  const add = () => setItems([...items, { color: 'Stone', size: 'S', qty: 1 }]);
  const total = items.reduce((s,i)=>s+i.qty,0);

  return (
    <div className="art-inner">
      <Header active="shop" showCart />
      <div style={{ padding: '32px 48px' }}>
        <Breadcrumb />
        <div style={{ display: 'grid', gridTemplateColumns: '460px 1fr', gap: 48 }}>
          <Gallery />
          <div>
            <h1 style={{ fontSize: 26 }}>Classic Logo Tee</h1>
            <div style={{ fontSize: 22, fontWeight: 600, marginTop: 6 }}>$18.00</div>
            <TabBar />

            <div style={{ padding: 14, border: '1px dashed var(--border-strong)', borderRadius: 'var(--radius-sm)', color: 'var(--ink-3)', fontSize: 12, marginBottom: 16 }}>
              Description text for Product info / Table or Image upload for size chart.
            </div>

            <div className="col gap-12">
              <div>
                <div className="tiny muted" style={{ marginBottom: 6 }}>Color</div>
                <div className="row gap-8">
                  {COLORS.map((c,i)=>(
                    <div key={c.n} title={c.n} style={{ width: 26, height: 26, borderRadius: 999, background: c.c, border: '2px solid var(--bg)', boxShadow: i===1?'0 0 0 2px var(--accent)':'0 0 0 1px var(--border-strong)', cursor: 'pointer' }} />
                  ))}
                </div>
              </div>
              <div>
                <div className="tiny muted" style={{ marginBottom: 6 }}>Size</div>
                <div className="row gap-4" style={{ flexWrap:'wrap' }}>
                  {SIZES.map((s,i)=><span key={s} className={`chip ${i===2?'active':''}`}>{s}</span>)}
                </div>
              </div>
              <div className="tiny" style={{ color: 'var(--accent)', cursor: 'pointer', fontWeight: 500 }}>
                + Ability to add more custom fields with dropdown list selection
              </div>

              <div className="row gap-8" style={{ alignItems:'center' }}>
                <div className="row" style={{ border:'1px solid var(--border-strong)', borderRadius: 'var(--radius-sm)', overflow:'hidden' }}>
                  <button className="btn-ghost" style={{ padding: '8px 12px', border:'none', cursor:'pointer' }}>−</button>
                  <div style={{ padding: '8px 14px', borderLeft:'1px solid var(--border)', borderRight:'1px solid var(--border)', fontSize: 13, minWidth: 40, textAlign: 'center' }}>1</div>
                  <button className="btn-ghost" style={{ padding: '8px 12px', border:'none', cursor:'pointer' }}>+</button>
                </div>
                <button className="btn" onClick={add}>Add to list</button>
                <button className="btn btn-primary">{items.length>0 ? 'Add list to cart' : 'Add to cart'}</button>
              </div>

              <div style={{ marginTop: 6 }}>
                <MetaRows />
              </div>

              <div style={{ marginTop: 8 }}>
                <div className="tiny muted" style={{ marginBottom: 8 }}>Order List Summary</div>
                <div style={{ border: '1px solid var(--accent)', borderRadius: 'var(--radius-sm)', padding: items.length?0:16, background: items.length? 'var(--bg)':'var(--accent-soft)' }}>
                  {items.length === 0 ? (
                    <div className="tiny" style={{ color: 'var(--ink-2)', textAlign: 'center' }}>As items are added to list, show the order list summary here.</div>
                  ) : (
                    <>
                      {items.map((it,i)=>(
                        <div key={i} className="row gap-12" style={{ alignItems:'center', padding: '10px 14px', borderBottom: i<items.length-1?'1px solid var(--border)':'none', fontSize: 13 }}>
                          <span style={{ width: 16, height: 16, borderRadius: 999, background: COLORS.find(c=>c.n===it.color)?.c }} />
                          <span style={{ width: 80 }}>{it.color}</span>
                          <span style={{ width: 40, color: 'var(--ink-3)' }}>{it.size}</span>
                          <span className="space" />
                          <span>× {it.qty}</span>
                          <span style={{ width: 60, textAlign: 'right', fontWeight: 500 }}>${(it.qty*18).toFixed(2)}</span>
                          <button className="btn-ghost" style={{ padding: 4, color: 'var(--ink-3)' }}><Icon name="x" size={13} /></button>
                        </div>
                      ))}
                      <div className="row" style={{ padding: '10px 14px', background: 'var(--surface)', fontSize: 13 }}>
                        <span style={{ fontWeight: 600 }}>{items.length} line items · {total} units</span>
                        <span className="space" />
                        <span style={{ fontWeight: 600 }}>${(total*18).toFixed(2)}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ──────────────── V2: Matrix / table picker ────────────────
function ProductDetailV2() {
  const [grid, setGrid] = React.useState({ 'Navy-M': 12, 'Navy-L': 8, 'Black-M': 4 });
  const total = Object.values(grid).reduce((s,n)=>s+(+n||0),0);
  return (
    <div className="art-inner">
      <Header active="shop" showCart />
      <div style={{ padding: '32px 48px' }}>
        <Breadcrumb />
        <div style={{ display: 'grid', gridTemplateColumns: '420px 1fr', gap: 40 }}>
          <Gallery />
          <div>
            <h1 style={{ fontSize: 26 }}>Classic Logo Tee</h1>
            <div style={{ fontSize: 22, fontWeight: 600, marginTop: 6 }}>$18.00 <span className="tiny muted" style={{ fontWeight: 400 }}>/ unit</span></div>
            <div className="muted" style={{ marginTop: 8, maxWidth: 420, fontSize: 13 }}>Mid-weight combed cotton. Order any combination of colors & sizes in a single add.</div>

            <div style={{ marginTop: 20, fontSize: 13, fontWeight: 600, marginBottom: 8 }}>Bulk order matrix</div>

            <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', overflow: 'hidden' }}>
              <div className="row" style={{ background: 'var(--surface)', padding: '10px 12px', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ink-3)', fontWeight: 600 }}>
                <span style={{ width: 110 }}>Color \ Size</span>
                {SIZES.map(s => <span key={s} style={{ flex: 1, textAlign: 'center' }}>{s}</span>)}
                <span style={{ width: 60, textAlign: 'right' }}>Row</span>
              </div>
              {COLORS.slice(0,4).map(c => {
                const rowTotal = SIZES.reduce((s,sz)=>s+(+grid[`${c.n}-${sz}`]||0),0);
                return (
                  <div key={c.n} className="row" style={{ padding: '8px 12px', borderTop: '1px solid var(--border)', alignItems: 'center' }}>
                    <span className="row gap-8" style={{ width: 110, alignItems: 'center', fontSize: 13 }}>
                      <span style={{ width: 14, height: 14, borderRadius: 999, background: c.c, boxShadow: '0 0 0 1px var(--border-strong)' }} />
                      {c.n}
                    </span>
                    {SIZES.map(s => {
                      const v = grid[`${c.n}-${s}`] || '';
                      return (
                        <input key={s} className="input" value={v} onChange={e=>setGrid({...grid, [`${c.n}-${s}`]: e.target.value})} style={{ flex: 1, margin: '0 3px', textAlign: 'center', padding: '6px 4px', fontSize: 13 }} placeholder="—" />
                      );
                    })}
                    <span style={{ width: 60, textAlign: 'right', fontSize: 13, fontWeight: rowTotal?600:400, color: rowTotal?'var(--ink)':'var(--ink-4)' }}>{rowTotal || '—'}</span>
                  </div>
                );
              })}
            </div>

            <div className="row" style={{ marginTop: 16, alignItems:'center' }}>
              <div>
                <div className="tiny muted">Total units</div>
                <div style={{ fontSize: 24, fontWeight: 600 }}>{total}</div>
              </div>
              <div style={{ marginLeft: 24 }}>
                <div className="tiny muted">Order subtotal</div>
                <div style={{ fontSize: 24, fontWeight: 600 }}>${(total*18).toFixed(2)}</div>
              </div>
              <div className="space" />
              <div className="row gap-8">
                <button className="btn">Save as template</button>
                <button className="btn btn-primary">Add {total} units to cart</button>
              </div>
            </div>

            <div className="hr" />
            <TabBar tabs={['Details','Shipping','Reviews']} />
            <div style={{ padding: 14, border: '1px dashed var(--border-strong)', borderRadius: 'var(--radius-sm)', color: 'var(--ink-3)', fontSize: 12 }}>
              Production & shipping info, instructions, disclaimers and terms & conditions text area / Additional info area (follow same as current).
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ──────────────── V3: Stepper + chip summary + sticky list ────────────────
function ProductDetailV3() {
  const [step, setStep] = React.useState(2);
  const [list, setList] = React.useState([
    { color: 'Black', size: 'M', qty: 6 },
    { color: 'Navy', size: 'L', qty: 4 },
    { color: 'Stone', size: 'S', qty: 2 },
  ]);
  const total = list.reduce((s,i)=>s+i.qty,0);

  const Step = ({ n, label, active, done }) => (
    <div className="row gap-8" style={{ alignItems:'center', opacity: active||done?1:0.5 }}>
      <span style={{ width: 22, height: 22, borderRadius: 999, background: active?'var(--accent)':done?'var(--ink)':'var(--surface-2)', color: active||done?'#fff':'var(--ink-3)', display:'grid', placeItems:'center', fontSize: 11, fontWeight: 600 }}>
        {done ? <Icon name="check" size={11} stroke={2.5} /> : n}
      </span>
      <span style={{ fontSize: 13, fontWeight: active?600:500 }}>{label}</span>
    </div>
  );

  return (
    <div className="art-inner">
      <Header active="shop" showCart cartCount={3} />
      <div style={{ padding: '32px 48px' }}>
        <Breadcrumb />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 36 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '360px 1fr', gap: 32 }}>
            <Gallery />
            <div>
              <h1 style={{ fontSize: 24 }}>Classic Logo Tee</h1>
              <div style={{ fontSize: 20, fontWeight: 600, marginTop: 6 }}>$18.00</div>

              <div className="row gap-16" style={{ marginTop: 20, marginBottom: 20, paddingBottom: 20, borderBottom: '1px solid var(--border)' }}>
                <Step n={1} label="Color" done />
                <div style={{ flex: 0, height: 1, width: 16, background: 'var(--border-strong)' }} />
                <Step n={2} label="Size" active />
                <div style={{ flex: 0, height: 1, width: 16, background: 'var(--border-strong)' }} />
                <Step n={3} label="Qty" />
              </div>

              <div className="tiny muted" style={{ marginBottom: 6 }}>Selected</div>
              <div className="row gap-8" style={{ marginBottom: 20, flexWrap: 'wrap' }}>
                <span className="chip active"><span style={{ width: 10, height: 10, borderRadius: 999, background: '#1f3a5f' }} /> Navy</span>
                <span className="chip muted" style={{ opacity: 0.6 }}>Size: —</span>
                <span className="chip muted" style={{ opacity: 0.6 }}>Qty: —</span>
              </div>

              <div className="tiny muted" style={{ marginBottom: 8 }}>Choose a size</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8, marginBottom: 20 }}>
                {SIZES.map((s,i)=>(
                  <button key={s} className="btn" style={{ padding: '10px 0', justifyContent: 'center', borderColor: i===2?'var(--accent)':'var(--border-strong)', background: i===2?'var(--accent-soft)':'var(--bg)' }}>{s}</button>
                ))}
              </div>

              <div className="row gap-8">
                <button className="btn">Back</button>
                <div className="space" />
                <button className="btn btn-primary">Add to list →</button>
              </div>

              <div className="hr" />
              <MetaRows />
            </div>
          </div>

          {/* Sticky list panel */}
          <aside style={{ position: 'sticky', top: 20, alignSelf: 'flex-start', border: '1px solid var(--border)', borderRadius: 'var(--radius)', overflow: 'hidden', background: 'var(--bg)' }}>
            <div className="row" style={{ padding: '14px 16px', alignItems:'center', borderBottom: '1px solid var(--border)' }}>
              <span style={{ fontWeight: 600, fontSize: 14 }}>Your order list</span>
              <span className="space" />
              <span className="tag">{list.length} lines</span>
            </div>
            <div>
              {list.map((it,i)=>(
                <div key={i} className="row gap-10" style={{ alignItems:'center', padding: '12px 16px', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                  <span style={{ width: 14, height: 14, borderRadius: 999, background: COLORS.find(c=>c.n===it.color)?.c, boxShadow:'0 0 0 1px var(--border-strong)' }} />
                  <span className="grow">
                    <div>{it.color} · {it.size}</div>
                    <div className="tiny muted">× {it.qty} · ${(it.qty*18).toFixed(2)}</div>
                  </span>
                  <button className="btn-ghost" style={{ padding: 4, color: 'var(--ink-3)' }}><Icon name="trash" size={13} /></button>
                </div>
              ))}
            </div>
            <div style={{ padding: '14px 16px', background: 'var(--surface)' }}>
              <div className="row" style={{ marginBottom: 4 }}>
                <span className="tiny muted">Subtotal</span>
                <span className="space" />
                <span style={{ fontSize: 13 }}>${(total*18).toFixed(2)}</span>
              </div>
              <div className="row">
                <span className="tiny muted">Units</span>
                <span className="space" />
                <span className="tiny">{total}</span>
              </div>
              <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 12 }}>Add list to cart</button>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ProductDetailV1, ProductDetailV2, ProductDetailV3 });
