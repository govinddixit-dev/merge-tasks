# 00 — Product Overview

## What is MergeTasks?

A platform for **promotional product distributors** (think custom t-shirts, mugs, swag bags, branded apparel, signage) to run their business — manage clients, send proposals, fulfill orders, run print jobs, and host **branded webstores** for their end-user clients.

## Who are the users?

There are two distinct user types:

### 1. Distributor (the MergeTasks customer)
- Runs a promo products business
- Uses the main MergeTasks app to manage clients, send proposals, run jobs
- Creates a **webstore per end-user client** (e.g. "Acme Corp swag store")
- **NOT a user of the screens in this handoff** — those are managed elsewhere in the app

### 2. End-User Client (the distributor's customer)
- An employee at a company that buys swag/merch (e.g. an HR coordinator at Acme Corp ordering branded onboarding kits)
- Visits the webstore the distributor built for them
- **THIS is who the screens in this handoff are for**

## What's a "webstore"?

A self-contained, branded e-commerce site that lives at a custom subdomain (e.g. `acme.mergetasks.store`). Each webstore:

- Has **one brand** (logo, primary color, company name) — set by the distributor
- Has **one template** chosen at creation (Modern / Classic / Minimal) — controls the entire visual language
- Has **one product catalog** curated by the distributor
- Has **one client portal** where the end-user signs in to see proposals, order history, print requests, and team members

## The two surface areas

### Storefront (public-facing, template-driven)
- `/` — Home (hero, featured products, story)
- `/shop` — Browse & filter the catalog
- `/cart` — Review cart
- `/checkout` — Place order
- `/custom-request` — Request a custom item not in the catalog

### Client Portal (auth-required, template-agnostic)
- `/portal/signin` — Sign in
- `/portal` — Overview (recent activity, quick actions)
- `/portal/proposals` — List of proposals from the distributor
- `/portal/proposals/:id` — Detail view (line items, accept/decline)
- `/portal/orders` — Order history
- `/portal/print` — Print requests / production status
- `/portal/team` — Team members on this account

## How templates work

When the distributor creates a webstore, they pick **one of three templates**:

| | Modern | Classic | Minimal |
|---|---|---|---|
| Vibe | Editorial, asymmetric | Traditional retail | Premium, curated |
| Header | Center logo, thin nav | Top utility bar + main nav + sidebar | Centered, generous whitespace |
| Hero | Curtain-reveal scroll effect | Promo banner | Centered single image |
| Product grid | Asymmetric, large cards | Dense 4-col + sidebar filters | 3-col with no card chrome |
| Typography | Mix of serif italic + sans | Standard sans | Light / thin sans |
| Best for | Lifestyle, agency | Large catalogs (Shopify-like) | Premium / aesthetic brands |

The chosen template applies to **all storefront screens** for that webstore. The portal does NOT change — it always uses the neutral system design.

## Brand context (separate from templates)

On top of the template, each webstore has a brand identity:
- **Brand name** (e.g. "Acme Corp")
- **Brand mark / logo** (text or image)
- **Primary accent color** (used sparingly — buttons, links, accents)

The brand identity overlays on top of the template's neutral colors. It does NOT change layout or type — only the accent color, logo, and name strings.

## Sample brands shown in wireframes

The wireframes use 3 sample brands to demonstrate brand context:

- **Yan & Co.** — Apparel/lifestyle (used as default in wireframes)
- **Northwind** — Industrial/B2B
- **Acme** — Corporate

You can switch the active brand in the wireframe via the brand selector — this is for demo only. In production, each webstore is hard-bound to one brand at creation.

## What's NOT in this handoff

- Distributor admin UI (managing webstores, products, proposals creation) — exists elsewhere
- Auth flows beyond sign-in (signup, password reset) — handle with existing auth
- Email templates
- Mobile native — these designs are responsive web only
